// 由于 uni.request 自带的拦截器不能执行异步操作, 所以这里对它进行一下封装
// 封装后的大致使用方式是  
// http.get(url,data, {header:header}) 其中data是查询参数
// http.post(url,data, {header:header}) 其中data是请求体

// 请求基地址
let baseURL = 'http://127.0.0.1:8000/api/'


async function get_csrftoken(){
	let res = await http({
		method:'get',
		url:'user/get_csrftoken/'
	}).then(res=>{
		return res.data.data
	})
	// console.log(res);
	return res
}

// 请求拦截
let req_befor = async (options={})=>{
	options.withCredentials = true
	options.timeout = 3*60*1000  // 请求超时时间, 这里设置为3分钟
	// options.sslVerify=false
	// #ifdef APP-PLUS || MP-WEIXIN
	// 1. 非 http 开头需拼接地址
	if (!options.url.startsWith('http')) {
		options.url = baseURL + options.url
	}
	// #endif
	// #ifdef H5
	if(!options.url.startsWith('http')){
		options.url = baseURL + options.url
	}
	// #endif
	
	if(options.method=='POST' || options.method=='post' || options.method=='PUT' || options.method=='put'||
	options.method=='DELETE' || options.method=='delete'
	){
		// 如果是post请求，则先获取csrftoken，django发送post请求需要验证请求头中的csrftoken
		// 3. 添加请求头
		// options.header = {
		//   ...options.header,
		//   "X-CSRFToken": await get_csrftoken(),
		// }
		// console.log(options);
	}


	return new Promise((resolve,reject)=>{
		
		// 封装自己的请求头
		options.header = {
			...options.header,
			// client: 'bbb'
		}
		resolve(options)
	})
}
// 响应拦截
let req_after = (res)=>{
	return new Promise((resolve,reject)=>{
		if(res.statusCode >= 200 && res.statusCode < 300){
			// console.log('请求成功');
			resolve(res)
		}else{
			uni.showToast({icon:'none',title:'网络错误111'})
			reject(res)
		}
	})
	
}

const http = async (options)=>{
	// 请求拦截
	let res = await req_befor(options)
	// 发送请求
	let ret = await uni.request(res)
	
	// 响应拦截
	return req_after(ret[1])
}
http.get = (url, data,args)=>{
	let options = {
		method:'get',
		url:url,
		data:data,
		...args
	}
	return http(options)
}
http.post = (url,data,args)=>{
	let options = {
		method:'post',
		url:url,
		data:data,
		...args
	}
	return http(options)
}
http.put = (url,data,args)=>{
	let options = {
		method:'put',
		url:url,
		data:data,
		...args
	}
	return http(options)
}
http.patch = (url,data,args)=>{
	let options = {
		method:'patch',
		url:url,
		data:data,
		...args
	}
	return http(options)
}
http.delete = (url,data,args)=>{
	let options = {
		method:'delete',
		url:url,
		data:data,
		...args
	}
	return http(options)
}


export default http