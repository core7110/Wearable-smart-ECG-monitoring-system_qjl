const BaseUrl='http://localhost:8000'
function requests(params={}){
	const {url,method,header,data}=params
	const newurl=BaseUrl+url
	return new Promise((resolve,reject)=>{
		uni.request({
			url:newurl,
			method:method,
			header:header,
			data:data,
			timeout:5000,
			success:(res)=>{
				resolve(res.data)
			},
			fail:(res)=>{
				uni.showToast({
					title: '请求失败',
					duration: 2000,
					icon:"error"
				})
				reject(res.data)
			}
		})
	})

}
export default requests