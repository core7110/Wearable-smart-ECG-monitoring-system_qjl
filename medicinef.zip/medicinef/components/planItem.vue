<template>
	<view>
		<view :class="'box'+' ' + sstt[radios[item.target]]">
			<view class="box-left">
				<u-icon name="checkmark-circle" class="check" size="28" :color="isClick ?' #3ba88e':'#D6D7D9'"
					@click="chooseMol(1)" :name="isClick ? 'checkmark-circle-fill':'checkmark-circle'">
				</u-icon>
			</view>

			<view class="box-content">
				<view class="content-left">{{item.name}}</view>
				<view class="content-right">
					<view v-if="isShow" class="active">{{time}}分钟后截至</view>
					<view v-else class="over">已截至</view>
				</view>
			</view>
			<view class="box-right">
				<u-icon name="trash" size="28" class="trash" @click="chooseMol(2)"></u-icon>
			</view>



			<view>
				<u-modal :show="show" :closeOnClickOverlay="true" :showCancelButton="true" @confirm="dosubmit"
					@close="closeMol" @cancel="closeMol" :title="title"></u-modal>
			</view>
		</view>

	</view>

</template>

<script>
	export default {
		name: "planItem",
		props: ['item', 'index'],
		data() {
			return {
				// 是否展示模态框
				show: false,
				// 模态框标题
				title: "",
				p: 1,
				// 是否选择的颜色
				isClick: false,
				// 背景颜色
				sstt: ["c1", "c2", "c3", "c4", "c5"],
				// 分类
				radios: {
					"运动": '0',
					"医疗": '1',
					"吃药": '2',
					"心情": '3',
					"其他": '4',
				},
				isShow: true
			};
		},

		computed: {
			time() {

				let times = this.item.end.split("-")
				times = times.reverse()
				let str = `${times[0]}/${times[1]}/${times[2]} ${times[3]}:${times[4]}:00`
				let target = (new Date(str)).getTime() / 1000

				let now = new Date().getTime() / 1000

				let res = Math.ceil(target - now)
				if (res < 0) {
					this.isShow = false
					return
				}
				res = Math.ceil(res / 60)
				return res
			}
		},
		methods: {
			// 选择模态框状态
			chooseMol(p) {


				if (p === 1) {
					// 已经归档不用在归档
					if (this.item.status == 0) {
						return
					}
					this.show = true
					this.isClick = true
					this.title = "是否确认归档？"
					this.p = 1
				} else {
					this.show = true
					this.isClick = true
					this.title = "是否确认删除？"
					this.p = 2
				}
			},

			// 模态框确认事件
			dosubmit() {
				this.isClick = false
				this.show = false
				if (this.p == 1) {
					let data = [this.index, this.item.planid]
					console.log(this.item.status);
					if (this.item.status == 1) {
						this.retPlan(data)
					} else {
						return
					}
				} else {
					let data = [this.index, this.item.planid, this.item.status]
					console.log("删除");
					this.delPlan(data)
				}
			},
			// 关闭模态框
			closeMol() {
				this.show = false
				this.isClick = false
			},
			delPlan(data) {
				this.$emit("delPlanItem", data)
			},
			retPlan(data) {
				this.$emit("retPlan", data)
			},
			selectPlan(index) {
				this.isClick = true
				console.log(index);
			}
		}
	}
</script>

<style lang="less" scoped>
	.box {
		margin-bottom: 40rpx;
		height: 150rpx;
		border-radius: 20rpx;
		width: 100%;
		display: flex;
		color: #000;

		.box-left {
			width: 60rpx;
			height: 100%;
			line-height: 150rpx;

			.check {
				display: inline-block;
				width: 100%;
				height: 60rpx;
				margin-right: 30rpx;
				padding: 10rpx;

			}
		}

		.box-content {
			flex: 1;
			margin: 10rpx 20rpx;
			font-size: 40rpx;
			display: flex;
			flex-direction: column;
			justify-content: space-around;

			.content-left {}

			.content-right {
				text-align: right;
				font-size: 28rpx;

				.active {
					color: #aaa;
				}

				.over {
					color: #3ba88e;
				}
			}
		}

		.box-right {
			width: 60rpx;
			height: 100%;
			line-height: 150rpx;

			.trash {
				display: inline-block;
				height: 60rpx;
				margin-right: 50rpx;
				margin-top: 10rpx;
			}
		}
	}





	.c1 {
		background-color: #F2FAFA;
	}

	.c2 {
		background-color: #FFF5F4;
	}

	.c3 {
		background-color: #F9FBFE;
	}

	.c4 {
		background-color: #FFF8FB;
	}

	.c5 {
		background-color: #F6F4FB;
	}
</style>
