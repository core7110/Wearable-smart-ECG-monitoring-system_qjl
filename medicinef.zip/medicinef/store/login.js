// store/modules/user.js
export default {
  state: {
    userInfo: {
      username: '',
      email: '',
      phone: '',
      role: '',
      isLogin: false
    }
  },
  mutations: {
    SET_USER(state, userInfo) {
      state.userInfo = {
        ...userInfo,
        isLogin: true
      }
      // 持久化存储
      uni.setStorageSync('userInfo', state.userInfo)
    },
    CLEAR_USER(state) {
      state.userInfo = {
        username: '',
        email: '',
        phone: '',
        role: '',
        isLogin: false
      }
      uni.removeStorageSync('userInfo')
    }
  }
}