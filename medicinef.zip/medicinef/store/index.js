import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
let lifeDate = {}

try {
	// 尝试获取本地是否存在liseData变量，第一次启动app时是不存在的
	lifeDate = uni.getStorageSync('lifeDate')
} catch (e) {}

//需要永久存储，且下次APP启动需要取出的，在state中的变量名
let saveStateKeys = ['vuex_user', 'vuex_token', 'vue_token_expired', 'vuex_cid', 'vuex_uid', 'vuex_longi', 'vuex_lati']

// 保存到本地存储中
const savelifeDate = function(key, value) {
	// 判断变量名是否在需要存储的数组中

	if (saveStateKeys.indexOf(key) != -1) {
		// 获取本地存储的lifeDate对象，将变量添加到对象中
		let tmp = uni.getStorageSync('lifeDate')
		// 第一次打开APP时,不存在lifeDate变量,需要放一个空对象
		tmp = tmp ? tmp : {}
		tmp[key] = value
		// 执行这一步后,所有需要存储的变量,都挂载到本地的lifeDate对象中
		uni.setStorageSync('lifeDate', tmp)
	}
}
const store = new Vuex.Store({
	state: {
		// 如果上面从本地获取的lifeDate对象下有对应的属性，就赋值给state中对应的变量
		vuex_user: lifeDate.vuex_user ? lifeDate.vuex_user : {
			username: '医小汇',
			phone: '',
			age: '0',
			gender: 0,
			avatar: 'https://img0.baidu.com/it/u=4183049334,1616452240&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400'
		},
		vuex_token: lifeDate.vuex_token ? lifeDate.vuex_token : '',
		vue_token_expired: lifeDate.vue_token_expired ? lifeDate.vue_token_expired : '',
		vuex_uid: lifeDate.vuex_uid ? lifeDate.vuex_uid : '',
		vuex_cid: lifeDate.vuex_cid ? lifeDate.vuex_cid : '',
		vuex_longi: lifeDate.vuex_longi ? lifeDate.vuex_longi : '',
		vuex_lati: lifeDate.vuex_lati ? lifeDate.vuex_lati : '',
	},
	mutations: {
		$uStore(state, payload) {
			// 判断是否多层级调用，state中为对象存在的情况，诸如user.info.score = 1
			let nameArr = payload.name.split('.')
			let saveKey = ''
			let len = nameArr.length
			if (nameArr.length >= 2) {
				let obj = state[nameArr[0]]
				for (let i = 1; i < len - 1; i++) {
					obj = obj[nameArr[i]]
				}
				obj[nameArr[len - 1]] = payload.value
				saveKey = nameArr[0]
			} else {
				// 单层级变量，在state就是一个普通变量的情况
				state[payload.name] = payload.value
				saveKey = payload.name
			}
			// 保存变量到本地，见顶部函数定义
			savelifeDate(saveKey, state[saveKey])
		}
	}
})
export default store
