// store/modules/pwd.js
import requests from "../utils/requests";
import { email } from "../uni_modules/uview-ui/libs/function/test";

export default {
  namespaced: true,
  state: {
    form: {
      username: "",
      email: '',
      newPassword: '',
      passwordAgain: '',
      code: ''
    }
  },
  mutations: {
    SET_FORM_FIELD(state, { field, value }) {
      state.form[field] = value;
    },
    RESET_FORM(state) {
      state.form = {
        username: "",
        email: '',
        newPassword: '',
        passwordAgain: '',
        code: ''
      };
    }
  },
  actions: {
    async findPwd({ state, commit }) {
      try {
        const res = await requests({
          url: '/base/findPwd/',
          method: 'post',
          data: {
            username: state.form.username,
            password: state.form.newPassword,
            email: state.form.email,
            code: state.form.code
          }
        });
        
        if (res.code === 200) {
          commit('RESET_FORM');
          uni.$u.toast('修改密码成功');
          return true;
        } else {
          uni.$u.toast(`修改密码失败，${res.error}`);
          return false;
        }
      } catch (error) {
        uni.$u.toast('请求失败，请稍后重试');
        console.error(error);
        return false;
      }
    },
    async send_email({ state }) {
      try {
        const res = await requests({
          url: '/base/sendEmail/',
          method: 'post',
          data: {
            email: state.form.email
          }
        });
        
        if (res.code === 200) {
          return '邮箱验证码发送成功';
        } else {
          return `邮箱验证码发送失败,${res.error}`;
        }
      } catch (error) {
        console.error(error);
        return '邮箱验证码发送失败';
      }
    },
    async getCode({ dispatch }, uCode) {
      if (uCode.canGetCode) {
        uni.showLoading({
          title: '正在获取验证码'
        });
        
        try {
          const msg = await dispatch('send_email');
          console.log(msg);
          
          setTimeout(() => {
            uni.hideLoading();
            uni.$u.toast(msg);
            uCode.start();
          }, 2000);
        } catch (error) {
          uni.hideLoading();
          uni.$u.toast('获取验证码失败');
        }
      } else {
        uni.$u.toast('请30秒后再发送');
      }
    }
  }
};