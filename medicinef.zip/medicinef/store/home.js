// store/modules/home.js
export default {
  namespaced: true,
  state: {
    search_input: '',
    empty: 0,
    latitude: uni.getStorageSync('latitude'),
    longitude: uni.getStorageSync('longitude'),
    search_list: [],
    rules: '',
    gole_address: '',
    gole_name: '',
    gole_city: '',
    points_list: [],
    polyline_list: [],
    markers: []
  },
  mutations: {
    SET_SEARCH_INPUT(state, value) {
      state.search_input = value;
    },
    SET_SEARCH_LIST(state, list) {
      state.search_list = list;
    },
    SET_EMPTY(state, value) {
      state.empty = value;
    },
    SET_LOCATION(state, { latitude, longitude }) {
      state.latitude = latitude;
      state.longitude = longitude;
    },
    SET_GOLE_INFO(state, { location, address, name, city }) {
      state.gole_location = location;
      state.gole_address = address;
      state.gole_name = name;
      state.gole_city = city;
    },
    CLEAR_SEARCH(state) {
      state.search_input = '';
    }
  },
  actions: {
    startLocation({ commit }) {
      uni.getLocation({
        type: 'gcj02',
        isHighAccuracy: true,
        success: (res) => {
          uni.setStorageSync('latitude', res.latitude);
          uni.setStorageSync('longitude', res.longitude);
          uni.setStorageSync('selfLatitude', res.latitude);
          uni.setStorageSync('selfLongitude', res.longitude);
          commit('SET_LOCATION', {
            latitude: res.latitude,
            longitude: res.longitude
          });
        },
        fail: (error) => {
          uni.$u.toast('定位失败');
        }
      });
    },
    refleshSelfLocation({ commit }) {
      uni.getLocation({
        type: 'gcj02',
        isHighAccuracy: true,
        success: (res) => {
          uni.setStorageSync('selfLatitude', res.latitude);
          uni.setStorageSync('selfLongitude', res.longitude);
          uni.$u.toast('刷新成功');
        },
        fail: (error) => {
          uni.$u.toast('刷新失败');
        }
      });
    },
    async searchlocation({ state, commit, rootState }) {
      if (state.search_input === '') {
        uni.$u.toast('搜索内容不能为空');
      } else if (rootState.hospital.showStart === 2) {
        uni.$u.toast('必须结束当前定位才能查询');
      } else {
        try {
          const res = await uni.request({
            url: 'https://restapi.amap.com/v3/assistant/inputtips',
            method: 'get',
            data: {
              key: '4eac491217889d34536b62dacfa8d6f6',
              keywords: state.search_input
            }
          });
          
          const data = res[1].data;
          if (data.status === '1') {
            commit('SET_SEARCH_LIST', data.tips);
            commit('SET_EMPTY', 1);
            commit('CLEAR_SEARCH');
          } else {
            uni.$u.toast('搜索失败');
          }
        } catch (error) {
          uni.$u.toast('搜索请求失败');
          console.error(error);
        }
      }
    },
    chooseItem({ commit }, { gole_location, gole_address, gole_name, gole_city, store, self, marker, polyline, marker_dict, gole_location_marker }) {
      commit('SET_GOLE_INFO', {
        location: gole_location,
        address: gole_address,
        name: gole_name,
        city: gole_city
      });
      store.total(self, marker, polyline, marker_dict, gole_location_marker);
    },
    map_self({ commit }) {
      const latitude = uni.getStorageSync('latitude');
      const longitude = uni.getStorageSync('longitude');
      commit('SET_LOCATION', { latitude, longitude });
    },
    map_hospital({ commit }) {
      const latitude = uni.getStorageSync('hospital_latitude');
      const longitude = uni.getStorageSync('hospital_longitude');
      commit('SET_LOCATION', { latitude, longitude });
    },
    map_gole({ commit }) {
      const confirm = uni.getStorageSync('gole_latitude');
      if (!confirm) {
        uni.$u.toast('你还没有输入目的地');
      } else {
        const latitude = uni.getStorageSync('gole_latitude');
        const longitude = uni.getStorageSync('gole_longitude');
        commit('SET_LOCATION', { latitude, longitude });
      }
    },
    map_reflesh({ rootState }, { hospitlStore, goleStore, store, marker_dict2 }) {
      if (rootState.hospital.showStart === 2) {
        hospitlStore.refleshHospital(store, marker_dict2);
      } else if (rootState.gole.loading === 2) {
        goleStore.refleshGole(store, marker_dict2);
      } else {
        uni.$u.toast('还没有开始定位');
      }
    }
  }
};