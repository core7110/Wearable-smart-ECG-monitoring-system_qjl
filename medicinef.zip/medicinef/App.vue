<script>
	import {
		isLogin,
	} from '@/config/utils.js'

	export default {
		methods: {

			// getPushInfo() {
			// 	let pinf = plus.push.getClientInfo();
			// 	let cid = pinf && pinf.clientid || '';
			// 	// console.log(cid, '外面获取');
			// 	plus.push.getClientInfoAsync(function(info) {
			// 		// console.log('Success');
			// 		cid = info.clientid
			// 		// console.log(cid, '里面获取');
			// 		// console.log(info.clientid);
			// 		uni.$u.vuex('vuex_cid', info.clientid)
			// 		// console.log(JSON.stringify(info));
			// 	}, function(e) {
			// 		// console.log('Failed');
			// 		// console.log(JSON.stringify(e));
			// 	})
			// },
			// async postCidUid() {
			// 	await postCid({
			// 		cid: user.cid,
			// 		uid: user.uid
			// 	})
			// }
		},
		onLoad() {
			// console.log("App onLoad");
		},
		onLaunch: function() {
			// this.getPushInfo()
			//let user = uni.getStorageSync("lifeDate") || 'as'
			//const token = user.vuex_token

		//	isLogin(token)
		//	// plus.push.addEventListener("receive", function(msg) {
			// 	// console.log(msg);
			// }, false)
			// plus.push.addEventListener("click", function(msg) {
			// 	setTimeout(() => {
			// 		uni.switchTab({
			// 			url: '/pages/pages/plan/plan'
			// 		})  
			// 	}, 1000)
			// 	plus.push.clear()
			// })
		},
		onShow: function() {},
		onHide: function() {}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import "@/uni_modules/uview-ui/index.scss";

	@import 'uni_modules/jo-markdown/components/jo-markdown/main.css'; //引入jo-markdown呈现
</style>