// 此vm参数为页面的实例，可以通过它引用vuex中的变量
module.exports = (vm) => {
  uni.$u.http.setConfig((config) => {
    /* config 为默认全局配置*/
    config.baseURL = 'http://121.89.237.52:8083/' /* 根域名 */
    return config
  })
}
