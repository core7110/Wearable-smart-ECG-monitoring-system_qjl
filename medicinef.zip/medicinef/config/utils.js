// 跳转登录
export const isLogin = token => {
	if (!token) {
		setTimeout(() => {
			uni.$u.route({
				type: 'reLaunch',
				url: 'pages/login/login',
			})
		}, 0)
		return false
	}
	return true
}
export const setAlarm = prama => {
	let {
		location,
		description,
		startDate,
		endDate
	} = prama
	const dcRichAlert = uni.requireNativePlugin('CRGG-Plugin')
	console.log(dcRichAlert)
	dcRichAlert.setcalendar({
		title: '小医智汇提醒',
		location,
		allDay: '1',
		description,
		startDate,
		endDate,
		alarmArray_ios: ['-7.f', '-17.f', '-27.5f'],
		alarmArray_android: [1, 2, 10],

	}, result => {
		if (result.type == '0') {
			//失败 message
			uni.showToast({
				icon: 'error',
				title: '创建失败'
			})
		} else {
			//成功
			uni.showToast({
				icon: 'success',
				title: '创建成功'
			})
		}
	})
}
