const http = uni.$u.http

// get 获取首页文章内容
export const getArticle = data => {
	return http.get(`/tips/recommend?uid=${data}`)
}
// get 根据文章id获取文章详情
export const getItem = data => {
	return http.get(`/tips/look?pid=${data}`)
}
// get 获取收藏文章内容
export const getCollectionArticle = data => {
	return http.get(`/tips/collectArticle?uid=${data}`)
}
// 计划
// 提交当前设备的cid
export const postCid = (params, config = {}) => http.post('/user/register', params, config)
// 获取计划集计划
export const getAllPlan = data => {
	return http.get(`/Plan/plan?uid=${data}`)
}
// 获取归并计划集计划
export const retPlan = data => {
	return http.get(`/Plan/planGuiDang?uid=${data}`)
}
// 删除计划
export const delPlan = (params, config = {}) => http.post(`/Plan/delete?PlanId=${params}`)
// 归档
export const retPlanItem = (params, config = {}) => http.post('/Plan/update', params, config)
// 创建计划
export const insertPlanItem = (params, config = {}) => http.post('/Plan/insert', params, config)



// 个人中心相关
// 获取健康档案基础信息
export const getTrueInfo = data => {
	return http.get(`/user/UserInfo?uid=${data}`)
}
// 获取健康档案健康信息
export const getHealth = data => {
	return http.get(`/user/HealthInfo?uid=${data}`)
}
// 更新健康档案基础信息
export const postTrueInfo = (params, config = {}) => {
	console.log(params)
	return http.post('/user/UserInfo', params, config)
}
// 更新健康健康档案健康信息
export const postHealth = (params, config = {}) => http.post('/user/HealthInfo', params, config)
// post示例内容
export const postMenu = (params, config = {}) => http.post('/api/auth/wx/bind', params, config)

// 点赞文章
export const postLike = (uid, pid) => {
	return http.post(`/tips/like?pid=${pid}&uid=${uid}`)
}
// 获取点赞状态
export const getLike = (uid, pid) => {
	return http.get(`/tips/likeStatus?pid=${pid}&uid=${uid}`)
}
// 收藏文章
export const postCollect = (uid, pid) => {
	return http.post(`/tips/collect?pid=${pid}&uid=${uid}`)
}
// 获取收藏状态
export const getCollect = (uid, pid) => {
	return http.get(`/tips/collectStatus?pid=${pid}&uid=${uid}`)
}
// 取消收藏
export const deleteCollect = (uid, pid) => {
	return http.delete(`/tips/cancelCollect?pid=${pid}&uid=${uid}`)
}
