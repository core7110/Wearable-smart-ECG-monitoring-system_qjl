// vue.config.js
module.exports = {
  devServer: {
    proxy: {
      '/prefix/api/user/list': {
        target: 'http://api.heclouds.com/devices/932059476/datastreams',
        pathRewrite: {
          '^/prefix': ''
        }
      }
    },
  }
}
