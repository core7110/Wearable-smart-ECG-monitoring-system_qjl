<template>
	<view>
			<!--文章顶部-->
			<view class="article-top">
				<u-avatar :src="article.authorP" size="50"></u-avatar>
				<view class="article-middle">
					<u-tag class="tags" :text="article.target" plain size="mini" type="warning" icon="tags"></u-tag>
					<p class="p1">{{article.publishDate}}</p>
				</view>
				<view class="article-right">
					<u-icon name="star" size="28" color="#909399"></u-icon>
					<u-icon name="share" size="28" color="#909399"></u-icon>
				</view>
			</view>
			<u-divider text="分割线" :dot="true"></u-divider>
			<!--文章标题-->
			<view class="title">
				<p>{{article.title}}</p>
			</view>
			<view class="author">作者:{{article.author}}</view>
			<view class="img">
				<image src="http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/17/16527694706633911.png"></image>
			</view>
			<view class="title-item">
			<div
					  class="markdown-body"
					  v-html="article.content"
					  ref="article-content"
					></div>
			</view>
			<u-divider class="bot-div" :text="'来源: ' + article.paperFrom" textPosition="right"></u-divider>
			<!-- <u-tabbar
				:value="value6"
				@change="name => value6 = name"
				:fixed="true"
				:placeholder="true"
				:safeAreaInsetBottom="true"
			>
				<u-tabbar-item text="喜欢" icon="thumb-up" ></u-tabbar-item>
				<u-tabbar-item text="无感" icon="thumb-down" ></u-tabbar-item>
				<u-tabbar-item text="收藏" icon="star" @click="collection"></u-tabbar-item>
			</u-tabbar> -->
			<view class="u-demo-block">
				<view class="u-demo-block__content">
						<u-row customStyle="margin-bottom: 10px">
								<u-col span="6">
										<div class="demo-layout">
											<p class="icon"><u-icon :name="thumbUp.name" 
											size="25" @click="upClick"></u-icon></p>
										</div>
								</u-col>
								<u-col span="6">
										<div class="demo-layout">
											<p class="icon"><u-icon :name="star.name" 
											size="25" @click="starClick"></u-icon></p>
										</div>
								</u-col>
						</u-row>
				</view>
			</view>
	</view>
</template>

<script>
	import {
		getItem, postLike, getLike, postCollect, getCollect, deleteCollect
	} from '@/config/api.js'
	export default {
	 onLoad(option){
		 this.pid = option['id']
		 this.getAcrticleItem()
		 console.log(this.vuex_uid)
		 console.log(this.pid)
		 this.getUp();
		 this.getStar();
		},
		data() {
			return {
				pid: '',
				value6: 0,
				article:[],
				thumbUp: {
					isUp: null,
					name:''
				},
				star: {
					isUp: null,
					name:''
				}
			}
		},
		
		methods: {
				async getAcrticleItem(){
						const id = this.pid
						const {data} = await getItem(id)
						const results = data.data
						this.article = results
						console.log(this.article)
				},
			getUp(){
				getLike(this.vuex_uid, this.pid).then(res=>{
					if (res.data.data == 1){
						this.thumbUp.isUp = true;
						this.thumbUp.name ='thumb-up-fill';
					}
					else{
						this.thumbUp.isUp = false
						this.thumbUp.name = 'thumb-up'
					}
				})
			},
			getStar(){
				getCollect(this.vuex_uid, this.pid).then(res=>{
					if (res.data.data == 1){
						this.star.isUp = true;
						this.star.name ='star-fill';
					}
					else{
						this.star.isUp = false;
						this.star.name ='star';
					}
				})
			},
			upClick(){
					if(!this.thumbUp.isUp){
						postLike(this.vuex_uid, this.pid).then(res=>{
							this.thumbUp.isUp = true;
							this.thumbUp.name ='thumb-up-fill';
						})
					}
					else
						return
				},
				starClick(){
					if(!this.star.isUp){
						postCollect(this.vuex_uid, this.pid).then(res=>{
							this.star.isUp = true;
							this.star.name ='star-fill';
						})
					}
					else{
						deleteCollect(this.vuex_uid, this.pid).then(res=>{
							this.star.isUp = false;
							this.star.name ='star';
						})
					}
				}		
		}
	}
</script>

<style lang="less" scoped>
	@import url('./github-markdown.css');
	.u-demo-block{
		// background-color: aliceblue;
		border: 1px solid #e2dfde;
		.demo-layout {
		    height: 25px;
		    border-radius: 4px;
				position: relative;
				.icon{
						position: absolute;
						top: 65%;
						left: 50%;
						transform: translate(-50%, -50%);
					}
		}
	}
	
	    
	
		.article-top{
			margin-top: 20rpx;
			display: flex;
			align-items: center;
			justify-content: space-around;
			.tags{
				width: 150rpx;
			}
			.p1{
				margin-top: 12rpx;
				color:gray;
				font-size: 24rpx
			}
			.article-middle{
				margin-left: -100rpx;
			}
			.article-right{
				display: flex;
				.u-icon{
					margin-left: 20rpx;
				}
			}
		}
			.u-divider{
				width: 90%;
				margin: 0 auto;
			}
			.uni-icons{
			font-size: 30rpx!important;
			}
			.u-line{
				margin:0 auto!important;
				margin-top: 50rpx;
			}
			.title{
					color: black;
					font-size: 40rpx;
					margin: 0 auto;
					text-align: center;
					font-weight: bold;
					padding: 36rpx;
			}
			.img{
				text-align: center;
				margin: 0 auto;
				uni-image{
					width: 700rpx;
					height: 380rpx;
				}
			}
			.title-item{
				margin-bottom: 100rpx;
				padding: 30rpx;
			}
			.bot-div{
				margin-bottom: 50rpx;
			}
			.author{
				margin: 0 auto;
				text-align: center;
				margin-bottom: 16rpx;
			}
</style>
