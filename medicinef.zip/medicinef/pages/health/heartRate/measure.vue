<template>
	<view class="resultMain">
  <!-- <remote-js src="https://cdn.jsdelivr.net/npm/echarts@4.3.0/dist/echarts.min.js"></remote-js> -->
		<!-- 图形结果 -->
		<div class="statistical">
			<!-- 数字结果 -->
			<div class="number">
				<div>
					<image src="../../../static/icon/heart.png" class="img"></image>
					<span>心率</span>
					<span>(次/分钟)</span>
				</div>
				<div class="resultNumber">
					<p>平均心率</p>
					<p>{{theFirst.heartRate}}</p>
				</div>
				<div class="resultNumber">
					<p>正常范围</p>
					<p>60~100</p>
				</div>
			</div>
			<div class="graph">
				<!-- <u-line-progress :percentage="30" :showText="false" height="8"></u-line-progress> -->
			<ul>
				<li>过缓</li>
				<li>正常</li>
				<li>过速</li>
			</ul>
			<ul>
				<li></li><li></li><li></li>
			</ul>
			<ul>
				<li>60</li>
				<li>100</li>
				<li v-bind:style="{left: indicate, borderBottomColor: borderColor}"></li>
			</ul>
			</div>
		</div>
			
			<div class="statistical" id="statistical1">
				<!-- 数字结果 -->
				<div class="number">
					<div>
						<image src="../../../static/icon/O2.png" class="img"></image>
						<span>血氧</span>
						<span>(百分比)</span>
					</div>
					<div class="resultNumber">
						<p>测量结果</p>
						<p>{{theFirst.bloodOxygen}}%</p>
					</div>
					<div class="resultNumber">
						<p>正常范围</p>
						<p>94%~100%</p>
					</div>
				</div>
			</div>
			<div class="statistical" id="statistical2">
				<!-- 数字结果 -->
				<div class="number">
					<div>
						<image src="../../../static/icon/tiwen.png" class="img"></image>
						<span>体温</span>
						<span>(摄氏度)</span>
					</div>
					<div class="resultNumber">
						<p>测量结果</p>
						<p>{{theFirst.temperature}}℃</p>
					</div>
					<div class="resultNumber">
						<p>正常范围</p>
						<p>36℃~37℃</p>
					</div>
				</div>
			</div>
		</div>
	</view>
</template>

<script>
	export default {
		props: ['theFirst'],
		data() {
			return {
				indicateData: 0,
				data: null,
			}
		},
		computed: {
			indicate(){
				if(!this.indicateData)
					this.getIndicateData()
				return this.indicateData + 'rpx'
			},
			borderColor(){
				if(!this.indicateData)
					this.getIndicateData()
				if(this.indicateData < 206){
					return '#fedd59'
				}
				else if(this.indicateData <= 430){
					return '#7ee697'
				}
				else{
					return '#ff7272'
				}
			}
		},
		methods: {
			getIndicateData(){
				if(this.theFirst.heartRate < 60)
					this.indicateData = (224/60)*this.theFirst.heartRate - 18
				else if(this.theFirst.heartRate == 60)
					this.indicateData = 206;
				else if(100 > this.theFirst.heartRate > 60)
					this.indicateData = 206 + (224/40)*(this.theFirst.heartRate - 60);
				else if(this.theFirst.heartRate == 100)
					this.indicateData = 430;
				else
					this.indicateData = 430 + (224/40)*(this.theFirst.heartRate - 100)
			}
		}
	}
</script>

<style lang="less" scoped>
	#statistical1, #statistical2{
		height: 190rpx;
		.number{
			div:nth-of-type(2){
				width: 300rpx;
			}
			div:nth-of-type(3){
				width: 300rpx;
			}
		}
	}
.resultMain{
	// border-top: 1px solid #BBBBBB;
	padding: 0rpx 30rpx;
	// height: calc(100vh - 89rpx);
	background-color: rgba(248, 250, 253, 100);
	div{
		// border: 1px solid black;
	}
	.statistical{
		margin-top: 30rpx;
		height: 370rpx;
		// border: 1px solid black;
		// box-shadow: 0 0 10rpx rgba(0,0,0,.1);
		margin-bottom: 20rpx;
		background-color: #fff;
		border: 1px solid rgba(207, 232, 232, 100);
		border-radius: 10px 10px 10px 10px;
		padding: 30rpx 0;
		.number{
			margin-left:40rpx;
			div:nth-of-type(1) {
				position: relative;
				height: 50rpx;
				.img{
				 width: 50rpx;
				 height: 50rpx;
				}
				span:nth-of-type(1){
					font-size: 40rpx;
					font-weight: 600;
					position: absolute;
					left: 70rpx;
					top: 2rpx;
				}
				span:nth-of-type(2){
					font-size: 34rpx;
					position: absolute;
					left: 170rpx;
					color: #B0B0B0;
					top: 7rpx;
				}
			}
			.resultNumber{
				margin-top: 30rpx;
				height: 114rpx;
				float: left;
				p:nth-of-type(1){
					font-size: 34rpx;
					margin-bottom: 10rpx;
				}
				p:nth-of-type(2){
					font-size: 50rpx;
				}
			}
			div:nth-of-type(2){
				width: 350rpx;
			}
			div:nth-of-type(3){
				width: 200rpx;
			}
		}
		.graph{
			height: 200rpx;
			margin-top: 180rpx;
			ul{
				width: 672rpx;
				padding-left: 0;
				margin: 0 auto;
			}
			li{
				list-style-type: none;
			}
			ul:nth-of-type(1){
				height: 41.6rpx;
				li{
					float: left;
					width: 224rpx;
					text-align: center;
				}
			}
			ul:nth-of-type(2){
				height: 40rpx;
				li{
					float: left;
					width: 224rpx;
					height: 40rpx;
				}
				li:nth-of-type(1){
					background-color: #fedd59;
					border-top-left-radius: 20rpx;
					border-bottom-left-radius: 20rpx;
				}
				li:nth-of-type(2){
					background-color: #7ee697;
					position: relative;
					// bottom: 0rpx;
				}
				li:nth-of-type(3){
					background-color: #ff7272;
					border-top-right-radius: 20rpx;
					border-bottom-right-radius: 20rpx;
				}
			}
			ul:nth-of-type(3){
				height: 41.6rpx;
				position: relative;
				margin-top: 20rpx;
				li{
					width: 250rpx;
				}
				li:nth-of-type(1){
					float: left;
					text-align: right;
				}
				li:nth-of-type(2){
					float: right;
					text-align: left;
				}
				li:nth-of-type(3){
					position: absolute;
					width: 0rpx;
					height: 0rpx;
					border: 18rpx solid transparent;
					top: -32rpx;
				}
			}
	}
		.words{
			height: 200rpx;
			p{
				text-align: center;
			}
		}
	}
}
</style>

