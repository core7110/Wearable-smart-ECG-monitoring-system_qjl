<template>
	<view class="historyMain">
	<view class="history">
		<ul>
			<li v-for="item in thirtyData">
				<p class="time">{{item.date}}</p>
				<div class="number">
					<div class="value">
						<div class="center">
							<p>心率<span>{{item.heartRate}}</span>bmp</p>
							<p><u-tag :text="getRateTag(item.heartRate).text" :type="getRateTag(item.heartRate).type" plain plainFill></u-tag></p>
						</div>
					</div>
					<div class="value">
						<div class="center">
							<p>血氧<span>{{item.bloodOxygen}}</span>%</p>
							<p><u-tag :text="getBloodTag(item.bloodOxygen).text" :type="getBloodTag(item.bloodOxygen).type" plain plainFill></u-tag></p>
						</div>
					</div>
					<div class="value">
						<div class="center">
							<p>体温<span>{{item.temperature}}</span>℃</p>
							<p><u-tag :text="getTempTag(item.temperature).text" :type="getTempTag(item.temperature).type" plain plainFill></u-tag></p>
						</div>
					</div>	
				</div>
			</li>
		</ul>
	</view>
	</view>
</template>

<script>
	export default {
		props: ['thirtyData'],
		data() {
			return {
				tag:[
					{
						text: '过低',
						type: 'warning'
					},
					{
						text: '正常',
						type: 'success'
					},
					{
						text: '过高',
						type: 'error'
					}
				]
			}
		},
		methods: {
			getRateTag(rate){
				if(rate < 60)
					return this.tag[0];
				else if(rate <= 100 )
					return this.tag[1];
				else
					return this.tag[2]; 
			},
			getBloodTag(blood){
				if(blood < 94)
					return this.tag[0];
				else if(blood <= 100 )
					return this.tag[1];
				else
					return this.tag[2]; 
			},
			getTempTag(temp){
				if(temp < 36)
					return this.tag[0];
				else if(temp <= 37 )
					return this.tag[1];
				else
					return this.tag[2]; 
			}
		}
	}
</script>

<style lang="less" scoped>
	.historyMain{
		background-color: rgba(248, 250, 253, 100);
	}
	.history{
		width: 93%;
		margin: 0 auto;
		ul{
			margin-top: 40rpx;
			padding: 0;
			padding-bottom: 40rpx;
			background-color: rgba(248, 250, 253, 100);
			li{
				height: 558rpx;
				list-style-type: none;
				border-radius: 30rpx;
				margin-bottom: 50rpx;
				.time{
					color: #474444;
					font-size: 36rpx;
					font-weight: 600;
				}
				.number{
					.value{
						position: relative;
						height: 150rpx;
						margin-top: 20rpx;
						background-color: #fff;
						border-radius: 20rpx;
						box-shadow: 0 0 10rpx rgba(0,0,0,.1);
						.center{
							position: relative;
							top: 42.2rpx;
							margin-left: 60rpx;
							p:nth-of-type(1){
								color: #525050;
								font-size: 36rpx;
								span{
									color: #2AAD67;
									font-size: 50rpx;
									display: inline-block;
									margin: 0 10rpx 0 40rpx;
								}
							}
							p:nth-of-type(2){
								width: 100rpx;
								height: 56rpx;
								position: absolute;
								bottom: 0;
								right: 60rpx;
							}
						}
					}
				}
			}
		}
	}
</style>