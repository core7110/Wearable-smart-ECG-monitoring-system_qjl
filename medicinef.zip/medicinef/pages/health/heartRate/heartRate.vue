<template>
  <view class="container">
    <!-- 顶部导航栏 -->
<!--    <view class="header">
      <view class="back-icon"></view>
      <text class="header-title">健康检测</text>
    </view> -->
    <!-- 数据展示区域 -->
    <view class="data-block">
      <!-- 心电图检测显示 ,引入lime-ecg组件,心电图模块的所有组件都放在uni_modules/lime-ecg/components/lime-ecg/lime-ecg.vue文件里-->
      <view class="ecg-display">
        <text class="ecg-title">心电图检测</text>
        <!-- <lime-ecg ref="limeEcgRef" class="lime-ecg-custom"></lime-ecg> -->
        <!-- <MyLimeEcg ref="limeEcgRef"></MyLimeEcg> -->

        <view ref="echart" style="width: 100%;height:400px;"></view>
		<view @click="preData">测试预测功能</view>
		<view>
			<view v-if="pre_state">异常状态：{{pre_state.predicted_classes.join(',')}}</view>
		</view>
      </view>
    </view>
    <view v-for="(item, index) in healthData" :key="index" class="data-block">
      <view class="data-header">
        <text :class="item.iconClass">{{ item.label }}</text>
        <text class="unit">{{ item.unit }}</text>
      </view>
      <view class="data-content">
        <view class="data-sub-item">
          <text class="sub-label">{{ item.subLabel1 }}</text>
          <text class="sub-value">{{ item.value1 }}</text>
          <!-- 新增状态提示位置 -->
          <text :class="getStatusClass(item)" class="status-text">{{ getStatusText(item) }}</text>
        </view>
        <view class="data-sub-item">
          <text class="sub-label">{{ item.subLabel2 }}</text>
          <text class="sub-value">{{ item.value2 }}</text>
        </view>
      </view>
    </view>
    <!-- 健康指数分析 -->
    <view class="health-index">
      <button class="health-index-button" @click="showHealthIndexAnalysis">
        <text class="ai-icon">💻</text>
        <text class="button-text">健康指数分析</text>
      </button>
    </view>
  </view>
</template>

<script>
import http from '@/utils/http.js'
import * as echarts from 'echarts';

export default {
  data() {
    
    return {
      activeTab: 'latest',
      healthData: [
        {
          label: '心率',
          iconClass: 'icon-heart',
          unit: '(次/分钟)',
          subLabel1: '平均心率',
          subLabel2: '正常范围',
          value1: 75,
          value2: '60~100',
          range: [60, 100]
        },
        {
          label: '呼吸',
          iconClass: 'icon-blood-oxygen',
          unit: '(次/分钟)',
          subLabel1: '呼吸频率',
          subLabel2: '正常范围',
          value1: 10,
          value2: '12~20',
          range: [12, 20]
        },
        {
          label: '体温',
          iconClass: 'icon-temperature',
          unit: '(摄氏度)',
          subLabel1: '当前体温',
          subLabel2: '正常范围',
          value1: 39.5,
          value2: '35~40',
          range: [35, 39]
        }
      ],
      isPlaying: false,
      chart:null,
      chart_option:null,
      start:0,  // 开始秒数
      timer:0,  // 定时器
	  pre_state:null,
    };
  },
  mounted() {
    this.getData();
    // 开启一个定时器, 每秒更新一次数据
    this.timer = setInterval(() => {
      this.getData();
    }, 500);
    this.initData()
  },
  // 组件销毁时候触发
  beforeDestroy() {
    // 停止定时器
    clearInterval(this.timer);
  },
  methods: {
    getProgressClass(value, range) {
      if (value < range[0]) {
        return 'progress-low';
      } else if (value > range[1]) {
        return 'progress-high';
      } else {
        return 'progress-normal';
      }
    },
    getProgressWidth(value, range) {
      const min = range[0];
      const max = range[1];
      return ((value - min) / (max - min) * 100) + '%';
    },
    showHealthIndexAnalysis() {
      uni.navigateTo({
        url: `/pages/webview/webview?url=${encodeURIComponent('https://deepseek.com')}`
      });
    },
    getStatusText(item) {
      const { label, value1, range } = item;
      if (label === '心率') {
        if (value1 < range[0]) return '过缓';
        if (value1 > range[1]) return '过速';
        return '正常';
      } else if (label === '呼吸') {
        if (value1 < range[0]) return '过缓';
        if (value1 > range[1]) return '过速';
        return '正常';
      } else if (label === '体温') {
        if (value1 < range[0]) return '过低';
        if (value1 > range[1]) return '过高';
        return '正常';
      }
      return '正常';
    },
    getStatusClass(item) {
      const status = this.getStatusText(item);
      if (status === '过缓' || status === '过低') return 'progress-low-text';
      if (status === '过速' || status === '过高') return 'progress-high-text';
      return 'progress-normal-text';
    },
	
	// 获取真实数据
	getData(){
		let data = [];
		http.get('get_data/',{start:this.start}).then(res=>{
		  if(res.data.code==200){
			this.healthData.map(item=>{
			  if(item.label=='心率'){
				  let breath = Math.round(res.data.last_data.breath) 
				  if(breath >= 60 && breath <=100){
					  item.value1= breath
				  }
				
			  }else if(item.label=='呼吸'){
				item.value1= this.getRandomInt(item.range[0],item.range[1])
			  }
			  else if(item.label=='体温'){
				item.value1=(this.getRandomInt(item.range[0],item.range[1]) + Math.random() * 1).toFixed(1)
			  }
			})
			// 更新图表数据
			this.chart.setOption({
			  dataset: {
				  source: [
					  ['时间', ...res.data.data.map(item=>item.timestamp)],
					  ['ecg_data', ...res.data.data.map(item=>item.heartRate)],
				  ]
			  },
			})
			this.start += 1
			if(!res.data.has_next){
			  // 检查是否还有更多数据, 如果没有了, 则停止
			  clearInterval(this.timer)
			  
			}
			if(this.start >100){
			  // 检查是否还有更多数据, 如果没有了, 则停止
			  clearInterval(this.timer)
			  
			}
			// 获取状态预测信息
			if(res.data.pre_state){
				this.pre_state = res.data.pre_state
			}
			
			
		  }else{
			uni.showToast({icon:'none',title: '获取数据失败',duration:3000})
		  }
		})
		
	},
  // 初始化数据
  initData(){
    this.chart = echarts.init(this.$refs.echart.$el);
    this.chart_option = {
            dataset: {
                source: [
                    ['时间', '222'],
                    ['ecg_data', '333'],
                ]
            },
            title: {text:'ECG数据'},
            // dataZoom: [
            //     {
            //         type: 'inside', // 滑动条型数据区域缩放组件
            //         start: 0, // 左边在10%的位置
            //         end: 100 // 右边在60%的位置
            //     },
            //     {
            //         type: 'slider', // 滑动条型数据区域缩放组件
            //         start: 0, // 左边在10%的位置
            //         end: 100 // 右边在60%的位置
            //     },
            // ],
            xAxis: [
                {type: 'category'},
            ],
			
            yAxis: [{gridIndex: 0, type:'value', min:100000, max:180000, interval:30000}],
            tooltip:{show:true},
            series: [
                {
                    type: 'line',
                    seriesLayoutBy: 'row',
					symbol: 'none', // 不显示点
					smooth:true,
					connectNulls: true,
					// 添加平均值线
					markLine: {
						data: [
							{ type: 'average', name: '平均值' }
						]
					},
					animation: true,
					animationEasing: 'linear',
					animationDuration: 1000
      //               label: {
      //                   show: true,
						// // interval:5,  // 间隔5个值显示
      //                   position: 'top', // 可以是 'top', 'left', 'right', 'bottom', 'inside', 'insideLeft', 'insideRight'
      //                   formatter: '{a}' // 使用数据值作为标签内容，{c} 表示数据值
      //                 }
                },

            ]
        }
        this.chart.setOption(this.chart_option);
  },
  // 实时更新数据
  updateData(value){
    console.log('我被执行了',this.$refs.ecgRef.update);
    this.$refs.ecgRef.update.call(this.$refs.ecgRef,value);
    console.log('我被执行了');
    setInterval(() => {
      this.$refs.ecgRef.update(value);
      console.log('我被执行了');
    }, 1000);
  },
  
  // 生成随机整数, 模拟呼吸评率和温度
  getRandomInt(a, b){
    // 确保min和max为整数
    let min = Math.ceil(a);
    let max = Math.floor(b);
    // Math.random()生成一个[0,1)的浮点数，乘以(max - min + 1)后，
    // 结果的范围是[0, max - min + 1)，然后通过Math.floor()取整，
    // 结果的范围变为[0, max - min]，最后加上min得到最终的范围[min, max]
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },
  // 预测
  preData(){
	  http.get('pre_data/').then(res=>{
		  
		  this.pre_state = res.data
	  })
  }



	
  }

};
</script>

<style>
.container {
  background-color: #f4f4f4;
  padding: 10px;
}
.header {
  display: flex;
  align-items: center;
  background-color: white;
  padding: 15px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}
.back-icon {
  width: 20px;
  height: 20px;
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><path d="M12 18L4 10l8-8" stroke="black" stroke-width="2" fill="none"></path></svg>');
  background-size: contain;
  margin-right: 10px;
}
.header-title {
  font-size: 18px;
  font-weight: bold;
}
.tab-bar {
  display: flex;
  justify-content: space-around;
  background-color: white;
  margin-top: 10px;
  padding: 10px 0;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}
.tab-bar view {
  font-size: 16px;
  padding-bottom: 5px;
}
.tab-active {
  color: #007AFF;
  border-bottom: 2px solid #007AFF;
}
.data-block {
  background-color: white;
  border-radius: 10px;
  margin-top: 10px;
  padding: 15px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}
.data-header {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}
.icon-heart::before {
  content: '\1F495';
  margin-right: 5px;
}
.icon-blood-oxygen::before {
  content: '🌫';
  margin-right: 5px;
}
.icon-temperature::before {
  content: '🌡';
  margin-right: 5px;
}
.unit {
  font-size: 14px;
  color: #666;
}
.data-content {
  display: flex;
  justify-content: space-between;
}
.data-sub-item {
  width: 48%;
  position: relative;
}
.sub-label {
  font-size: 12px;
  color: #666;
  margin-bottom: 3px;
}
.sub-value {
  font-size: 16px;
  font-weight: bold;
}
.status-text {
  font-size: 14px;
  position: relative;
  display: block;
  margin-top: 3px;
  white-space: nowrap;
}
.progress-container {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.progress-bar {
  height: 8px;
  background-color: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
  position: relative;
  width: 100%;
}
.progress-segment {
  height: 100%;
}
.progress-low {
  background-color: #FFC107;
}
.progress-normal {
  background-color: #4CAF50;
}
.progress-high {
  background-color: #F44336;
}
.progress-value {
  display: none;
}
.progress-text {
  display: none;
}
.progress-status {
  display: none;
}
.ecg-display {
  max-width: 100%; /* 限制最大宽度 */
  background-color: #f9f9f9;
  border-radius: 10px;
  padding: 10px; /* 调整内边距 */
  margin-top: 10px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: center;
}

.ecg-title {
  font-size: 16px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
  text-align: center;
}
.lime-ecg-custom {
  width: 100%; /* 组件宽度占满容器 */
  box-sizing: border-box; /* 确保内边距和边框不影响宽度 */
}
.health-index {
  background-color: #f9f9f9;
  border-radius: 10px;
  padding: 15px;
  margin-top: 10px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  text-align: center;
}
.health-index-button {
  width: 100%;
  padding: 10px;
  font-size: 16px;
  background-color: white;
  color: #007AFF;
  border: 1px solid #007AFF;
  border-radius: 5px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.ai-icon {
  margin-right: 5px;
  font-size: 20px;
}
.button-text {
  line-height: 1;
}
.progress-low-text {
  color: #FFC107;
}
.progress-normal-text {
  color: #4CAF50;
}
.progress-high-text {
  color: #F44336;
}

</style>    