
<template>
	<view class="measureMain">
		<div class="image">
			<!-- <image style="width: 100%; z-index: 99; position: absolute; top: 0;" src="@/static/images/my/heartRate.png" mode=""></image> -->

			<!-- <image src="../../../static/images/my/heartRate.png" mode=""></image> -->
			<u--image width="100%" src="../../../static/images/my/heartRate.png"></u--image>

			<!-- <image src="../../../static/images/my/bloodPressure.png" mode="	heightFix"></image> -->
		</div>
		<div class="measure"> 
			<p>请佩戴好心率测量仪，并打开心率测量仪</p>
			<div calss="circle" @click="getData" style="width: 250rpx;
		height: 250rpx; margin: 46rpx auto 0;">
				<circle-progress inactiveColor="#B8D9FD" 
				borderWidth="10" :percent="percent" 
				bgColor="#F8FAFD" width="250">开始测量
				</circle-progress>
			</div>
		</div>
		<!-- 蓝牙未开提示 -->
		<u-overlay :show="overlayShow" @click="overlayShow = false" :opacity="0.3">
				<view class="warp">
					<view class="rect" @tap.stop>
						<p>提示</p>
						<p>蓝牙设备未打开</p>
						<p>请开启蓝牙并连接设备</p>
						<div class="btn">
							<u-button type="primary" text="取消" class="custom1-style"
							color="#F7F7F7" style="color: #5a5a5a" @click="close"></u-button>
							<u-button type="primary" text="前往打开" class="custom2-style"
							color="#69C0FF"></u-button>
						</div>
					</view>
				</view>
		</u-overlay>
	</view>
</template>

<script>
	import circleProgress from '@/components/ar-circle-progress/index.vue'
	export default {
		data() {
			return {
				overlayShow: false,
				percent: 0
			}
		},
		components:{
			circleProgress
		},
		methods: {
			close(){
				this.overlayShow = false
			},
			getData(){ 
				// uni.request({
				// 	url:'http://api.heclouds.com/devices/932059476',
				// 	header: {
				// 					"api-key": 'aAOUtvAo5OU=kkD3EjnbmA=DP0Y=' //自定义请求头信息
				// 			},
				// 	method:'GET',
				// 	success: (res) =>{
				// 		console.log(res.data.data)
						uni.navigateTo({
							url: '/pages/health/heartRate/result'
						})
				// 	}
				// })
			}
		}
	}
</script>

<style lang="less" scoped>
.measureMain{
	background-color: rgba(248, 250, 253, 100);
	height: calc(100vh - 240rpx);
}
.measure{
	height: 200rpx;
	margin-top: 102rpx;
	p{
		text-align: center;
		font-size: 36rpx;
	}
	.circle{
		margin: 0 auto;
	}
}
// 蓝牙未开提示
.warp {
		display: flex;
		align-items: center;
		justify-content: center;
		height: 100%;
		.rect {
			width: 522rpx;
			height: 404rpx;
			background-color: #fff;
			border-radius: 40rpx;
			p{
				text-align: center;
				font-size: 32rpx;
			}
			p:nth-of-type(1){
				font-size: 36rpx;
				margin-top: 36rpx;
			}
			p:nth-of-type(2){
				margin-top: 58rpx;
			}
			.btn{
				padding: 0 58rpx;
				margin-top: 48rpx;
				button{
					border-radius: 24rpx;
				}
				.custom1-style {
					width: 182rpx;
					height: 68rpx;
					float: left;
					
				}
				.custom2-style {
					width: 182rpx;
					height: 68rpx;
					float: right;
				}
			}
		}
	}

	
</style>

