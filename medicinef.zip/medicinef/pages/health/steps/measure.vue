<template>
	<view class="measureMain">
	<!-- 最大的盒子 -->
	<view class="bigBox">
		<!-- 每天步数 -->
		<!-- <view class="box1">
			<div class="icon_down" @click="openCalendar">
				<u-icon name="arrow-down" color="#000" size="16"
				label="日历" labelPos = "left"></u-icon>
			</div>
			<u-calendar :show="show" :mode="mode" @confirm="confirm" @close="closeCalendar"
			:maxDate="maxDate" :minDate = "minDate" title="选择日期">
			</u-calendar>
		</view> -->
		<view class="box2"> 
			<div class="stepNumber">
				<p>步数</p>
				<p><span>{{theFirst}}</span>/6000步</p>
			</div>
			<div class="circle">
				<circle-progress activeColor="#52CF93" borderWidth="20" :percent="percent">{{percent}}%</circle-progress>
			</div>
		</view>
		<!-- <view class="box3">
			<div class="box3-small1">
				<p>{{strength}}</p>
				<p>30<span class="small">分钟</span></p>
				<p><u-tag text="充足" type="success" plain plainFill></u-tag></p>
			</div>
			<div class="box3-small2">
				<p>消耗</p>
				<p>7645<span class="small">千卡</span></p>
				<p><u-tag text="不足" type="error" plain plainFill></u-tag></p>
			</div>
		</view> -->
		<view class="box4"> 
			<p>30天内情况统计</p>
			<div class="count">
				<div>
					<p>日均</p>
					<p><span>{{isNaN(tongJi.average) ? 0 : tongJi.average}}</span>步</p>
				</div>
				<div>
					<p>达标天数</p> 
					<p><span>{{tongJi.reach}}</span>天</p>
				</div>
			</div>
		</view>
		<view class="box5">
			<p>文字建议</p>
			<p class="suggest">{{getSuggest}}</p>
		</view>
	</view>
	<!-- <unicloud-db v-slot:default="{data, loading, error, options}" collection="steps">
		<view v-if="error">{{error.message}}</view>
		<view v-else>
			{{data}}
		</view>
	</unicloud-db> -->
	<view>
	</view>
	</view>
</template>

<script>
	import circleProgress from '@/components/ar-circle-progress/index.vue'
	// import {addStep} from '../../../config/measure.js'
	// import {getFormatTime} from '../../../config/formData.js'
	import SOtime from '@/js_sdk/fl-SOtime/SOtime.js'
	const d = new Date()
	const year = d.getFullYear()
	let month = d.getMonth() + 1
	// month = month < 10 ? `0${month}` : month
	let minmonth = month < 3 ? (month+12-2) : (month-2)
	let minyear = minmonth >= 11 ? year-1 : year
	const date = d.getDate()
	export default {
		props: ['thirtyData', 'count', 'theFirst'],
		data() {
			return {
				show: false,
				mode: 'single',
				maxDate: `${year}-${month}-31`,
				minDate: `${minyear}-${minmonth}-01`,
				// 选中的日期
				selectDate: null,
				strength: "中高强度",
				resultData: {
					step: 3000,
				},
				suggest: ['今天运动量较小，请多多运动', '今天运动量良好，请继续保持','今天运动量较大，请好好休息']
			}
		},
		onload(){
		},
		computed: {
			percent: function(){
				if(this.theFirst >=6000)
					return 100;
				else if(this.theFirst == 0)
					return 0;
				else
					return Number((this.theFirst/60).toFixed(0))
			},
			tongJi: function(){
				let average = 0;
				let reach = 0;
				for(let i = 0; i < this.count; i++)
				{
					average = this.thirtyData[i].step + average;
					if(this.thirtyData[i].step >= 6000)
						reach = reach + 1;
				}
				average = (average/this.count).toFixed(0);
				return {average, reach}
			},
			getSuggest(){
				if(this.theFirst < 6000)
					return this.suggest[0]
				else if(this.theFirst < 20000) 
					return this.suggest[1]
				else
					return this.suggest[2]
			}
		},
		components:{
			circleProgress
		},
		onLoad() {
			// console.log(this.maxDate)
			// console.log(this.minDate)
			// console.log(date)
			console.log(this.vuex_uid)
			// this.addStep()
			// this.removeStep()
			// console.log(getFormatTime(1653318790715))
			console.log(SOtime.time3(1593790157203)) // 2019-11-11 12:01
			console.log(SOtime.time4('2019-11-11 12:01')) // 1593790157203
			console.log(SOtime.time3(1593790157203) == SOtime.time4('2019-11-11 12:01')) // 1593790157203
			console.log(new Date(1593790157203).getMonth()) // 2019-11-11 12:01
			console.log(Date.now()) // 2019-11-11 12:01
			// this.updateStep()
			this.lookSteps()
		},
		methods: {
			confirm(e) {
				this.selectDate = e[0];
				console.log(this.selectDate);
				this.show = false
			},
			closeCalendar(){
				this.show = false
			},
			openCalendar() {
				this.show = true
			},
			// 增加步数			
			addStep(){
				const db = uniCloud.database() //代码块为cdb
				const dateData = SOtime.time3(Date.now()).substring(0,11)
				const data = {
					user_id: this.vuex_uid,  
					date: dateData,
					step: 16000,
				}
				console.log(dateData)
				db.collection('steps').add(data) 
				.then(e=>{
					console.log(e)
				}).catch((err) => {
						console.log( err.message )
					})
			},
			removeStep(){
				const db = uniCloud.database();
				db.collection("steps").doc("628b9507302d9f00018f6f6a").remove()
					.then((res) => {
						console.log("删除成功");
					})
					.catch((err) => {
						console.log( err.message )
					})
			},
			updateStep(){
				const db = uniCloud.database();
				db.collection("steps").where({
				  date: '2022-05-24 00:02'
				}).update({step: 8000})
					.then((res) => {
						console.log("更新成功");
					})
					.catch((err) => {
						console.log( err.message )
					})
			},
			lookSteps(){
				const db = uniCloud.database();
				const dbCmd = db.command
				db.collection('steps').where({user_id : this.vuex_uid, step: dbCmd.gte(6000)}).get().then((res) => {
						console.log(res.result.data[0].step)
					})
					.catch((err) => {
						console.log( err.message )
					})
			}
		}
	}
</script>

<style lang="less" scoped>
	.measureMain{
		background-color: rgba(248, 250, 253, 100);
		// height: calc(100vh - 700rpx);
	}
	.box2, .box3-small1, .box3-small2, .box4, .box5{
		background-color: #fff;
		border: 1px solid rgba(207, 232, 232, 100);
		border-radius: 10px 10px 10px 10px;
		margin-bottom: 34rpx;
	}
	.bigBox{
		width: 692rpx;
		margin: 0 auto;
		padding-top: 34rpx;
		.box1{
			text-align: center;
			margin-bottom: 34rpx;
			.icon_down{
				display: inline-block;
			}
		}
		.box2{
			height: 272rpx;
			position: relative;
			.stepNumber{
				margin-left: 42rpx;
				margin-top: 68rpx;
				p:nth-of-type(1){
					color: rgba(16, 16, 16, 0.42);
					font-size: 28rpx;
					width: 112rpx;
					height: 40rpx;
					margin-bottom: 12rpx;
				}
				p:nth-of-type(2){
					color: #000;
					font-size: 40rpx;
					span{
						font-size: 72rpx;
						display: inline-block;
						margin-right: 10rpx;
					}
				}
			}
			.circle{
				position: absolute;
				top: 40rpx;
				right: 50rpx;
			}
		}
		// .box3{
		// 	div{
		// 		width: 296rpx;
		// 		height: 186rpx;
		// 		padding-left: 34rpx;
		// 		// border: 1px solid black;
		// 		display: inline-block;
		// 		position: relative;
		// 		p:nth-of-type(1){
		// 			color: rgba(16, 16, 16, 0.42);
		// 			font-size: 28rpx;
		// 			width: 112rpx;
		// 			height: 40rpx;
		// 			margin-top: 26rpx;
		// 		}
		// 		p:nth-of-type(2){
		// 			color: #101010;
		// 			font-size: 40rpx;
		// 				height: 58rpx;
		// 			margin-top: 12rpx;
		// 			// margin-top: 25rpx;
		// 		}
		// 		p:nth-of-type(3){
		// 			width: 100rpx;
		// 			height: 56rpx;
		// 			position: absolute;
		// 			top: 78rpx;
		// 			// top: 26rpx;
		// 			right: 24rpx;
		// 		}
		// 	}
		// 	.box3-small2{
		// 		float: right;
		// 	}
		// }
		.box4{
			width: 688rpx;
			height: 260rpx;
			// padding-left: 44rpx;
			p:nth-of-type(1){
				color: rgba(16, 16, 16, 0.42);
				font-size: 28rpx;
				width: 300rpx;
				height: 40rpx;
				margin-top: 30rpx;
				margin-left: 44rpx;
			}
			.count{
				font-size: 28rpx;
				margin-left: 44rpx;
				div{
					width: 49%;
					float: left;
					// margin-top: 20rpx;
					p:nth-of-type(1){
					color: #000;
					margin-left: 0rpx;
					}
					p:nth-of-type(2){
						color: #000;
						span{
							font-size: 60rpx;
							display: inline-block;
							margin-right: 10rpx;
						}
					}
				}
			}
		}
		.box5{
			height: 170rpx;
			p:nth-of-type(1){
				color: rgba(16, 16, 16, 0.42);
				font-size: 28rpx;
				width: 112rpx;
				height: 40rpx; 
				margin: 30rpx 0 20rpx 42rpx;
			}
			.suggest{
				margin-left: 42rpx;
			}
		}
	}
	.small{
		font-size: 28rpx;
	}
</style>
