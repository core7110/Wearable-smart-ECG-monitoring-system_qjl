<template>
	<view class="main">
		<ul class="select">
			<li :class="{show: isShow}" @click="isShowResult">最新结果</li>
			<li :class="{show: !isShow}" @click="isShowHistory">历史结果</li>
		</ul>
		<measure v-if="isShow" :thirtyData="thirtyData" :count="count" :theFirst = "theFirst"></measure>
		<history v-if="!isShow" :thirtyData="thirtyData"></history>
	</view>
</template>

<script>
	import measure from "@/pages/health/steps/measure.vue"
	import history from "@/pages/health/steps/history.vue"
	// import SOtime from '@/js_sdk/fl-SOtime/SOtime.js'
	export default {
		data() {
			return {
				isShow: true,
				StepData: null,
				thirtyData: null,
				count: 0,
				theNew: null,
				theFirst: 0
			}
		},
		components:{
			measure,
			history
		},
		onLoad() {
			// this.lookStepsList()
			this.lookThirtyData()
			this.getNew()
			// const moreData = [
			// 		{
			// 			user_id: this.vuex_uid,  
			// 			date: '2022-06-09',
			// 			step: 1000,
			// 		},
			// 		{
			// 			user_id: this.vuex_uid,  
			// 			date: '2022-06-10',
			// 			step: 8000,
			// 		},
			// 		{
			// 			user_id: this.vuex_uid,  
			// 			date: '2022-06-11',
			// 			step: 21000,
			// 		}	
			// 	]
			// const dateData = SOtime.time3(Date.now()).substring(0,11)
			// const todayData = {
			// 		user_id: this.vuex_uid,
			// 		date: dateData,
			// 		step: 8000,
			// 	}
			// this.theFirst = todayData.step;
			// this.addStep(moreData[0])
			// this.addStep(moreData[1])
			// this.addStep(moreData[2])
			// this.addStep(todayData)
			
		},
		methods: {
			isShowResult(){
				this.isShow = true
			},
			isShowHistory(){
				this.isShow = false
			},
			async lookThirtyData(){
				const db = uniCloud.database();
				const dbCmd = db.command
				let res = await db.collection('steps').where({user_id : this.vuex_uid})
				.orderBy("date_now", "desc").limit(30).get()
						this.thirtyData = res.result.data;
						this.count = this.thirtyData.length;
			},
			async getNew(){

				const db = uniCloud.database() //代码块为cdb
				const dbCmd = db.command
				let res = await db.collection('steps').where({user_id : this.vuex_uid})
				.orderBy("date_now", "desc").limit(1).get()
				this.theFirst = res.result.data[0].step;
			},
			// 增加步数
			async addStep(data){
				const db = uniCloud.database() //代码块为cdb
				const dbCmd = db.command
				let res = await db.collection('steps').where({user_id : this.vuex_uid, date: data.date})
				.orderBy("date_now", "desc").limit(1).get()
				this.theNew = res.result.data[0];
				// const dateData = SOtime.time3(Date.now()).substring(0,11)
				// const data = {
				// 	user_id: this.vuex_uid,  
				// 	date: dateData,
				// 	step: 8000, 
				// }				
				if(this.theNew){
					console.log(this.theNew)
					if(this.theNew.date == data.date){
						db.collection("steps").where({
							user_id : this.vuex_uid,
						  date: data.date
						}).update({step: data.step})
							.then((res) => {
								console.log("更新成功");
							})
							.catch((err) => {
								console.log( err.message )
							})
					}else{
						db.collection('steps').add(data)
						.then(e=>{
							console.log(e)
						}).catch((err) => {
								console.log( err.message )
							})
					}
				}else{
					db.collection('steps').add(data)
					.then(e=>{
						console.log(e)
					}).catch((err) => {
							console.log( err.message )
						})
				}
				
			},
		}
	}
</script>

<style lang="less" scoped>
	.main{
			background-color: rgba(248, 250, 253, 100);
			// height: calc(100vh - 88rpx);
			height: calc(100vh);
			.select{
				padding: 40rpx 0 0 90rpx;
				height: 90rpx;
				border-top: 1px solid #BBBBBB;
				background-color: #fff;
				li{
					list-style-type: none;
					float: left;
					width: 160rpx;
					height: 52rpx;
					text-align: center;
					margin-right: 40rpx;
					font-size: 18px;
				}
			}
		}
		.show{
			border-bottom: 8rpx solid #FF7875;
		}
	// .articleMain {
	// 	width: 95%;
	// 	margin: 20rpx auto 40rpx;
	// 	// border: 1px solid black;
	// 	padding: 0;
	
	// 	li {
	// 		list-style-type: none;
	// 		height: 260rpx;
	// 		// padding: 20rpx;
	// 		box-shadow: 0 0 10rpx rgba(0, 0, 0, .2);
	// 		background-color: #fff;
	// 		border-radius: 10rpx;
	// 		position: relative;
	// 		margin-bottom: 40rpx;
	
	// 		.iamge {
	// 			width: 200rpx;
	// 			height: 200rpx;
	// 			margin: 30rpx 40rpx 30rpx 30rpx;
	// 			display: inline-block;
	// 		}
	
	// 		.text {
	// 			display: inline-block;
	// 			width: 400rpx;
	// 			position: relative;
	// 			top: -26rpx;
	// 			color: #404040;
	
	// 			p:nth-of-type(1) {
	// 				width: 400rpx;
	// 				word-wrap: break-word;
	// 				text-overflow: ellipsis;
	// 				display: -webkit-box;
	// 				-webkit-line-clamp: 1;
	// 				/* 限制在一个块元素显示的文本的行数 */
	// 				-webkit-box-orient: vertical;
	// 				/* 垂直排列 */
	// 				overflow: hidden;
	// 				// height: 44.8rpx;
	// 				font-size: 34rpx;
	// 				margin-bottom: 20rpx;
	// 			}
	
	// 			p:nth-of-type(2) {
	// 				margin-bottom: 15rpx;
	
	// 				.tag {
	// 					display: inline-block;
	// 					margin-left: 20rpx;
	// 					color: #aaa0a0;
	// 				}
	// 			}
	
	// 			// p:nth-of-type(3){
	// 			// 	width: 100rpx;
	// 			// 	height: 56rpx;
	// 			// 	position: absolute;
	// 			// 	bottom: 50rpx;
	// 			// 	right: 60rpx;
	// 			// }
	// 			p:nth-of-type(3) {
	// 				color: #aaa0a0;
	// 				// font-size: rpx;
	// 			}
	// 		}
	
	// 		.right {
	// 			width: 50rpx;
	// 			height: 50rpx;
	// 			position: absolute;
	// 			right: 20rpx;
	// 			bottom: 45rpx;
	
	// 		}
	// 	}
	// }
</style>
