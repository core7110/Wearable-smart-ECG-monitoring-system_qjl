<template>
  <view class="container">
    <!-- 标题栏 -->
    <view class="header">
      <text class="title">DeepSeek 智能助手</text>
    </view>
    
    <!-- 聊天内容区域 -->
    <scroll-view 
      class="chat-container" 
      scroll-y="true" 
      :scroll-with-animation="true"
      :scroll-top="scrollTop"
    >
      <view 
        v-for="(message, index) in messages" 
        :key="index" 
        :class="['message', message.role]"
      >
        <image 
          v-if="message.role === 'assistant'" 
          class="avatar" 
          src="/static/icons/ai-avatar.png"
        />
        <image 
          v-else 
          class="avatar" 
          src="/static/icons/user-avatar.png"
        />
        <view class="content">
          <text class="text">{{ message.content }}</text>
        </view>
      </view>
      <view v-if="loading" class="message assistant">
        <image class="avatar" src="/static/icons/ai-avatar.png" />
        <view class="content">
          <text class="text">思考中...</text>
        </view>
      </view>
    </scroll-view>
    
    <!-- 输入框区域 -->
    <view class="input-area">
      <textarea 
        class="input" 
        v-model="inputMessage" 
        placeholder="输入您的问题..." 
        :adjust-position="true"
        :show-confirm-bar="false"
        @confirm="sendMessage"
      />
      <button 
        class="send-btn" 
        :disabled="!inputMessage.trim() || loading" 
        @click="sendMessage"
      >
        <image class="send-icon" src="/static/icons/send-icon.png" />
      </button>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      inputMessage: '',
      loading: false,
      scrollTop: 0,
      messages: [
        {
          role: 'assistant',
          content: '你好！我是DeepSeek助手，有什么可以帮您的吗？'
        }
      ]
    }
  },
  methods: {
    async sendMessage() {
      if (!this.inputMessage.trim() || this.loading) return
      
      const userMessage = {
        role: 'user',
        content: this.inputMessage.trim()
      }
      this.messages.push(userMessage)
      this.inputMessage = ''
      this.loading = true
      
      try {
        this.scrollToBottom()
        
        const response = await this.callDeepSeekAPI(this.messages)
        
        const assistantMessage = {
          role: 'assistant',
          content: response.choices[0].message.content
        }
        this.messages.push(assistantMessage)
      } catch (error) {
        console.error('API调用失败:', error)
        uni.showToast({
          title: error.message || '请求失败，请重试',
          icon: 'none'
        })
      } finally {
        this.loading = false
        this.scrollToBottom()
      }
    },
    
    async callDeepSeekAPI(messages) {
      try {
        // 获取CSRF token（确保Django设置了CSRF_COOKIE）
        const csrfToken = this.getCookie('csrftoken') || ''
        
        const res = await uni.request({
          url: 'http://127.0.0.1:8000/hello_gpt/',
          method: 'POST',
          data: {
            messageHistory: JSON.stringify(messages)
          },
          header: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRFToken': csrfToken
          }
        })
        
        if (res[1].statusCode !== 200) {
          throw new Error(res[1].data.error || `请求失败: ${res[1].statusCode}`)
        }
        
        return {
          choices: [{
            message: res[1].data.message
          }]
        }
      } catch (error) {
        throw new Error(`API请求错误: ${error.message}`)
      }
    },
    
    getCookie(name) {
      // 简单实现获取cookie，实际项目中可能需要更完善的实现
      const cookies = document.cookie.split(';')
      for (let cookie of cookies) {
        const [key, value] = cookie.trim().split('=')
        if (key === name) return decodeURIComponent(value)
      }
      return ''
    },
    
    scrollToBottom() {
      this.$nextTick(() => {
        setTimeout(() => {
          this.scrollTop = 99999
        }, 100)
      })
    }
  }
}
</script>

<style lang="scss">
/* 样式保持不变，与之前相同 */
.container {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background-color: #f5f5f5;
}

.header {
  padding: 20rpx;
  background-color: #3498db;
  color: white;
  text-align: center;
  
  .title {
    font-size: 36rpx;
    font-weight: bold;
  }
}

.chat-container {
  flex: 1;
  padding: 20rpx;
  overflow-y: auto;
}

.message {
  display: flex;
  margin-bottom: 30rpx;
  
  &.user {
    flex-direction: row-reverse;
    
    .content {
      background-color: #3498db;
      color: white;
      border-radius: 20rpx 20rpx 0 20rpx;
    }
  }
  
  &.assistant {
    .content {
      background-color: white;
      color: #333;
      border-radius: 20rpx 20rpx 20rpx 0;
    }
  }
  
  .avatar {
    width: 80rpx;
    height: 80rpx;
    border-radius: 50%;
    margin: 0 20rpx;
  }
  
  .content {
    max-width: 70%;
    padding: 20rpx;
    box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
    
    .text {
      font-size: 32rpx;
      line-height: 1.5;
    }
  }
}

.input-area {
  display: flex;
  align-items: center;
  padding: 20rpx;
  background-color: white;
  border-top: 1rpx solid #eee;
  
  .input {
    flex: 1;
    height: 80rpx;
    padding: 10rpx 20rpx;
    background-color: #f9f9f9;
    border-radius: 40rpx;
    font-size: 32rpx;
  }
  
  .send-btn {
    width: 80rpx;
    height: 80rpx;
    margin-left: 20rpx;
    background-color: #3498db;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0;
    
    &[disabled] {
      background-color: #ccc;
    }
    
    .send-icon {
      width: 40rpx;
      height: 40rpx;
    }
  }
}
</style>