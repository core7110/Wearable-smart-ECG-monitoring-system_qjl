<template>
	<view class="bigBox">
		<view class="top">
			<view class="myimg">
				<image src="https://z3.ax1x.com/2021/11/18/IIaue1.png" mode=""></image>
			</view>
			<view class="mytext">
				提交成功
			</view>
			<view class="mydetail">
				您的申请已经提交，正在等待医生审核
			</view>
		</view>
		<view class="button_box">
			<button @click="goSigned" class="button_1" type="default">查看签约进度</button>
			<button @click="goHome" class="button_2" type="default">返回首页</button>
		</view>
	</view>
</template>

<script>
	export default {
		data(){
				return{
					
				}
		},
		methods:{
			goSigned() {
				uni.redirectTo({
					url: `/pages/my/signed?name=${this.username}`
				});
			},
			goHome() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			}
		}
	}
</script>

<style scoped>
	.bigBox{
		width: 100%;
		height: 600px;
		background-color: #F7FAFD;
	}
	.top{
		width: 100%;
		height: 170px;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	.myimg{
		width: 50px;
		height: 50px;
		overflow: hidden;
		padding: 0;
		margin: 10px 0;  
	}
	.myimg>image{
		width: 50px;
		height: 50px;
	}
	.mytext{
		width: 100%;
		height: 20px;
		text-align: center;
		font-size: 20px;
		margin: 10px 0;
	}
	.mydetail{
		width: 100%;
		height: 20px;
		text-align: center;
		font-size: 13px;
		color: #999999;
		margin: 10px 0;
	}
	.center{
		width: 100%;
		height: 200px;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	.center button{
		width: 90%;
		/* height: 60px; */
		margin: 0 5%;
		border-radius: 5px;
		margin: 10px 0;
		/* line-height: 60px; */
	}
	.button_1 {
		background-color: #2984F8;
		color: rgb(255, 255, 255);
		width: 335px;
		height: 44px;
		box-shadow: rgb(41 132 248 / 30%) 0px 5px 30px;
		border-radius: 8px;
	}
	
	.button_2 {
		margin-top: 50rpx;
		border-color: rgb(204, 204, 204);
		background-color: rgba(255, 255, 255, 0);
		box-shadow: rgb(41 132 248 / 30%) 0px 5px 30px;
		border-radius: 8px;
		width: 335px;
		height: 44px;
		color: rgb(0, 110, 241);
	}
</style>
