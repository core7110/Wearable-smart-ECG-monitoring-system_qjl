<template>
	<view class="contract_box">
		<view class="top">
			<view class="top_box">
				<view class="top_first">
					<view class="img_box">
						<image class="top_img" mode="scaleToFill"></image>
					</view>
					<view class="xinxi">
						<view class="name">
							刘老师
						</view>
						<view class="sex">
							<text>男</text>
							<text></text>
						</view>
					</view>
					<button @click="changeInfo" class="top_button" type="default">个人信息</button>
				</view>
				<view class="number font">
					身份证号<text>61052820011016115</text>
				</view>
				<view class="tel font">
					联系电话<text>13772117153</text>
				</view>
				<view class="adress font">
					家庭住址<text>陕西省西安市长安区</text>
				</view>
			</view>
		</view>
		<view class="content">
			<view class="content_tab">
				<view class="tab_left">
					医院名称
				</view>
				<view class="tab_right">
					{{teamdetail.mechanism}}
				</view>
			</view>
			<view class="content_tab">
				<view class="tab_left">
					预约团队
				</view>
				<view class="tab_right">
					{{teamdetail.name}}
				</view>
				<u-icon @click="changeTeam" class="icon" type="arrowright" color="#9C9C9C" size="15"></u-icon>
			</view>
			<view class="content_tab">
				<view class="tab_left">
					预约医生
				</view>
				<view class="tab_right">
					{{doctorDetail.name}}
				</view>
			</view>
			<view class="content_tab">
				<view class="tab_left">
					服务包
				</view>
				<view class="tab_right">
					{{package}}
				</view>
				<u-icon @click="changePackage" class="icon" type="arrowright" color="#9C9C9C" size="15"></u-icon>
			</view>
			<view class="content_tab">
				<view class="tab_left">
					预约时间
				</view>
				<view class="tab_right">
					2022/05/20
				</view>
			</view>
			<view class="content_tab">
				<view class="tab_left">
					费用
				</view>
				<view class="tab_right red">
					￥{{package | priceFilters}}
				</view>
			</view>
		</view>
		<checkbox-group @change="checkboxChange">
			<label>
				<view class="labie">
					<checkbox @change="checkboxChange" class="check" :checked="isCheak" /><text
						class="yuedu">我已阅读并同意<text class="xieyi">《小医智汇签约协议》</text></text>
				</view>
			</label>
		</checkbox-group>
		<view class="buttom_botton" @click="submit">
			<button type="default" class="button" @click="contract">申请预约</button>
		</view>
	</view>
</template>

<script>
	export default {
		name: "contract",
		data() {
			return {
				doctorDetail: {},
				lastDetail: {},
				teamdetail: {},
				teamList: ['李云龙团队', '王天弋团队', '高晓松团队'],
				package: "基础包",
				packageList: ['基础包', '老人服务包', '0-6岁儿童服务包'],
				isCheak: false,
				myinfo: [],
				showinfo: [],
				useList: [],
				myname: ""
			}
		},
		onLoad(option) {
			// #ifdef APP-NVUE
			const eventChannel = this.$scope.eventChannel; // 兼容APP-NVUE
			// #endif
			// #ifndef APP-NVUE
			const eventChannel = this.getOpenerEventChannel();
			// #endif
			// 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
			eventChannel.on('acceptDataFromOpenerPage', (data) => {
				this.doctorDetail = data.data[0];
				this.lastDetail = data.data[1];
				this.teamdetail = data.data[2];
				// console.log(this.doctorDetail);
				// console.log(this.teamdetail);
				// console.log(this.lastDetail);
			});
			this.myname = option.name;

			try {
				const value = uni.getStorageSync('myinfo');
				if (value) {
					this.myinfo = value;
					if (this.myname != undefined) {
						this.myinfo.forEach((item, index) => {
							if (item.username == this.myname) {
								this.showinfo = item
							}
						})
					} else {
						this.showinfo = this.myinfo[0];
					}
					this.myinfo.forEach((item, index) => {
						this.useList.push(item.username)
					})
					// console.log(this.myinfo);
					// console.log(this.showinfo);
					// console.log(this.useList);
				}
			} catch (e) {
				// error
			}
		},
		methods: {
			changeInfo() {
				uni.showActionSheet({
					itemList: this.useList,
					itemColor: "#188CF5",
					success: (res) => {
						this.showinfo = this.myinfo[res.tapIndex]
					},
					fail: (res) => {
						console.log(res.errMsg);
					}
				});
			},
			changeTeam() {
				uni.showActionSheet({
					itemList: this.teamList,
					itemColor: "#188CF5",
					success: (res) => {
						this.teamdetail.name = this.teamList[res.tapIndex]
					},
					fail: (res) => {
						console.log(res.errMsg);
					}
				});
			},
			changePackage() {
				uni.showActionSheet({
					itemList: this.packageList,
					itemColor: "#188CF5",
					success: (res) => {
						this.package = this.packageList[res.tapIndex]
					},
					fail: (res) => {
						console.log(res.errMsg);
					}
				});
			},
			checkboxChange(e) {
				this.isCheak = !this.isCheak;
				// console.log(this.isCheak);
			},
			getTime() {
				let date = new Date(),
					year = date.getFullYear(),
					month = date.getMonth() + 1,
					day = date.getDate(),
					hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours(),
					minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes(),
					second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
				month >= 1 && month <= 9 ? (month = "0" + month) : "";
				day >= 0 && day <= 9 ? (day = "0" + day) : "";
				let timer = year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
				return timer;
			},
			submit() {
				if (!this.isCheak) {
					uni.showModal({
						content: '请勾选签约协议',
						success: function(res) {
							if (res.confirm) {
								console.log('用户点击确定');
							} else if (res.cancel) {
								console.log('用户点击取消');
							}
						}
					});
				} else {
					uni.showModal({
						content: '签约申请提交后不可更改，确认提交吗？',
						success: (res) => {

							// console.log(this.myinfo);
							uni.setStorageSync('myinfo', this.myinfo);
							//跳转页面
							uni.redirectTo({
								url: '../success/success'
							});
						}
					});
				}
			}
		},
		filters: {
			sexFilters(i) {
				switch (i) {
					case "0":
						return '男';
					case "1":
						return '女';
				}
			},
			priceFilters(i) {
				switch (i) {
					case "基础包":
						return '0';
					case "老人服务包":
						return '120';
					case "0-6岁儿童服务包":
						return '120';
				}
			}
		}
	}
</script>

<style scoped>
	.top {
		background-color: #dbfde6;
		padding: 35rpx;
	}

	.top_box {
		background-color: #3ba88e;
		box-shadow: rgb(41 132 248 / 30%) 0px 5px 30px;
		border-radius: 12px;
		padding: 25rpx;
		color: white;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
	}

	.top_first {
		display: flex;
		position: relative;
	}

	.img_box {
		width: 56px;
		height: 56px;
		overflow: hidden;
		border-radius: 8px;
	}

	.top_img {
		width: 56px;
		height: 56px;
	}

	.xinxi {
		margin-left: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
	}

	.name {
		font-size: 20px;
	}

	.sex {
		font-size: 12px;
		color: #D4E6FE;
	}

	.sex>text:nth-of-type(1) {
		margin-right: 10rpx;
	}

	.top_button {
		border-width: 0px;
		position: absolute;
		top: 10rpx;
		right: 10rpx;
		width: 79px;
		height: 24px;
		font-size: 12px;
		color: #3ba88e;
		box-shadow: rgb(41 132 248 / 30%) 0px 5px 30px;
		border-radius: 32px;
		background-color: #FFFFFF;
		line-height: 24px;
	}

	.font {
		font-size: 12px;
		color: #D4E6FE;
		margin-top: 20rpx;
	}

	.font>text {
		margin-left: 20rpx;
	}

	/* 选项卡部分 */
	.content {
		background-color: #FFFFFF;
		display: flex;
		flex-direction: column;
		padding: 0 40rpx;
	}

	.content_tab {
		display: flex;
		font-size: 14px;
		height: 44px;
		line-height: 44px;
		position: relative;
		border-bottom: 1px solid #F2F2F2;
	}

	.tab_left {
		color: #B39999;
		width: 140rpx;
	}

	.tab_right {
		margin-left: 30rpx;
	}

	.icon {
		position: absolute;
		top: 3px;
		right: 5px;
	}

	.red {
		color: red;
	}

	/* 勾选 */
	.labie {
		margin-top: 20rpx;
		margin-left: 20rpx;
		background-color: #FFFFFF;
	}

	.check {
		transform: scale(0.6);
	}

	.yuedu {
		color: #C9C9C9;
		font-size: 13px;
	}

	.xieyi {
		color: #3ba88e;
		font-size: 13px;
	}

	/* 底部按钮 */
	.buttom_botton {
		background-color: #FFFFFF;
		height: 160rpx;
		text-align: center;
		line-height: 160rpx;
		position: sticky;
		bottom: 0;
	}

	.button {
		width: 335px;
		height: 44px;
		color: white;
		position: absolute;
		top: calc(50% - 22px);
		left: calc(50% - 167.5px);
		background-color: #3ba88e;
		border-radius: 8px;
	}
</style>
