<template>
  <view> <!-- 根元素 -->
    <view class="custom-navbar" :style="navbarStyle">
      <view class="navbar-title">心 安</view> <!-- 使用艺术字体 -->
    </view>

    <view class="content">
      <!-- 搜索框 -->
      <view class="search-container">
        <u-search 
          placeholder="医院/医生" 
          v-model="keyword"
          @focus="isActive=true" 
          @blur="isActive=false"
          @confirm="onConfirm"
        ></u-search>
        <image src="../../static/chicken.gif" mode="" class="search-icon" 
          :class="isActive?'active':''"></image>
      </view>
      <!-- 顶部轮播 -->
      <u-swiper class="mySwiper" :list="list" previousMargin="30" nextMargin="30" circular :autoplay="true" :interval="3000" radius="5" height="150" bgColor="#ffffff" :indicator="true" @click="clickItem">
      </u-swiper>
      <!-- 功能模块 -->
      <view class="u-demo-block">
        <view class="u-demo-block__content">
          <u-row customStyle="margin-bottom: 10px">
            <!-- 健康数据 -->
            <u-col span="6">
              <div class="demo-layout health" @click="jmpHeartRate">
                <p class="tipText">健康数据</p>
                <p class="smallText">查看健康指标</p>
                <image src="../../static/images/health.png" mode="" class="tipImage"></image>
              </div>
            </u-col>
            <!-- 预约医生 -->
            <u-col span="6">
              <div class="demo-layout steps" @click="jmpStep">
                <p class="tipText">预约医生</p>
                <p class="smallText">在线预约医生</p>
                <image src="../../static/icon/center-active.png" mode="" class="tipImage"></image>
              </div>
            </u-col>
          </u-row>
          <u-row customStyle="margin-bottom: 10px">
            <!-- AI助手 -->
            <u-col span="6">
              <div class="demo-layout plans" @click="jmpAI">
                <p class="tipText">AI助手</p>
                <p class="smallText">智能健康咨询</p>
                <image src="../../static/images/my/shezhi.png" mode="" class="tipImage"></image>
              </div>
            </u-col>
            <!-- 地图导航 -->
            <u-col span="6">
              <div class="demo-layout navigation" @click="jmpMapNavigation">
                <p class="tipText">地图导航</p>
                <p class="smallText">快速导航就医</p>
                <image src="../../static/icon/treamentLocate.png" mode="" class="tipImage"></image>
              </div>
            </u-col>
          </u-row>
        </view>
      </view>
      <!-- 附近就医 -->
      <div class="nearHospital" @click="jmpHospital">
        <p>附近寻医</p>
        <p>健康体检</p>
        <p>路线导航</p>
      </div>
    </view> <!-- 内容闭合 -->
  </view> <!-- 根元素闭合 -->
</template>

<script>
	import {
		getArticle, // 导入获取文章数据的API方法
	} from '@/config/api.js' // 从api.js文件中导入getArticle方法
	import SOtime from '@/js_sdk/fl-SOtime/SOtime.js' // 导入SOtime工具，用于处理时间
	let _this; // 定义一个全局变量_this，用于保存当前Vue实例

	export default {
		data() {
			return {
				isActive: false, // 控制搜索图标动画
				isShow: false, // 控制某个元素是否显示的标志
				newData: null, // 存储获取的文章数据
				title: '你好，uniapp', // 页面标题
				nav_title: '我是导航栏', // 导航栏标题
				status_bar: true, // 是否包含状态栏
				navbarStyle: {
				        backgroundImage: "url(/static/20.png)", // 背景图片路径
				        backgroundSize: "cover", // 背景图片覆盖整个导航栏
				        backgroundPosition: "center", // 背景图片居中
				},
				list: [ // 轮播图图片列表
					'/static/11.jpg',
					'/static/9.jpg',
					'/static/10.jpg',
					'/static/12.jpg',
					'/static/8.jpg'
				],
				baseList: [{ // 功能模块列表
						name: 'hourglass', // 图标名称
						title: '步数监测', // 功能标题
						fun() { // 点击事件处理函数
							_this.jmpStep() // 跳转到步数监测页面
						}
					},
					{
						name: 'heart-fill', // 图标名称
						title: '心率检测', // 功能标题
						fun() { // 点击事件处理函数
							_this.jmpHeartRate() // 跳转到心率检测页面
						}
					},
					{
						name: 'server-man', // 图标名称
						title: '附近就医', // 功能标题
						fun() { // 点击事件处理函数
							fun: _this.jmpHospital() // 跳转到附近就医页面
						}
					}
				],
				keyword: '', // 搜索框的关键字
				articleIamge: [ // 文章图片列表
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529658134801406.png',
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529658864265309.png',
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529659461767940.png',
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529660074933715.png',
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529661797101070.png'
				],
				Mlist: [{ // 轮播图点击后的提示信息列表
				  title: "医学贴士", // 提示标题
				  content: "每日为您精选健康小贴士，涵盖养生、饮食、运动等多方面内容，助您轻松掌握健康生活小窍门。" // 提示内容
				}, {
				  title: "商务合作", // 提示标题
				  content: "欢迎各界伙伴与我们合作！合作范围包括广告投放、企业合作（校招、实习、内推、兼职等）及广告资源置换。" // 提示内容
				}, {
				  title: "健康监测", // 提示标题
				  content: "实时监测您的心率、血压等健康指标，通过蓝牙将数据同步至客户端，生成健康报告并提供专业建议，助您随时掌握身体状况。" // 提示内容
				}, {
				  title: "附近就医", // 提示标题
				  content: "一键查找附近医院及门诊，查看详细信息、距离及导航路线，助您快速找到最合适的医疗机构，轻松就医。" // 提示内容
				}, {
				  title: "紧急救援", // 提示标题
				  content: "紧急情况下，一键呼救，快速联系附近急救中心及医疗机构。提供最近的急救点信息及联系方式，为您争取宝贵时间。" // 提示内容
				}]
			}
		},
		computed:{
			isLoadingShow(){ // 计算属性，用于控制加载图标的显示
				if(!this.newData) // 如果newData为空
					return true; // 显示加载图标
				else
					return false; // 隐藏加载图标
			}
		},
    onLoad() { // 页面加载时执行
    _this = this // 将当前Vue实例赋值给_this
      // 获取首页文章数据
      this.getArticleList() // 调用获取文章列表的方法
      // 解决app首次打开,出现的bug
      let uid = this.vuex_uid // 获取当前用户的ID
      if (uid) { // 如果用户ID存在
        this.getUserInfo() // 调用获取用户信息的方法
      }
      console.log(this.newsData) // 打印newsData（此处可能有误，应为newData）
			
			const dateData = SOtime.time3(Date.now()).substring(0,11) // 获取当前日期并格式化
			const todayData = { // 定义今日步数数据
					user_id: this.vuex_uid, // 用户ID
					date: dateData, // 当前日期
					step: 8000, // 步数
				}
			this.addStep(todayData) // 调用增加步数的方法
			
    },
		methods: {
			onConfirm(e) {
				console.log(e);
				// 这里可以添加搜索确认后的逻辑
			},
			// 增加步数
			async addStep(data){ // 异步方法，用于增加步数
				const db = uniCloud.database() // 获取uniCloud数据库实例
				const dbCmd = db.command // 获取数据库命令对象
				let res = await db.collection('steps').where({user_id : this.vuex_uid, date: data.date}) // 查询步数数据
				.orderBy("date_now", "desc").limit(1).get() // 按日期倒序排列，获取最新一条数据
				this.theNew = res.result.data[0]; // 将查询结果赋值给theNew
				if(this.theNew){ // 如果查询结果存在
					console.log(this.theNew) // 打印查询结果
					if(this.theNew.date == data.date){ // 如果日期匹配
						db.collection("steps").where({ // 更新步数数据
							user_id : this.vuex_uid,
						  date: data.date
						}).update({step: data.step})
							.then((res) => { // 更新成功
								console.log("更新成功");
							})
							.catch((err) => { // 更新失败
								console.log( err.message )
							})
					}else{ // 如果日期不匹配
						db.collection('steps').add(data) // 添加新的步数数据
						.then(e=>{ // 添加成功
							console.log(e)
						}).catch((err) => { // 添加失败
								console.log( err.message )
							})
					}
				}else{ // 如果查询结果不存在
					db.collection('steps').add(data) // 添加新的步数数据
					.then(e=>{ // 添加成功
						console.log(e)
					}).catch((err) => { // 添加失败
							console.log( err.message )
						})
				}
			},
			async getUserInfo() { // 异步方法，用于获取用户信息
				let uid = this.vuex_uid // 获取当前用户的ID
				// 发送请求获取用户数据
				const loginDo = uniCloud.importObject('request') // 导入uniCloud请求对象
				const res = await loginDo.getUsers({ // 调用获取用户信息的方法
					uid,
					field: ['password'] // 请求字段
				})
				if (res.userInfo.password) { // 如果用户信息中包含密码
					this.isShow = false // 隐藏某个元素
				} else {
					this.isShow = true // 显示某个元素
				}
			},
			cancelout() { // 取消操作
				this.isShow = false // 隐藏某个元素
			},
			clickItem(e) { // 轮播图点击事件
				uni.showModal({ // 显示模态框
					title: this.Mlist[e].title, // 模态框标题
					content: this.Mlist[e].content, // 模态框内容
					mask: true, // 显示遮罩层
					showCancel: false, // 不显示取消按钮
					confirmColor: '#3ba88e' // 确认按钮颜色
				})
			},
			goPass() { // 跳转到修改密码页面
				this.isShow = false // 隐藏某个元素
				uni.navigateTo({
					url: '/pages/center/changePassbySms' // 跳转路径
				});
			},
			// 获取文章列表
			async getArticleList() { // 异步方法，用于获取文章列表
				console.log('hahaha') // 打印日志
				const id = this.vuex_uid // 获取当前用户的ID
				const {
					data
				} = await getArticle(id) // 调用获取文章数据的API方法
				const results = data.data // 获取文章数据
				this.newData = results // 将文章数据赋值给newData
				let i = 0;
				for (let j of this.newData) { // 遍历文章数据
					j.image = this.articleIamge[i]; // 为每篇文章添加图片
					i = i + 1;
				}
				console.log(results) // 打印文章数据
			},
			click(name) { // 点击事件
				this.$refs.uToast.success(`点击了第${name}个`) // 显示Toast提示
			},
			// 点击导航栏左侧
			clickNavLeft() { // 导航栏左侧点击事件
				uni.showToast({ // 显示Toast提示
					title: '点击导航栏左侧',
					duration: 1500, // 显示时长
					icon: 'none' // 不显示图标
				});
			},
			// 点击导航栏右侧
			clickNavRight() { // 导航栏右侧点击事件
				uni.showToast({ // 显示Toast提示
					title: '点击导航栏右侧',
					duration: 1500, // 显示时长
					icon: 'none' // 不显示图标
				});
			},
			// 跳转文章详情页
			handleDetail(id) { // 跳转到文章详情页
				const pid = id // 文章ID
				uni.navigateTo({
					url: '../ariticle/ariticle?id=' + encodeURIComponent(JSON.stringify(pid)) // 跳转路径
				})
			},
			// 跳转附近就医
			treat() { // 跳转到附近就医页面
				uni.navigateTo({
					url: '../treatMent/treatMent' // 跳转路径
				})
			},
			// 跳转计划
			plan() { // 跳转到计划页面
				uni.navigateTo({
					url: '/pages/plan/plan' // 跳转路径
				})
			},
			// 跳转到健康监测部分
			jmpStep() { // 跳转到步数监测页面
				uni.navigateTo({
					url: '/pages/health/steps/steps' // 跳转路径
				})
			},
			jmpHeartRate() { // 跳转到心率检测页面
				uni.navigateTo({
					url: '/pages/health/heartRate/heartRate', // 跳转路径
				})
			},
			jmpHospital() { // 跳转到附近就医页面
				uni.navigateTo({
					url: '../treatMent/treatMent' // 跳转路径
				})
			},
			jmpAI() { // 跳转到附近就医页面
				uni.navigateTo({
					url: '../AI/chat' // 跳转路径
				})
			},
      impPlan() { // 跳转到计划页面（TabBar页面）
        uni.switchTab({
          url: '/pages/plan/plan', // 跳转路径
        })
      }
		},
	}
</script>

<style lang="less" scoped>
.content {
  background-color: #fff;
}

.search-container {
  padding: 0 20rpx;
  margin-top: 20rpx;
  position: relative;
  
  .u-search {
    position: relative;
    z-index: 2;
    background: #fff;
  }
  
  .search-icon {
    width: 48rpx;
    height: 48rpx;
    z-index: 1;
    position: absolute;
    top: 10rpx;
    left: calc(50% - 24rpx);
    transition: top 0.3s;
  }
  
  .search-icon.active {
    top: -48rpx;
  }
}

.u-demo-block {
  // background-color: aliceblue;
  // border: 1px solid #e2dfde;
  margin: 40rpx 8rpx;

  .demo-layout {
    // height: 25px;
    // border-radius: 4px;
    height: 170rpx;
    position: relative;
    width: 95%;
    margin: 0 auto;
    // text-align: center;
    background-color: #fff;
    background-size: 100% 100%;

    // box-shadow: 0 0 10rpx rgba(0, 0, 0, .1);
    .tipText {
      margin: 15rpx 0 0 20rpx;
      color: rgba(255, 255, 255, 0.9);
      font-size: 38rpx;
    }

    .smallText {
      margin: 10rpx 0 0 20rpx;
      color: rgba(255, 255, 255, 0.8);
      font-size: 21rpx;
    }

    .tipImage {
      position: absolute;
      right: 20rpx;
      bottom: 20rpx;
      width: 50rpx;
      height: 50rpx;
    }
  }
  .navigation {
    background-image: url(@/static/images/backgroundSteps.png); /* 使用原图 */
    filter: brightness(1.1); /* 调暗至70%亮度（值越小越暗） */
  }
  .steps {
    background-image: url(@/static/images/backgroundSteps.png);
  }

  .health {
    background-image: url(@/static/images/backgroundHealth.png);
  }

  .plans {
    background-image: url(@/static/images/backgroundPlans.png);
  }
}

.nearHospital {
  margin: 0 auto;
  width: 95%;
  height: 250rpx;
  background-image: url(@/static/13.jpg);
  background-size: 100% 100%;
  border-radius: 10rpx;

  p:nth-of-type(1) {
    display: inline-block;
    width: 100%;
    margin: 40rpx 0 0 100rpx;
    font-size: 44rpx;
    font-weight: 600;
    color: rgba(0, 0, 0, 0.5);
  }

  p:nth-of-type(2),
  p:nth-of-type(3) {
  display: inline-block;
  width: 180rpx;
  height: 55rpx;
  border-radius: 30rpx;
  font-size: 34rpx;
  background-color: rgb(120, 216, 255); /* 浅蓝色 */
  color: rgba(255, 255, 255, 0.9);
  text-align: center;
  line-height: 55rpx;
  margin-top: 20rpx;
}

  p:nth-of-type(2) {
    margin-left: 20rpx;
    margin-right: 10rpx;
  }
}

page {
  background-color: #fff;
}

.u-line {
  margin: 0 auto !important;
}

.uni-page-wrapper {
  background-color: #f6f6f6;
}

.mySwiper {
  margin-top: 30rpx;
}

.u-grid {
  margin-top: 60rpx;
}

.u-grid-item {
  border-radius: 10%;
  width: 26% !important;
  margin: 28rpx;
  
}

.u-grid-item:hover {
  cursor: pointer;
}

.u-grid-item:nth-child(1) {
  background-color: #f56c6c !important;
}

.u-grid-item:nth-child(2) {
  background-color: #f9ae3d !important;
}

.u-grid-item:nth-child(3) {
  background-color: #5ac725 !important;
}

.infobox {
  width: 100%;
  height: 270rpx;
  margin-bottom: 10rpx;
  display: flex;
  justify-content: space-around;
}

.infobox view {
  margin-bottom: 10rpx;
}

.toutiao,
.huli {
  height: 180rpx;
  width: 40%;
  position: relative;
  background-color: #eaf3fe;
  border-radius: 10%;
  padding: 20rpx;
  margin-top: 10rpx;
}

.toutiao image {
  width: 140rpx;
  height: 120rpx;
  position: absolute;
  right: 20rpx;
  bottom: 20rpx;
}

.title2 {
  font-size: 32rpx;
  color: grey;
  margin-top: 40rpx;
}

.title3 {
  font-size: 36rpx;
  font-weight: 500;
}

.title5 {
  margin-left: 50rpx;
  display: flex;
}

.title5:hover {
  color: black;
}

.huli image {
  width: 132rpx;
  height: 76rpx;
  position: absolute;
  right: 20rpx;
  bottom: 20rpx;
}

// 没有
.fwtx {
  width: 95%;
  margin: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  margin-bottom: 10rpx;
}

.fwtempo {
  width: 96%;
  height: 240rpx;
  border-radius: 10rpx;
  background-color: white;
  margin: auto;
  margin-top: 20rpx;
  position: relative;

  box-sizing: border-box;
  box-shadow: 0 0 10rpx rgba(0, 0, 0, 0.1);
  margin-bottom: 8rpx;
}

.iconinfo {
  position: absolute;
  top: 50rpx;
  left: 50rpx;
  width: 140rpx;
  height: 140rpx;
  background-color: #fff8e4;
  text-align: center;
}

.iconinfo image {
  margin: auto;
  margin-top: 18rpx;
  width: 100%;
  height: 100%;
}

.textfw {
  width: 70%;
  height: 100rpx;
  /* background-color: #007AFF; */
  position: absolute;
  top: 50rpx;
  margin: 10rpx;
  left: 200rpx;
}

.fwpre {
  width: 32rpx;
  height: 32rpx;
  position: absolute;
  right: 20rpx;
  top: 50%;
  margin-top: -16rpx;
}

.fwpre image {
  width: 32rpx;
  height: 32rpx;
}
.custom-navbar {
  height: 44px;
  background-color: #3A8EE6; /* 蓝色背景 */
  display: flex;
  justify-content: center;
  align-items: center;
}

.navbar-title {
  font-family: 'STKaiti', '楷体', serif; /* 使用楷体作为艺术字体 */
  font-size: 20px;
  font-weight: bold;
  color: #fff; /* 白色字体 */
}
</style>