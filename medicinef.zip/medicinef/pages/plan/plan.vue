<template>
  <view class="container">
    <!-- 计划列表 -->
    <u-collapse class="collapse" @close="close" @open="open" :value="openColl">
      <!-- 活动计划 -->
      <u-collapse-item class="coll-item" title="计划集" name="1">
        <view v-if="activePlans.length === 0" class="empty-tip">
          <u-empty mode="list" text="暂无活动计划"></u-empty>
        </view>
        <view class="plan-list">
          <view 
            class="plan-item" 
            v-for="(plan, index) in activePlans" 
            :key="plan.id"
            :class="getPlanCategoryClass(plan.category)"
            @click="togglePlan(plan)"
          >
            <view class="plan-content">
              <view class="plan-name">{{ plan.name }}</view>
              <view class="plan-meta">
                <u-tag :text="plan.category" size="mini" :type="getTagType(plan.category)"></u-tag>
                <text class="reminder-time">{{ formatTime(plan.reminderTime) }}</text>
              </view>
            </view>
            <view class="plan-actions">
              <u-icon name="checkmark" size="22" color="#3ba88e" @click.stop="archivePlan(index)"></u-icon>
              <u-icon name="trash" size="22" color="#FA746B" @click.stop="deletePlan(index, false)"></u-icon>
            </view>
          </view>
        </view>
      </u-collapse-item>

      <!-- 已归档计划 -->
      <u-collapse-item title="已归档" name="2">
        <view v-if="archivedPlans.length === 0" class="empty-tip">
          <u-empty mode="list" text="暂无归档计划"></u-empty>
        </view>
        <view class="plan-list">
          <view 
            class="plan-item archived" 
            v-for="(plan, index) in archivedPlans" 
            :key="plan.id"
            @click="togglePlan(plan)"
          >
            <view class="plan-content">
              <view class="plan-name">{{ plan.name }}</view>
              <view class="plan-meta">
                <u-tag :text="plan.category" size="mini" type="info"></u-tag>
                <text class="reminder-time">{{ formatTime(plan.reminderTime) }}</text>
              </view>
            </view>
            <view class="plan-actions">
              <u-icon name="trash" size="22" color="#FA746B" @click.stop="deletePlan(index, true)"></u-icon>
            </view>
          </view>
        </view>
      </u-collapse-item>
    </u-collapse>

    <!-- 返回顶部按钮 -->
    <u-back-top :scrollTop="scrollTop" :mode="mode" :iconStyle="iconStyle"></u-back-top>

    <!-- 创建计划按钮 -->
    <view class="add-btn">
      <u-button @click="openModal" shape="circle" type="primary" class="floating-btn">
        <u-icon name="plus" color="#fff" size="28"></u-icon>
      </u-button>
    </view>

    <!-- 创建计划模态框 -->
    <u-modal 
      :show="showModal" 
      title="创建新计划"
      :showCancelButton="true"
      confirmText="创建"
      cancelText="取消"
      @confirm="createPlan"
      @cancel="closeModal"
      @close="closeModal"
    >
      <view class="modal-content">
        <!-- 计划名称 -->
        <view class="form-item">
          <text class="label">计划名称</text>
          <u--input 
            v-model="newPlan.name" 
            placeholder="请输入计划名称"
            border="bottom"
            clearable
            class="form-input"
          ></u--input>
          <text v-if="!isNameValid" class="error-tip">限1-10位字符以内</text>
        </view>

        <!-- 计划类别 -->
        <view class="form-item">
          <text class="label">计划类别</text>
          <view class="category-tags">
            <u-tag 
              v-for="(category, index) in categories"
              :key="index"
              :text="category.text"
              :type="category.selected ? 'primary' : 'info'"
              @click="selectCategory(index)"
              size="medium"
              class="category-tag"
              :customStyle="{
                marginRight: '12rpx',
                marginBottom: '12rpx'
              }"
            ></u-tag>
          </view>
          <text v-if="!newPlan.category" class="error-tip">请选择计划类别</text>
        </view>

        <!-- 提醒时间 -->
        <view class="form-item">
          <text class="label">提醒时间</text>
          <u-button 
            @click="showTimePicker = true"
            plain
            class="time-btn"
            :customStyle="{
              width: '100%',
              textAlign: 'left',
              justifyContent: 'flex-start',
              padding: '20rpx 0',
              borderBottom: '1px solid #f0f0f0'
            }"
          >
            <u-icon name="clock" size="18" style="margin-right: 8rpx;"></u-icon>
            {{ reminderTimeText }}
          </u-button>
          <u-datetime-picker 
            :show="showTimePicker"
            v-model="newPlan.reminderTime"
            mode="datetime"
            :minDate="minDate"
            @confirm="setReminderTime"
            @cancel="closeTimePicker"
          ></u-datetime-picker>
          <text v-if="!newPlan.reminderTime" class="error-tip">请选择提醒时间</text>
        </view>
      </view>
    </u-modal>
  </view>
</template>

<script>
export default {
  data() {
    return {
      // 计划数据
      plans: [],
      
      // 新建计划表单
      newPlan: {
        name: '',
        category: '',
        reminderTime: null
      },
      
      // UI状态
      showModal: false,
      showTimePicker: false,
      openColl: ['1'],
      scrollTop: 0,
      mode: 'circle',
      iconStyle: {
        fontSize: '32rpx',
        color: '#3ba88e',
      },
      
      // 计划类别
      categories: [
        { text: '运动', selected: false },
        { text: '医疗', selected: false },
        { text: '吃药', selected: false },
        { text: '心情', selected: false },
        { text: '其他', selected: false }
      ],
      
      // 最小日期（当前时间+1分钟）
      minDate: Date.now() + 60000,
      
      // 类别样式映射
      categoryStyles: {
        '运动': { class: 'sport', tagType: 'success', color: '#4CAF50' },
        '医疗': { class: 'medical', tagType: 'error', color: '#F44336' },
        '吃药': { class: 'medicine', tagType: 'warning', color: '#FF9800' },
        '心情': { class: 'mood', tagType: 'primary', color: '#2196F3' },
        '其他': { class: 'other', tagType: 'info', color: '#9E9E9E' }
      }
    }
  },
  
  computed: {
    // 活动计划
    activePlans() {
      return this.plans.filter(plan => plan.status === 'active').sort((a, b) => a.reminderTime - b.reminderTime);
    },
    
    // 已归档计划
    archivedPlans() {
      return this.plans.filter(plan => plan.status === 'archived').sort((a, b) => b.reminderTime - a.reminderTime);
    },
    
    // 计划名称验证
    isNameValid() {
      if (!this.newPlan.name) return true; // 初始状态不显示错误
      const reg = /^([\u4e00-\u9fa5]|[0-9_a-zA-Z]){1,10}$/;
      return reg.test(this.newPlan.name);
    },
    
    // 提醒时间显示文本
    reminderTimeText() {
      return this.newPlan.reminderTime 
        ? this.formatDateTime(this.newPlan.reminderTime) 
        : '选择提醒时间';
    }
  },
  
  onLoad() {
    this.loadPlans();
  },
  
  onPageScroll(e) {
    this.scrollTop = e.scrollTop;
  },
  
  methods: {
    // 加载计划
    loadPlans() {
      const savedPlans = uni.getStorageSync('plans');
      if (savedPlans && savedPlans.length > 0) {
        this.plans = savedPlans;
      } else {
        // 默认示例数据
        this.plans = [
          {
            id: 1,
            name: '晨跑30分钟',
            category: '运动',
            reminderTime: Date.now() + 86400000, // 明天
            status: 'active',
            createdAt: Date.now()
          },
          {
            id: 2,
            name: '复查体检',
            category: '医疗',
            reminderTime: Date.now() + 259200000, // 3天后
            status: 'active',
            createdAt: Date.now()
          },
          {
            id: 3,
            name: '服用维生素',
            category: '吃药',
            reminderTime: Date.now() - 86400000, // 昨天
            status: 'archived',
            createdAt: Date.now() - 172800000
          }
        ];
        this.savePlans();
      }
    },
    
    // 保存计划到本地
    savePlans() {
      uni.setStorageSync('plans', this.plans);
    },
    
    // 打开创建计划模态框
    openModal() {
      this.resetForm();
      this.showModal = true;
    },
    
    // 关闭模态框
    closeModal() {
      this.showModal = false;
    },
    
    // 重置表单
    resetForm() {
      this.newPlan = {
        name: '',
        category: '',
        reminderTime: null
      };
      this.categories.forEach(item => item.selected = false);
    },
    
    // 选择计划类别
    selectCategory(index) {
      this.categories.forEach((item, i) => {
        item.selected = i === index;
        if (i === index) {
          this.newPlan.category = item.text;
        }
      });
    },
    
    // 设置提醒时间
    setReminderTime(e) {
      this.newPlan.reminderTime = e.value;
      this.showTimePicker = false;
    },
    
    // 关闭时间选择器
    closeTimePicker() {
      this.showTimePicker = false;
    },
    
    // 创建新计划
    createPlan() {
      if (!this.validateForm()) return;
      
      const newPlan = {
        id: Date.now(), // 使用时间戳作为ID
        name: this.newPlan.name,
        category: this.newPlan.category,
        reminderTime: this.newPlan.reminderTime,
        status: 'active',
        createdAt: Date.now()
      };
      
      this.plans.unshift(newPlan);
      this.savePlans();
      
      this.showModal = false;
      uni.showToast({
        title: '计划创建成功',
        icon: 'success'
      });
      
      // 这里可以添加设置提醒的逻辑
      this.setReminderNotification(newPlan);
    },
    
    // 设置提醒通知
    setReminderNotification(plan) {
      // 在实际应用中，这里可以调用uni-app的通知API设置提醒
      console.log(`设置提醒: ${plan.name} 在 ${this.formatDateTime(plan.reminderTime)}`);
    },
    
    // 表单验证
    validateForm() {
      let isValid = true;
      
      if (!this.isNameValid) {
        uni.showToast({
          title: '请输入1-10位有效字符',
          icon: 'none'
        });
        isValid = false;
      }
      
      if (!this.newPlan.category) {
        uni.showToast({
          title: '请选择计划类别',
          icon: 'none'
        });
        isValid = false;
      }
      
      if (!this.newPlan.reminderTime) {
        uni.showToast({
          title: '请选择提醒时间',
          icon: 'none'
        });
        isValid = false;
      }
      
      return isValid;
    },
    
    // 归档计划
    archivePlan(index) {
      const planId = this.activePlans[index].id;
      const planIndex = this.plans.findIndex(p => p.id === planId);
      
      if (planIndex !== -1) {
        this.plans[planIndex].status = 'archived';
        this.savePlans();
        
        uni.showToast({
          title: '计划已归档',
          icon: 'success'
        });
      }
    },
    
    // 删除计划
    deletePlan(index, isArchived) {
      uni.showModal({
        title: '确认删除',
        content: '确定要删除这个计划吗？',
        success: (res) => {
          if (res.confirm) {
            let planId;
            if (isArchived) {
              planId = this.archivedPlans[index].id;
            } else {
              planId = this.activePlans[index].id;
            }
            
            this.plans = this.plans.filter(p => p.id !== planId);
            this.savePlans();
            
            uni.showToast({
              title: '删除成功',
              icon: 'success'
            });
          }
        }
      });
    },
    
    // 格式化日期时间显示
    formatDateTime(timestamp) {
      const date = new Date(timestamp);
      const year = date.getFullYear();
      const month = this.padZero(date.getMonth() + 1);
      const day = this.padZero(date.getDate());
      const hours = this.padZero(date.getHours());
      const minutes = this.padZero(date.getMinutes());
      
      return `${year}/${month}/${day} ${hours}:${minutes}`;
    },
    
    // 格式化时间显示（相对时间）
    formatTime(timestamp) {
      const now = Date.now();
      const diff = timestamp - now;
      const dayDiff = Math.floor(diff / (1000 * 60 * 60 * 24));
      
      if (dayDiff > 0) {
        return `${dayDiff}天后`;
      } else if (dayDiff === 0) {
        return '今天';
      } else {
        return '已过期';
      }
    },
    
    // 补零
    padZero(num) {
      return num < 10 ? `0${num}` : num;
    },
    
    // 获取计划类别样式
    getPlanCategoryClass(category) {
      return this.categoryStyles[category]?.class || 'other';
    },
    
    // 获取标签类型
    getTagType(category) {
      return this.categoryStyles[category]?.tagType || 'info';
    },
    
    // 折叠面板操作
    open(e) {
      this.openColl = [e];
    },
    
    close(e) {
      this.openColl = [];
    },
    
    // 切换计划状态
    togglePlan(plan) {
      plan.status = plan.status === 'active' ? 'archived' : 'active';
      this.savePlans();
    }
  }
}
</script>

<style lang="less" scoped>
.container {
  padding: 20rpx;
  background-color: #f8f8f8;
  min-height: 100vh;
}

.collapse {
  margin-bottom: 120rpx;
  border-radius: 16rpx;
  overflow: hidden;
  box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
}

.empty-tip {
  padding: 40rpx 0;
}

.plan-list {
  padding: 0 20rpx;
}

.plan-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 28rpx 24rpx;
  margin-bottom: 20rpx;
  border-radius: 12rpx;
  background-color: #fff;
  box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  border-left: 8rpx solid;
  
  &.sport {
    border-left-color: #4CAF50;
  }
  
  &.medical {
    border-left-color: #F44336;
  }
  
  &.medicine {
    border-left-color: #FF9800;
  }
  
  &.mood {
    border-left-color: #2196F3;
  }
  
  &.other {
    border-left-color: #9E9E9E;
  }
  
  &.archived {
    opacity: 0.7;
    background-color: #f5f5f5;
    .plan-name {
      text-decoration: line-through;
      color: #999;
    }
  }
  
  &:active {
    transform: scale(0.98);
  }
}

.plan-content {
  flex: 1;
}

.plan-name {
  font-size: 32rpx;
  font-weight: 500;
  color: #333;
  margin-bottom: 12rpx;
}

.plan-meta {
  display: flex;
  align-items: center;
  
  .reminder-time {
    font-size: 24rpx;
    color: #666;
    margin-left: 16rpx;
  }
}

.plan-actions {
  display: flex;
  align-items: center;
  
  .u-icon {
    margin-left: 24rpx;
    padding: 8rpx;
    border-radius: 50%;
    background-color: rgba(0, 0, 0, 0.03);
    
    &:active {
      background-color: rgba(0, 0, 0, 0.08);
    }
  }
}

.add-btn {
  position: fixed;
  right: 40rpx;
  bottom: 80rpx;
  z-index: 100;
  
  .floating-btn {
    width: 100rpx;
    height: 100rpx;
    border-radius: 50%;
    box-shadow: 0 8rpx 24rpx rgba(59, 168, 142, 0.3);
    background: linear-gradient(135deg, #3ba88e, #4fc1a7);
    
    &:active {
      transform: scale(0.95);
    }
  }
}

.modal-content {
  padding: 0 20rpx;
}

.form-item {
  margin-bottom: 40rpx;
  
  .label {
    display: block;
    font-size: 28rpx;
    color: #666;
    margin-bottom: 16rpx;
  }
  
  .form-input {
    padding: 20rpx 0;
  }
  
  .error-tip {
    display: block;
    font-size: 24rpx;
    color: #F44336;
    margin-top: 8rpx;
  }
}

.category-tags {
  display: flex;
  flex-wrap: wrap;
  margin-top: 16rpx;
}

.time-btn {
  margin-top: 16rpx;
}

/* 动画效果 */
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s;
}
.fade-enter, .fade-leave-to {
  opacity: 0;
}

.slide-up-enter-active, .slide-up-leave-active {
  transition: all 0.3s ease;
}
.slide-up-enter, .slide-up-leave-to {
  transform: translateY(20rpx);
  opacity: 0;
}
</style>
