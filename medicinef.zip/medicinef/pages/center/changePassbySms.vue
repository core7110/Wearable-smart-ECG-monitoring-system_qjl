<template>
	<view>
		<view class="main">
			<view class="login_text">
				<image src="../../static/logo.jpg" mode=""></image>
				<text class="login-title">
					小医智汇
				</text>
			</view>
			<!-- 	输入框板块 -->
			<view class="inps">
				<!-- 1 -->
				<view class="inps_block">
					<view class="inp_prompt">
						<text class="content ">手机号码</text>
						<text class="content " v-if="phoneNumCheck !==''&&phoneNumCheck !== true"
							style="color: #FA746B;">手机号格式错误</text>
						<text class="content " v-if="phoneNumCheck !==''&&phoneNumCheck !== false"
							style="color:#3DD4A7;">手机号格式正确</text>
					</view>

					<view class="inpbox">
						<view class="inpbox_text">
							<text class="content btn gray">+86</text>
						</view>
						<input @input="phoneInp" @focus="focusPhone" @blur="blurPhone" :class="{focus: onPhoneFocus}"
							class="login_inp phonenum" type="text" :value="phoneNumGet" :placeholder="phonePlaceholder"
							placeholder-style="color:#ccc" />
					</view>
				</view>
				<view class="inps_block">
					<view class="inp_prompt">
						<text class="content inptitle">新密码</text>
						<text class="content " v-if="newCheck !==''&&newCheck !== true"
							style="color: #FA746B;">密码格式错误</text>
						<text class="content " v-if="newCheck !==''&&newCheck !== false"
							style="color:#3DD4A7;">密码格式正确</text>
					</view>

					<view class="inpbox">

						<input @input="newInp" @focus="focusNew" @blur="blurNew" :class="{focus: newFocus}"
							class="login_inp inp_pwd" type="text" :value="newGet" :placeholder="newPlaceholder"
							placeholder-style="color:#ccc" />
					</view>

				</view>

				<!-- 2 -->
				<view class="inps_block">
					<view class="inp_prompt">
						<text class="content inptitle">验证码</text>
						<text class="content " v-if="pwdCheck !==''&&pwdCheck !== true"
							style="color: #FA746B;">验证码格式错误</text>
						<text class="content " v-if="pwdCheck !==''&&pwdCheck !== false"
							style="color:#3DD4A7;">验证码格式正确</text>
					</view>

					<view class="inpbox">

						<input @input="pwdInp" @focus="focusPwd" @blur="blurPwd" :class="{focus: pwdFocus}"
							class="login_inp inp_pwd" type="text" :value="pwdGet" :placeholder="pwdPlaceholder"
							placeholder-style="color:#ccc" />
						<view class="inpbox-btn">
							<!-- <text @click="sendCode">发送验证码</text> -->
							<u-toast ref="uToast"></u-toast>
							<u-code :seconds="seconds" ref="uCode" @change="codeChange"></u-code>
							<u-button class="btn" @tap="getCode">{{tips}}</u-button>
						</view>
					</view>

				</view>
				<!-- 复选 -->
				<view class="login-tools">
					<u-checkbox-group>
						<u-checkbox v-model="checked" :checked="checked" @change="choose" shape="square"
							label="我已阅读并同意">
						</u-checkbox>
					</u-checkbox-group>
					<navigator @click="chooseServe" class="login-a" url="/components/ServiceAgree">用户服务协议、隐私政策
					</navigator>
				</view>
			</view>
			<view class="wrap">

			</view>
			<!-- 登录按钮-->
			<button type="default" class="log_btn white btn" :disabled="!isdisabled" @click="loginIn">确认修改</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				width: 120,
				height: 45,
				//获得焦点
				onPhoneFocus: false,
				pwdFocus: false,
				newFocus: false,
				//关键字
				phonePlaceholder: "请输入手机号",
				newPlaceholder: "请输入新密码",
				pwdPlaceholder: "请输入验证码",
				//判断复选框是否为空
				isChecked: false,

				//得到电话号码
				phoneNumGet: "",
				//电话号码是否正确
				phoneNumCheck: "",
				//得到密码
				pwdGet: "",
				//密码格式验证
				pwdCheck: "",
				newGet: "",
				newCheck: "",
				// 复选框是否勾选
				checked: false,
				tips: '',
				// refCode: null,
				seconds: 300,
			};
		},
		computed: {
			// 注册按钮是否可用
			isdisabled() {
				let istrue = this.phoneNumCheck == true && true && this.pwdCheck == true && this
					.checked == true && this.newCheck == true
				return istrue
			}
		},
		methods: {
			// 手机号
			focusPhone() {
				this.onPhoneFocus = true
				this.phonePlaceholder = ""

			},
			blurPhone() {
				this.onPhoneFocus = false
				this.phonePlaceholder = "请输入手机号"
			},
			// 验证码
			focusPwd() {
				this.pwdFocus = true
				this.pwdPlaceholder = ""
				// let value = uni.getStorageSync("userinfo");
				// value.push("1231")
				// uni.setStorageSync('userinfo', value)
			},
			// 密码
			focusNew() {
				this.newFocus = true
				this.newPlaceholder = ""
				// let value = uni.getStorageSync("userinfo");
				// value.push("1231")
				// uni.setStorageSync('userinfo', value)
			},
			blurPwd() {
				this.pwdFocus = false
				this.pwdPlaceholder = "请输入验证码"
			},
			blurNew() {
				this.newFocus = false
				this.newPlaceholder = "请输入密码"
			},
			//电话验证
			phoneInp(event) {

				let reg =
					/^(?:\+?86)?1(?:3\d{3}|5[^4\D]\d{2}|8\d{3}|7(?:[35678]\d{2}|4(?:0\d|1[0-2]|9\d))|9[189]\d{2}|66\d{2})\d{6}$/
				if (reg.test(event.detail.value)) {
					this.phoneNumCheck = true;
				} else {
					this.phoneNumCheck = false;
				}
				if (event.detail.value == "") {
					this.phoneNumCheck = "";
				}
				this.phoneNumGet = event.detail.value
			},
			//验证输入的验证码格式
			pwdInp(event) {
				let reg = /^(?:\d+|[a-zA-Z]+){6,8}$/
				if (reg.test(event.detail.value)) {
					this.pwdCheck = true;
				} else {
					this.pwdCheck = false;
				}
				if (event.detail.value == "") {
					this.pwdCheck = "";
				}
				this.pwdGet = event.detail.value
			},
			//验证输入的密码格式
			newInp(event) {
				let reg = /^(?:\d+|[a-zA-Z]+){6,8}$/
				if (reg.test(event.detail.value)) {
					this.newCheck = true;
				} else {
					this.newCheck = false;
				}
				if (event.detail.value == "") {
					this.newCheck = "";
				}
				this.newGet = event.detail.value
			},
			// 复选框选择
			choose(e) {
				this.checked = e
			},
			// 点击用户协议自动选中复选框
			chooseServe() {
				setTimeout(() => {
					this.checked = true
				}, 1000)
			},
			sendCode() {
				this.postCode()
			},
			// 发送验证码
			async postCode() {
				console.log("验证码");
				console.log(this.phoneNumGet);
				const mobile = this.phoneNumGet
				const templateId = "14755"

				const type = 'reset-pwd'
				const loginDo = uniCloud.importObject('request')
				// 调用登录接口
				const res = await loginDo.postCode({
					mobile,
					templateId,
					type
				})
				console.log(res);
			},
			//跳转登录
			async login() {
				const prame = {
					username: this.phoneNumGet,
					password: this.pwdGet
				}
				const loginDo = uniCloud.importObject('request')
				// 调用登录接口
				const res = await loginDo.login(prame)
				let vuex_user = {
					username: res.userInfo.phone,
					password: res.userInfo.password,
					phone: res.userInfo.phone,
					nickname: res.userInfo.nickname,
					gender: res.userInfo.gender,
					avatar: res.userInfo.avatar,
					age: res.userInfo.age,
				}
				if (res.code === 0) {
					uni.$u.vuex('vuex_uid', res.uid)
					uni.$u.vuex('vuex_user', vuex_user)
					uni.$u.vuex('vuex_token', res.token)
					uni.$u.vuex('vue_token_expired', res.tokenExpired)
					uni.showToast({
						icon: "success",
						title: "小医智汇欢迎您"
					})
					// 登录

					uni.$u.route({
						url: 'pages/index/index',
						type: 'switchTab',
						animationType: 'pop-in',
						animationDuration: 200
					})

				} else {
					return
				}
			},

			//跳转登录
			async loginIn() {
				let _this = this
				if (!this.phoneNumCheck || !this.pwdCheck) {
					uni.showModal({
						title: '提示',
						content: '手机号/密码格式错误或验证码错误,请确认后重试',
						success: function(res) {
							_this.phoneNumGet = "";

							_this.pwdGet = ""

							_this.phoneNumCheck = ""
							_this.pwdCheck = ""
						}
					});
				} else {
					// this.login()
					// 调用登录接口
					const loginDo = uniCloud.importObject('request')
					const mobile = this.phoneNumGet
					const code = this.pwdGet
					const password = this.newGet
					const res = await loginDo.resetPass({
						mobile,
						code,
						password
					})
					if (res.code == 0) {
						uni.showToast({
							icon: "success",
							title: "修改成功"
						})
						uni.switchTab({
							url: '/pages/center/center'
						})
					}




				}

			},
			codeChange(text) {
				this.tips = text;
			},
			getCode() {
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码

					this.postCode()
					setTimeout(() => {
						uni.hideLoading();
						// 这里此提示会被this.start()方法中的提示覆盖
						uni.$u.toast('验证码已发送');
						// 通知验证码组件内部开始倒计时
						this.$refs.uCode.start();
					}, 2000);
				} else {
					uni.$u.toast('倒计时结束后再发送');
				}
			},
		},

	}
</script>

<style lang="less" scoped>
	image {
		width: 120rpx;
		height: 120rpx;
		margin-top: 20rpx;
	}

	/* 	文字描述 */
	.login_text {
		display: flex;
		justify-content: space-around;
		margin: 30rpx 0rpx 30rpx 0;
		height: 160rpx;

		.login-title {
			font-size: 70rpx;
			color: #3ba88e;
			line-height: 160rpx;
			// border-left: 2rpx solid #52ae8f;
		}

		.login-title::before {
			content: '';
			border: 1rpx solid #3ba88e;
			position: relative;
			left: -50rpx;
		}
	}

	.first_head {
		color: #333333;
		font-size: 40rpx;
	}

	/* 	主内容 */
	.main {
		width: 90%;
		margin: auto;
	}

	.content {
		color: #333;
		font-size: 28rpx;
	}

	/* 颜色 */
	.gray {
		color: #999;
	}

	.gray1 {
		color: #ccc;
	}

	.pb {
		color: #3ba88e;
	}

	.white {
		color: #F2F2F2;
	}

	.btn {
		font-size: 32rpx;
	}

	/* 输入框 */
	.inps {
		display: flex;
		flex-direction: column;
	}

	.inps_block {
		display: flex;
		flex-direction: column;
	}

	.inp_prompt {
		margin: 30rpx 0;
		display: flex;
		justify-content: space-between;
	}

	.inpbox {
		position: relative;
		/* 	border: 2px solid #000; */
		display: flex;
		align-items: center;

	}

	.inpbox-btn {
		height: 100%;
		width: 800rpx;
		background-color: #3ba88e;
		text-align: center;
		border-radius: 10rpx;

		.btn {
			color: #fff;
			background-color: #3ba88e;
		}
	}

	.inpbox_text {
		position: absolute;
		left: 30rpx;
		top: 18rpx;
		padding-right: 16rpx;
		border-right: 4rpx solid #ccc;

	}

	.login_inp {
		background-color: #f2f7fb;
		border: 2px solid transparent;
		height: 70rpx;
		line-height: 70rpx;
		border-radius: 10rpx;
		font-size: 32rpx;
	}

	/* 电话 */
	.phonenum {
		padding-left: 120rpx;
		width: 100%;
	}

	.focus {
		border: 2px solid #2984F8;
		background-color: #fff;
	}

	/* 密码 */
	.inp_pwd {
		width: 100%;
		margin-right: 10rpx;
		padding-left: 30rpx;

	}

	/* 验证码 */
	.vf_code {
		width: 70%;
		margin-right: 10rpx;
		padding-left: 30rpx;

	}

	/* 用户名 */
	.inp_usrname {
		width: 100%;
		padding-left: 30rpx;
	}


	/* 登录框 */
	.log_btn {
		width: 100%;
		height: 70rpx;
		line-height: 70rpx;
		border-radius: 10rpx;
		background-color: #52ae8f;
		margin-top: 40rpx;
		margin-bottom: 20rpx;

	}

	.login-tools {
		display: flex;
		color: #919191;
		font-size: 28rpx;
		margin-top: 20rpx;

		.login-a {
			color: #52ae8f;
		}
	}
</style>
