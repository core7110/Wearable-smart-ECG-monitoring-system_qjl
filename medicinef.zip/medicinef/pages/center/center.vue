<template>
    <view class="container">
        <view class="center-top">
            <view class="center-inder">
                <image class="avatar" :src="userInfo.avatar || '/static/default-avatar.png'" @click="previewAvatar"></image>
                <view class="top-text">
                    {{userInfo.nickname || '浪漫滴小鹿'}}
                    <view @click.stop="editNickname" class="edit-icon">✏️</view>
                </view>
            </view>
        </view>

        <!-- 功能菜单区域 -->
        <view class="contioner" style="background: url('../../static/28.jpg') no-repeat; background-size: 100%,100%;">
            <view class="center-grid">
                <view class="grid-item" @click="goCenter()">
                    <image class="grid-img" src="../../static/icon-center/perso.png"></image>
                    <view class="grid-text">
                        个人中心
                    </view>
                </view>
                <view class="grid-item" @click="goDangan()">
                    <image class="grid-img" src="../../static/icon-center/dangan.png"></image>
                    <view class="grid-text">
                        健康档案
                    </view>
                </view>
            </view>

            <view class="center-grid">
                <view class="grid-item" @click="goSetting()">
                    <image class="grid-img" src="../../static/icon-center/settings.png"></image>
                    <view class="grid-text">
                        我的设置
                    </view>
                </view>
                <view class="grid-item" @click="showLogoutConfirm = true">
                    <image class="grid-img" src="../../static/icon-center/logout.png"></image>
                    <view class="grid-text">
                        退出登录
                    </view>
                </view>
            </view>
        </view>

        <!-- 退出登录确认弹窗 -->
        <view v-if="showLogoutConfirm" class="modal-mask">
            <view class="modal-container">
                <view class="modal-title">提示</view>
                <view class="modal-content">是否确认退出心安</view>
                <view class="modal-footer">
                    <view class="modal-button" @click="cancelout">取消</view>
                    <view class="modal-button confirm" @click="loginout">确定</view>
                </view>
            </view>
        </view>
        
        <!-- 修改昵称弹窗 -->
        <view v-if="showEditModal" class="modal-mask">
            <view class="modal-container">
                <view class="modal-title">修改昵称</view>
                <view class="modal-content">
                    <input v-model="newNickname" class="nickname-input" placeholder="请输入新昵称" />
                </view>
                <view class="modal-footer">
                    <view class="modal-button" @click="showEditModal = false">取消</view>
                    <view class="modal-button confirm" @click="confirmEditNickname">确定</view>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
    export default {
        data() {
            return {
                showLogoutConfirm: false,
                showEditModal: false,
                newNickname: '',
                userInfo: {
                    avatar: '',
                    nickname: '',
                    gender: 0,
                    age: ''
                },
                age: 0,
                sex: ''
            }
        },
        methods: {
            // 预览头像
            previewAvatar() {
                if(this.userInfo.avatar) {
                    uni.previewImage({
                        urls: [this.userInfo.avatar],
                        current: 0
                    });
                } else {
                    uni.showToast({
                        title: '暂无头像',
                        icon: 'none'
                    });
                }
            },
            
            // 编辑昵称
            editNickname() {
                this.newNickname = this.userInfo.nickname || '';
                this.showEditModal = true;
            },
            
            // 确认修改昵称
            async confirmEditNickname() {
                if(!this.newNickname.trim()) {
                    uni.showToast({
                        title: '昵称不能为空',
                        icon: 'none'
                    });
                    return;
                }
                
                uni.showLoading({
                    title: '保存中...',
                    mask: true
                });
                
                try {
                    // 模拟API请求延迟
                    await new Promise(resolve => setTimeout(resolve, 800));
                    
                    // 更新本地数据
                    this.userInfo.nickname = this.newNickname;
                    
                    // 如果需要更新vuex中的用户信息
                    // this.$u.vuex('vuex_user', {...this.userInfo});
                    
                    this.showEditModal = false;
                    uni.hideLoading();
                    
                    uni.showToast({
                        title: '修改成功',
                        icon: 'success'
                    });
                } catch (error) {
                    uni.hideLoading();
                    uni.showToast({
                        title: '修改失败',
                        icon: 'none'
                    });
                    console.error('修改昵称失败:', error);
                }
            },
            
            goCenter() {
                uni.navigateTo({
                    url: '../center/setSingle'
                })
            },
            goDangan() {
                uni.navigateTo({
                    url: '../healthRecord/healthRecord'
                })
            },
            goSetting() {
                uni.navigateTo({
                    url: '../center/setting'
                })
            },
            cancelout() {
                this.showLogoutConfirm = false;
            },
            async loginout() {
                setTimeout(() => {
                    uni.$u.route({
                        type: "redirect",
                        url: 'pages/login/login',
                    })
                }, 500)
                const rejestDo = uniCloud.importObject('request')
                const token = this.vuex_token
                const user = await rejestDo.loginout({
                    uniIdToken: token
                })
                if (user.code == 0) {
                    uni.clearStorageSync('lifeData')
                } else {
                    uni.clearStorageSync('lifeData')
                }
            },
            jsGetAge(dateStr) {
                let date = new Date(dateStr)
                let returnAge;
                let birthYear = date.getFullYear()
                let birthMonth = date.getMonth()
                let birthDay = date.getDate()

                let d = new Date();
                let nowYear = d.getFullYear();
                let nowMonth = d.getMonth() + 1;
                let nowDay = d.getDate();

                if (nowYear == birthYear) {
                    returnAge = 0;
                } else {
                    let ageDiff = nowYear - birthYear;
                    if (ageDiff > 0) {
                        if (nowMonth == birthMonth) {
                            let dayDiff = nowDay - birthDay;
                            if (dayDiff < 0) {
                                returnAge = ageDiff - 1;
                            } else {
                                returnAge = ageDiff;
                            }
                        } else {
                            let monthDiff = nowMonth - birthMonth;
                            if (monthDiff < 0) {
                                returnAge = ageDiff - 1;
                            } else {
                                returnAge = ageDiff;
                            }
                        }
                    } else {
                        returnAge = -1;
                    }
                }
                return returnAge;
            },
            setGenderBack() {
                if (this.userInfo.gender == 1) {
                    this.sex = '男'
                } else if (this.userInfo.gender == 2) {
                    this.sex = '女'
                } else {
                    this.sex = '未知'
                }
                this.userInfo.age = Number(this.userInfo.age)
                this.age = this.jsGetAge(this.userInfo.age)
            },
        },
        onLoad() {
            this.userInfo = this.vuex_user || {
                avatar: '',
                nickname: '',
                gender: 0,
                age: ''
            };
            this.setGenderBack()
        },
        onShow() {
            this.setGenderBack()
        },
    }
</script>

<style lang="less" scoped>
    page {
        background-color: #F6f6f6;
    }

    .container {
        position: relative;
        min-height: 100vh;
    }

    .contioner {
        position: absolute;
        width: 100%;
        top: 280rpx;
        padding-bottom: 340rpx;
    }

    .center-top {
        height: 300rpx;
        background: url('../../static/27.png');
        background-size: 150%,100%;
        background-position: center;

        .center-inder {
            margin-left: 7%;
            display: flex;
            width: 400rpx;
            height: 260rpx;
            justify-content: space-evenly;
            align-items: center;

            .avatar {
                width: 90rpx;
                height: 90rpx;
                border-radius: 50%;
                border: 2rpx solid #fff;
            }

            .top-text {
                margin-left: 1%;
                font-size: 43rpx;
                color: black;
                display: flex;
                align-items: center;
                
                .edit-icon {
                    margin-left: 10rpx;
                    font-size: 40rpx;
                    padding: 10rpx;
                    border-radius: 50%;
                    &:active {
                        background-color: rgba(0, 0, 0, 0.1);
                    }
                }
            }
        }
    }

    .center-grid {
        display: flex;
        padding: 20rpx;
        justify-content: space-evenly;

        .grid-item {
            width: 45%;
            background-color: rgba(255, 255, 255, 0.6);
            text-align: center;
            margin: 35rpx;
            box-shadow: 0 0 10rpx rgba(0, 0, 0, .1);
            border-radius: 30rpx;

            .grid-img {
                width: 60rpx;
                height: 60rpx;
                padding: 40rpx;
                margin-top: 20rpx;
            }

            .grid-text {
                font-size: 40rpx;
                margin: 0 auto;
                margin-bottom: 40rpx;
            }
        }
    }

    /* 自定义弹窗样式 */
    .modal-mask {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 999;
    }

    .modal-container {
        width: 80%;
        background-color: #fff;
        border-radius: 16rpx;
        overflow: hidden;
    }

    .modal-title {
        padding: 30rpx;
        font-size: 36rpx;
        font-weight: bold;
        text-align: center;
        border-bottom: 1rpx solid #eee;
    }

    .modal-content {
        padding: 40rpx 30rpx;
        font-size: 32rpx;
        text-align: center;
    }

    .modal-footer {
        display: flex;
        border-top: 1rpx solid #eee;
    }

    .modal-button {
        flex: 1;
        padding: 30rpx;
        text-align: center;
        font-size: 34rpx;
        color: #666;
    }

    .modal-button.confirm {
        color: #007aff;
        font-weight: bold;
        border-left: 1rpx solid #eee;
    }

    .nickname-input {
        width: 100%;
        padding: 20rpx;
        border: 1rpx solid #eee;
        border-radius: 8rpx;
        font-size: 32rpx;
    }
</style>