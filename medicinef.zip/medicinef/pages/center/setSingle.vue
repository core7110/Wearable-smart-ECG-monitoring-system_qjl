<template>
	<view class="u-page">
		<!-- 头像 -->
		<view class="list-item" @tap="clickAvent">
			<text>头像</text>
			<u-avatar :src="userInfo.avatar" class="user-avent"></u-avatar>
		</view>
		<!-- 裁剪头像组件 -->
		<uni-ImgCropper ref="gmyImgCropper" :quality="1" cropperType="fixed" :imgSrc="imgSrc" @getImg="getImg">
		</uni-ImgCropper>
		<!-- 昵称 -->
		<view class="list-item" @click="clickName">
			<text>昵称</text>
			<text class="content" v-if="nameCheck !== true" style="color: #FA746B;">限3-8位且不包含字符</text>
			<text v-if="!showName">{{userInfo.nickname}}</text>
			<u--input v-if="showName" class="name-input" :focus="true" :autoBlur="true" v-model="nickName"
				@input="usernameInp" @blur="loseBlur">
			</u--input>
		</view>

		<!-- 性别 -->
		<view class="list-item" @click="clickSex">
			<text>性别</text>
			<text>{{sex}}</text>
		</view>
		<!-- 性别弹出层 -->
		<u-popup :show="showSex" mode="bottom" :closeOnClickOverlay="true" @close="close">
			<view>
				<view class="list-popup">
					<u-radio-group v-model="sex" @change="selectSex" iconPlacement="right" placement="column"
						iconColor="#fff">
						<u-radio class="sex-radio" activeColor="red" name="男" label="男"></u-radio>
						<u-radio class="sex-radio" activeColor="red" name="女" label="女"></u-radio>
					</u-radio-group>
				</view>
			</view>
		</u-popup>
		<!-- 生日 -->
		<view class="list-item" @click="clickBirth">
			<text>生日</text>
			<text>{{userInfo.age|date('yyyy-mm-dd')}}</text>
		</view>
		<!-- 生日选择器 -->
		<u-datetime-picker :minDate="0" :maxDate="Number(new Date())" :show="showData" @close="closeData"
			@cancel="cancelData" @confirm="confirmData" :closeOnClickOverlay="true" v-model="userInfo.age" mode="date">
		</u-datetime-picker>
		<view class="set-btn">
			<button class="toole-btn" @click="submitInfo" type="primary">确认修改</button>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/js_sdk/mmmm-image-tools/index.js'
	export default {
		name: 'setSingle',
		data() {
			return {
				// 用户信息
				userInfo: {},
				// 本地用户数据
				localInfo: {},
				imgSrc: '', // 待裁剪图片
				// 修改昵称
				showName: false,
				// 是否打开性别选择
				showSex: false,
				// 是否打开生日选择
				showData: false,
				// 昵称检测
				nameCheck: true,
				nickName: '',
				sex: ''
			}
		},
		onLoad() {
			this.getUserInfo()
			this.nickName = this.userInfo.nickname

		},
		methods: {
			// 获取用户信息
			async getUserInfo() {
				let uid = this.vuex_uid
				// 发送请求获取用户数据
				const loginDo = uniCloud.importObject('request')
				const res = await loginDo.getUsers({
					uid,
					field: ['avatar', 'nickname', 'gender', 'age']
				})

				this.userInfo = res.userInfo
				this.localInfo = this.vuex_user
				this.sex = this.userInfo.gender == 1 ? '男' : '女'
				if (this.userInfo.gender == 0) this.sex = '未知'
			},
			// 点击更换头像
			clickAvent() {
				// 调用实例的chooseImg方法，拉起图片选择界面，待图片选择完毕后直接进入图片截取界面
				this.$refs.gmyImgCropper.chooseImage();
			},
			// 裁剪完成时,返回截取图片的临时路径
			getImg(e) {
				pathToBase64(e).then(res => {
					this.userInfo.avatar = res
				})
			},
			// 点击修改昵称
			clickName() {
				this.showName = true
			},
			// 内容变化时
			usernameInp(event) {
				let reg = /^([\u4e00-\u9fa5]|[0-9_a-zA-Z]){3,8}$/
				if (reg.test(event)) {
					this.nameCheck = true
					this.userInfo.nickname = event
				} else {
					this.nameCheck = false
				}
			},
			// 失去焦点时触发
			loseBlur() {
				this.showName = false
				this.nameCheck = true
				this.nickName = this.userInfo.nickname
			},
			// 点击选择性别
			clickSex() {
				this.showSex = true
			},
			selectSex(val) {
				if (val == '男') {
					this.userInfo.gender = 1
				} else {
					this.userInfo.gender = 2
				}
				this.showSex = false
			},
			close() {
				this.showSex = false
			},
			// 点击选择生日
			clickBirth() {
				this.showData = true
			},
			confirmData(val) {
				this.userInfo.age = String(val.value)
				console.log(this.userInfo.age)
				this.showData = false
			},
			cancelData(e) {
				this.showData = false
			},
			closeData(e) {
				this.showData = false
			},
			async submitInfo() {
				this.userInfo.age = String(this.userInfo.age)
				this.localInfo.age = this.userInfo.age
				this.localInfo.avatar = this.userInfo.avatar
				this.localInfo.nickname = this.userInfo.nickname
				this.localInfo.gender = this.userInfo.gender
				uni.$u.vuex('vuex_user', this.localInfo)

				const token = this.vuex_token

				const rejestDo = uniCloud.importObject('request')
				// 检验token
				const user = await rejestDo.checktoken({
					uniIdToken: token
				})

				// 更新用户信息
				const updataUser = await rejestDo.updateUsers({
					uid: user.uid,
					nickname: this.userInfo.nickname,
					gender: this.userInfo.gender,
					age: this.userInfo.age
				})
				// 更新头像
				const res = await rejestDo.setAvant({
					avatar: this.userInfo.avatar,
					uid: user.uid
				})
				if (updataUser.code == 0 && res.code == 0) {
					uni.showToast({
						icon: "success",
						title: "修改成功"
					})
					uni.switchTab({
						url: '/pages/center/center'
					})
				} else {
					uni.showToast({
						icon: "error",
						title: "修改失败"
					})
				}


			}



		},
	}
</script>

<style lang="less" scoped>
	.u-page {
		.list-item {
			display: flex;
			height: 120rpx;
			line-height: 120rpx;
			padding: 20rpx;
			justify-content: space-between;
			border-bottom: 2rpx solid #ddd;
			position: relative;
		}

		.user-avent {
			margin-top: 20rpx;
		}

		.set-btn {
			margin-top: 40rpx;
			display: flex;
			width: 100%;
			justify-content: center;

			.toole-btn {
				width: 70%;
				border-radius: 30rpx;
			}

		}

		.list-popup {
			height: 600rpx;
		}

		.sex-radio {
			padding: 40rpx;
			height: 100rpx;
			border-bottom: 1rpx solid #ddd;
		}

		.name-input {
			border: none;
		}

		.content {
			color: #333;
			font-size: 28rpx;
			position: absolute;
			top: -20rpx;
			right: 10rpx;
		}

		/deep/.uni-input-input {
			text-align: right;
			color: #000;
		}
	}
</style>
