<template>
	<view>
		<view class="main">
			<!-- 	输入框板块 -->
			<view class="inps">
				<!-- 1 -->
				<view class="inps_block">
					<view class="inp_prompt">
						<text class="content ">旧密码</text>

					</view>

					<view class="inpbox">

						<input @input="oldPwdInp" @focus="focusOldPwdInp" @blur="blurOldPwdInp"
							:class="{focus: oldPwdFocus}" class="login_inp inp_pwd" type="text" :value="oldPwdGet"
							:placeholder="oldPwdPlaceholder" placeholder-style="color:#ccc" />
					</view>
				</view>
				<!-- 2 -->
				<view class="inps_block">
					<view class="inp_prompt">
						<text class="content inptitle">新密码(限6-8位且不包含字符)</text>
						<text class="content " v-if="pwdCheck !==''&&pwdCheck !== true"
							style="color: #FA746B;">密码格式错误</text>
						<text class="content " v-if="pwdCheck !==''&&pwdCheck !== false"
							style="color:#3DD4A7;">密码格式正确</text>
					</view>

					<view class="inpbox">
						<input @input="pwdInp" @focus="focusPwd" @blur="blurPwd" :class="{focus: pwdFocus}"
							class="login_inp inp_pwd" type="password" :value="pwdGet" :placeholder="pwdPlaceholder"
							placeholder-style="color:#ccc" />
					</view>

				</view>
				<!-- 3 -->
				<view class="inps_block">
					<view class="inp_prompt">
						<text class="content inptitle">再次输入密码</text>
						<text class="content " v-if="pwdAgainCheck !==''&&pwdAgainCheck !== true"
							style="color: #FA746B;">两次密码不一致</text>
						<text class="content " v-if="pwdAgainCheck !==''&&pwdAgainCheck !== false"
							style="color:#3DD4A7;">两次密码一致</text>
					</view>

					<view class="inpbox">
						<input @input="pwdAgainInp" @focus="focusPwdAgain" @blur="blurPwdAgain"
							:class="{focus: pwdAgainFocus}" class="login_inp inp_pwd" type="password"
							:value="pwdGetAgain" :placeholder="pwdAgainPlaceholder" placeholder-style="color:#ccc" />
					</view>

				</view>
			</view>
			<!-- 登录按钮-->
			<button type="default" class="log_btn white btn" @click="loginIn">确认修改</button>
		</view>

	</view>
</template>

<script>
	export default {
		name: "",
		data() {
			return {
				form: {
					check: '', //验证码
				},
				width: 120,
				height: 45,
				//获得焦点
				oldPwdFocus: false,
				pwdFocus: false,
				pwdAgainFocus: false,
				//关键字
				oldPwdPlaceholder: "请输入旧密码",
				pwdPlaceholder: "请输入新密码",
				pwdAgainPlaceholder: "请再次输入密码",
				//判断复选框是否为空
				isChecked: false,
				//得到电话号码
				oldPwdGet: "",
				//电话号码是否正确
				oldPwdCheck: "",
				//得到密码
				pwdGet: "",
				//密码格式验证
				pwdCheck: "",
				//再次得到密码
				pwdGetAgain: "",
				//再次密码格式验证
				pwdAgainCheck: ""


			}
		},

		onLoad() {
			const value = uni.getStorageSync("userinfo");
			if (value) {
				console.log(value)
			}
		},
		methods: {
			// 手机号
			focusOldPwdInp() {
				this.oldPwdFocus = true
				this.oldPwdPlaceholder = ""

			},

			blurOldPwdInp() {
				this.oldPwdFocus = false
				this.oldPwdPlaceholder = "请输入旧密码"
			},
			// 密码
			focusPwd() {
				this.pwdFocus = true
				this.pwdPlaceholder = ""
				// let value = uni.getStorageSync("userinfo");
				// value.push("1231")
				// uni.setStorageSync('userinfo', value)
			},

			blurPwd() {
				this.pwdFocus = false
				this.pwdPlaceholder = "请输入新密码"
			},
			//再次核对密码
			focusPwdAgain() {
				this.pwdAgainFocus = true
				this.pwdAgainPlaceholder = ""
				// let value = uni.getStorageSync("userinfo");
				// value.push("1231")
				// uni.setStorageSync('userinfo', value)
			},

			blurPwdAgain() {
				this.pwdAgainFocus = false
				this.pwdAgainPlaceholder = "请再次输入密码"
			},
			//电话验证
			oldPwdInp(event) {

				let reg =
					/^(?:\+?86)?1(?:3\d{3}|5[^4\D]\d{2}|8\d{3}|7(?:[35678]\d{2}|4(?:0\d|1[0-2]|9\d))|9[189]\d{2}|66\d{2})\d{6}$/
				if (reg.test(event.detail.value)) {
					this.oldPwdCheck = true;
				} else {
					this.oldPwdCheck = false;
				}
				if (event.detail.value == "") {
					this.oldPwdCheck = "";
				}
				this.oldPwdGet = event.detail.value
			},
			//用户名验证
			usernameInp(event) {
				let reg = /^([\u4e00-\u9fa5]|[0-9_a-zA-Z]){3,8}$/

				if (reg.test(event.detail.value)) {
					this.usernameCheck = true;
				} else {
					this.usernameCheck = false;
				}
				if (event.detail.value == "") {
					this.usernameCheck = "";
				}
				this.usernameGet = event.detail.value
			},
			//验证输入的密码格式
			pwdInp(event) {
				let reg = /^(?:\d+|[a-zA-Z]+){6,8}$/
				if (reg.test(event.detail.value)) {
					this.pwdCheck = true;
				} else {
					this.pwdCheck = false;
				}
				if (event.detail.value == "") {
					this.pwdCheck = "";
				}
				this.pwdGet = event.detail.value
			},
			//验证再次输入的密码
			pwdAgainInp(event) {

				if (event.detail.value == this.pwdGet) {
					this.pwdAgainCheck = true;
				} else {
					this.pwdAgainCheck = false;
				}
				if (event.detail.value == "") {
					this.pwdAgainCheck = "";
				}
				this.pwdGetAgain = event.detail.value
			},
			//登录
			async loginIn() {
				const uid = this.vuex_uid
				const data = {
					uid: uid,
					oldPassword: this.oldPwdGet,
					newPassword: this.pwdGet
				}
				const loginDo = uniCloud.importObject('request')
				const res = await loginDo.updatPwds(data)
				if (res.code === 0) {
					uni.showToast({
						icon: "success",
						title: "请重新登录"
					})

					uni.clearStorageSync('lifeData')
					setTimeout(() => {
						uni.$u.route({
							type: "redirect",
							url: 'pages/login/login',
						})
					}, 500)
				}


			},

		}
	}
</script>

<style scoped>
	.imgWrapper {
		display: flex;
		align-items: center;
		justify-content: center;
	}

	image {
		width: 200rpx;
		height: 200rpx;
	}

	/* 	文字描述 */
	.login_text {
		display: flex;
		flex-direction: column;
		margin: 80rpx 0rpx 60rpx 0;
	}

	.first_head {
		color: #333333;
		font-size: 40rpx;
	}

	/* 	主内容 */
	.main {
		width: 90%;
		margin: auto;
	}

	.content {
		color: #333;
		font-size: 28rpx;
	}

	/* 颜色 */
	.gray {
		color: #999;
	}

	.gray1 {
		color: #ccc;
	}

	.pb {
		color: #2984F8;
	}

	.white {
		color: #F2F2F2;
	}

	.btn {
		font-size: 32rpx;
	}

	/* 输入框 */
	.inps {
		margin-top: 50rpx;
		display: flex;
		flex-direction: column;
	}

	.inps_block {
		display: flex;
		flex-direction: column;
	}

	.inp_prompt {
		margin: 30rpx 0;
		display: flex;
		justify-content: space-between;
	}



	.inpbox {
		position: relative;
		/* 	border: 2px solid #000; */
		display: flex;
		align-items: center;

	}

	.login_inp {
		background-color: #f2f7fb;
		border: 2px solid transparent;
		height: 70rpx;
		line-height: 70rpx;
		border-radius: 10rpx;
		font-size: 32rpx;
	}


	.focus {
		border: 2px solid #2984F8;
		background-color: #fff;
	}

	/* 密码 */
	.inp_pwd {
		width: 100%;
		margin-right: 10rpx;
		padding-left: 30rpx;

	}

	/* 登录框 */
	.log_btn {
		width: 100%;
		height: 70rpx;
		line-height: 70rpx;
		border-radius: 10rpx;
		background-color: #2984F8;
		margin-top: 40rpx;
		margin-bottom: 20rpx;

	}

	/* 其他方式 */
	.login_switch {
		margin: 30rpx 0;
		display: flex;
		justify-content: space-between;
	}
</style>

<!-- 
					
 
 
 -->
