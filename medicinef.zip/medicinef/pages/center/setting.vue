<template>
	<view> 
		<view class="setting_box">
			<view class="items_wrapper" @click="goChangePass">
				<text class="sec_head">修改密码</text>
				<u-icon class="info_icon" type="arrowright" color="#ccc" size="20"></u-icon>
			</view>
			<view class="items_wrapper">
				<text class="sec_head">消息通知</text>
				<switch class="info_icon" checked="true" />
				<!-- <uni-icons class="info_icon" type="arrowright" color="#ccc" size="20"></uni-icons> -->
			</view>
			<view class="items_wrapper">
				<text class="sec_head">清除缓存</text>
				<text class="content">{{dataStore}}</text>
				<!-- <u-icon class="info_icon" type="arrowright" color="#ccc" size="20"></u-icon> -->
			</view>

			<view class="items_wrapper">
				<text class="sec_head">升级版本</text>
				<text class="content_v">{{version}}</text>
				<!-- <u-icon class="info_icon" type="arrowright" color="#ccc" size="20"></u-icon> -->
			</view>
			<view class="items_wrapper" @click="toAbout">
				<text class="sec_head">关于我们</text>
				<image src="../../static/icon/right.png" mode="" class="right">
			</view>

		</view>
	</view>
</template>

<script>
	export default {
		name: "",
		data() {
			return {
				dataStore: "6.2M",
				version: "已是最新版本"
			}
		},

		methods: {
			goChangePass() {
				uni.navigateTo({
					// url: '././changePassword'
					url: '././changePassbySms'
				});
			},
			toAbout(){
				uni.navigateTo({
					url: '/pages/center/aboutUs',
					// 一定要写最前面的 ”/“ 否则不能跳转
				});
			}
		}
	}
</script>

<style lang="less" scoped>
	.setting_box {
		width: 100%;
		display: flex;
		flex-direction: column;
	}

	.items_wrapper {
		width: 100%;
		height: 100rpx;
		line-height: 100rpx;
		display: flex;
		align-items: center;
		background-color: #fff;
		border-bottom: 2rpx solid #f2f2f2;
		position: relative;
		.right {
			width: 40rpx;
			height: 40rpx;
			position: absolute;
			right: 20rpx;
			bottom: 25rpx;
		
		}
	}

	.sec_head {
		color: #333333;
		font-size: 32rpx;
		padding-left: 30rpx;
	}

	.info_icon {
		margin-left: auto;
	}

	.content {
		color: #666666;
		font-size: 28rpx;
		margin-left: auto;
		position: absolute;
		right: 40rpx;
	}

	.content_v {
		color: #666666;
		font-size: 28rpx;
		margin-left: auto;
		position: absolute;
		right: 40rpx;
	}
</style>
