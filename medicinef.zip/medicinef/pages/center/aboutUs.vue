<template>
	<view class="aboutUsMain">
		<div class="logo">
			<div class="iamge">
				<image src="../../static/logo.jpg" mode="" style="width: 210rpx; height: 210rpx;"></image>
			</div>
			<p>快捷轻便的医疗健康管理助手</p>
		</div>
		<div class="message">
			<p>商务合作请联系：<span>13772117153</span></p>
			<p>工作日 9:00-19:00</p>
			<p>V1.0</p>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="less" scoped>
	.aboutUsMain{
		.logo{
			margin-top: 150rpx;
			position: relative;
			.iamge{
				position: relative;
				top: 20rpx;
				left: 50%;
				width: 210rpx; 
				height: 210rpx;
				transform: translate(-50%, 0);
				// box-shadow: 0rpx 1rpx 1rpx #888888;
			}
			p{
				text-align: center;
				margin-top: 50rpx;
				color: rgb(72, 72, 72);
				font-size: 36rpx;
			}
		}
		.message{
			margin-top: calc(100vh - 750rpx);
			p{
				text-align: center;
				color: rgb(172, 172, 172);
				font-size: 30rpx;
			}
			p:nth-of-type(1){
				span{
					color: rgb(26,160,52);
				}
			}
			p:nth-of-type(2){
				margin-top: 20rpx;
			}
			p:nth-of-type(3){
				margin-top: 70rpx;
				color: rgb(96,98,100);
				font-size: 40rpx;
			}
		}
	}
	
</style>
