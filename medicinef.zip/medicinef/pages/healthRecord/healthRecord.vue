<template>
	<view class="box">
		<!-- 导航栏 -->
		<view class="navigation">
			<view :class="'navigation_One'+' '+(isChage?'is_active':'')" @click="isChage = true">基础信息</view>
			<view :class="'navigation_Two'+' '+(isChage?'':'is_active')" @click="isChage = false">健康信息</view>
		</view>
		<!-- 基础信息部分 -->
		<view v-if="isChage">
			<!-- 头像部分 -->
			<view class="headPortrait">
				<view class="info_list">
					<view>
						<image :src="userInfo.avatar" mode=""
							style="width: 80px;height: 80px;border-radius: 50%;margin-left: 38%;margin-top: 30px;">
						</image>
					</view>
				</view>
			</view>
			<!-- 主体部分 -->
			<view class="" style="background-color: #FFFFFF;">
				<view class="realName">
					<text class="t1">真实姓名</text><input class="inp1" @input="nameInp" type="text"
						:value="theTrueInfo.name" placeholder="请填写您的真实姓名" />
				</view>
				<view class="realName">
					<text class="t1">身份证号</text><input @input="idInp" class="inp1" type="text" :value="theTrueInfo.id"
						placeholder="请填写您的身份证号" />
					<text class="content" v-if="idCheck !== true" style="color: #FA746B;">身份证号格式错误，请检查</text>
				</view>
				<view class="realName" @tap="sex_xz()">
					<text class="t1">性别</text>
					<view class="vie1">{{theTrueInfo.sex}}</view>
				</view>
				<view class="realName">
					<text class="t1">联系电话</text><input @input="phoneInp" style="color: #2984F8;" class="inp1"
						type="text" :value="theTrueInfo.phone" placeholder="请填写您的电话号码" />
					<text class="content" v-if="phoneCheck !== true" style="color: #FA746B;">手机号格式错误，请检查</text>
				</view>
				<view class="realName" style="border: 0;">
					<text class="t1">现居地</text><input class="inp1" type="text" @input="nowplaceInp"
						:value="theTrueInfo.nowplace" placeholder="请填写您的现居地" />
				</view>
				<view class="realName">
					<text class="t1">户籍地址</text><input class="inp1" type="text" @input="addressInp"
						:value="theTrueInfo.address" placeholder="请填写户籍信息" />
				</view>

				<view class="realName">
					<radio-group name="sex" @change="radioChange">
						<label style="margin-right: 20px;">户籍类型</label>
						<label>
							<radio value="农村" :checked="theTrueInfo.home=='农村'?true:false" /><text>农村</text>
							<radio value="城市" :checked="theTrueInfo.home=='农村'?false:true" /><text>城市</text>
						</label>
					</radio-group>
				</view>
				<view class="realName" style="height: 100px;border: 0;">
					<checkbox-group @change="selectCk">
						<label style="display: flex;flex-direction: row;font-size: 28upx;">
							<label style="margin-right: 20px;width: 100px;">费用类型</label>
							<label>
								<checkbox value="自费" :checked="set[ '自费']" /><text>自费</text>
								<checkbox value="社会医疗保险" :checked="set['社会医疗保险']" /><text>社会医疗保险</text>
								<checkbox value="商业保险" :checked="set['商业保险']" /><text>商业保险</text>
								<checkbox value="新农合" :checked="set['新农合']" /><text>新农合</text>
								<checkbox value="其他" :checked="set['其他']" /><text>其他</text>
							</label>
						</label>
					</checkbox-group>
				</view>
			</view>
			<view>
				<u-modal :show="isShowTrue" :showCancelButton="true" @cancel="cancelTrue" @confirm="baseSubmit"
					:closeOnClickOverlay="true" title="是否确认保存">

				</u-modal>
				<button class="baocun baocun-btn" @click="isShowTrue = true">保存</button>
			</view>
		</view>

		<!-- 健康信息部分 -->
		<view v-if="!isChage">
			<view class="realName">
				<text class="t1">身高</text><input class="inp1" type="text" @input="highInp" :value="helthInfo.high"
					placeholder="请输入你的身高" />cm
				<text class="content" v-if="highCheck !== true" style="color: #FA746B;">请填写数字</text>
			</view>
			<view class="realName">
				<text class="t1">体重</text><input class="inp1" type="text" @input="weighInp" :value="helthInfo.weight"
					placeholder="请输入你的体重" />kg
				<text class="content" v-if="weightCheck !== true" style="color: #FA746B;">请填写数字</text>
			</view>
			<view class="realName">
				<text class="t1">血型</text>
				<view class="vie1" @tap="loodtype_xz">{{helthInfo.loodtype}}</view>
			</view>
			<view class="realName">
				<radio-group name="sex" @change="allergy">
					<label style="margin-right: 20px;">过敏史</label>
					<label>
						<radio value='false' :checked="!helthInfo.allergy" /><text>无</text>
						<radio style="margin-left: 20px;" value="true" :checked="helthInfo.allergy" /><text>有</text>
					</label>
				</radio-group>
			</view>
			<view class="realName">
				<radio-group name="sex" @change="previoushistory ">
					<label style="margin-right: 20px;">既往史</label>
					<label>
						<radio value='false' :checked="!helthInfo.previoushistory" /><text>无</text>
						<radio style="margin-left: 20px;" value="true" :checked="helthInfo.previoushistory" />
						<text>有</text>
					</label>
				</radio-group>
			</view>
			<view class="realName">
				<radio-group name="sex" @change="medicalhistory ">
					<label style="margin-right: 20px;">就诊史</label>
					<label>
						<radio value='false' :checked="!helthInfo.medicalhistory" /><text>无</text>
						<radio style="margin-left: 20px;" value="true" :checked="helthInfo.medicalhistory" />
						<text>有</text>
					</label>
				</radio-group>
			</view>
			<view class="realName" style="border: 0;">
				<radio-group name="sex" @change="familymedicalhistory ">
					<label style="margin-right: 20px;">家族病史</label>
					<label>
						<radio value='false' :checked="!helthInfo.familymedicalhistory" /><text>无</text>
						<radio style="margin-left: 20px;" value="true" :checked="helthInfo.familymedicalhistory" />
						<text>有</text>
					</label>
				</radio-group>
			</view>
			<view class="baocun" @tap="healthSubmit">
				保存
			</view>

		</view>
	</view>
</template>

<script>
	import {
		getTrueInfo,
		getHealth,
		postTrueInfo,
		postHealth
	} from '../../config/api.js'
	export default {
		data() {
			return {
				// 是否切换tab栏
				isChage: true,
				// 基本信息保存模态框
				isShowTrue: false,
				// 健康信息保存模态框
				isShowHealth: false,
				// 获取存在本地的用户信息，主要使用头像和性别
				userInfo: {},
				// 基础信息页面信息
				theTrueInfo: {
					name: "", // 真实姓名
					id: "", // 身份证号
					sex: "", // 性别
					phone: "", // 手机号
					nowplace: "", // 现居地
					address: "", // 户籍地址
					home: '', // 户籍类型
					presentaddress: "", // 费用类型
				},
				// 身份证号是否正确
				idCheck: true,
				// 手机号是否正确
				phoneCheck: true,

				helthInfo: {
					high: 0, // 身高
					weight: 0, // 体重
					loodtype: "请选择你的血型", // 血型
					allergy: false, // 是否有过敏史
					previoushistory: false, // 是否有既往史
					medicalhistory: false, // 是否有就诊史
					familymedicalhistory: false // 是否有家族病史
				},
				highCheck: true,
				weightCheck: true,
				set: {
					'自费': false,
					'社会医疗保险': false,
					'商业保险': false,
					'新农合': false,
					'其他': false,

				}
			}
		},
		onLoad: function(option) {
			this.userInfo = this.vuex_user
			this.theTrueInfo.sex = this.userInfo.sex
			this.gettrueInfo()
			this.healthInfo()

		},
		methods: {
			radioChange: function(evt) {
				this.theTrueInfo.home = evt.detail.value
			},
			async gettrueInfo() {
				const uid = this.vuex_uid
				const res = await getTrueInfo(uid).catch(err => {
					console.log(err);
				})
				// 请求成功
				if (res.data.code === 200) {
					this.theTrueInfo = res.data.data || {}
					this.theTrueInfo.age = 1
					if (this.theTrueInfo.presentaddress) {
						let arr = this.theTrueInfo.presentaddress.split(",")
						arr.forEach(item => {
							this.set[item] = true
						})
					}
				} else {
					uni.showToast({
						icon: "error",
						title: "获取信息失败"
					})
				}
			},
			async healthInfo() {
				const uid = this.vuex_uid
				const res = await getHealth(uid)
				// 请求成功
				if (res.data.code === 200) {
					this.helthInfo = res.data.data || {}
					if (!this.helthInfo.loodtype) {
						this.helthInfo.loodtype = '请选择你的血型'
					}

				} else {
					uni.showToast({
						icon: "error",
						title: "获取信息失败"
					})
				}
			},
			// 取消保存
			cancelTrue() {
				this.isShowTrue = false
			},
			// 基本信息提交
			async baseSubmit() {
				this.isShowTrue = false
				if (!this.theTrueInfo.phone) {
					this.phoneCheck = false
				}
				if (!this.theTrueInfo.id) {
					this.idCheck = false
				}
				if (this.phoneCheck && this.idCheck) {
					const trueRes = await postTrueInfo(this.theTrueInfo)
					if (trueRes.data.code === 200) {
						uni.showToast({
							title: trueRes.data.message
						})
					}

				} else {
					if (!this.idCheck) {
						uni.showToast({
							icon: "error",
							title: "身份证号有误"
						})
					} else if (!this.phoneCheck) {
						uni.showToast({
							icon: "error",
							title: "手机号格式有误"
						})
					}

				}

			},
			// 选择的费用类型
			selectCk: function(e) {
				this.theTrueInfo.presentaddress = e.detail.value.join(",")
			},
			// 选择性别
			sex_xz() {
				uni.showActionSheet({
					itemList: ['男', '女'],
					success: function(res) {
						if (res.tapIndex == 0) {
							this.theTrueInfo.sex = "男"
						} else if (res.tapIndex == 1) {
							this.theTrueInfo.sex = "女"
						}
					}
				});
			},
			// 获取姓名
			nameInp(event) {
				this.theTrueInfo.name = event.detail.value
			},
			// 获取现居地
			nowplaceInp(event) {
				this.theTrueInfo.nowplace = event.detail.value
			},
			// 获取户籍地址
			addressInp(event) {
				this.theTrueInfo.address = event.detail.value
			},

			// 验证身份证号格式
			idInp(event) {
				let reg = /^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/
				if (reg.test(event.detail.value)) {
					this.idCheck = true;
					this.theTrueInfo.id = event.detail.value
				} else {
					this.idCheck = false;
				}
			},

			// 验证手机号
			phoneInp(event) {
				let reg =
					/^(?:\+?86)?1(?:3\d{3}|5[^4\D]\d{2}|8\d{3}|7(?:[35678]\d{2}|4(?:0\d|1[0-2]|9\d))|9[189]\d{2}|66\d{2})\d{6}$/
				if (reg.test(event.detail.value)) {
					this.phoneCheck = true;
					this.theTrueInfo.phone = event.detail.value
				} else {
					this.phoneCheck = false;
				}
			},
			// 获取身高
			highInp(event) {
				let reg = /^[-+]?([1-9][0-9]*|0)(\.[0-9]+)?$/
				if (reg.test(event.detail.value)) {
					this.highCheck = true;
					this.helthInfo.high = Number(event.detail.value)
				} else {
					this.highCheck = false;
				}
			},
			// 获取体重
			weighInp(event) {
				this.helthInfo.weight = Number(event.detail.value)
				let reg = /^[-+]?([1-9][0-9]*|0)(\.[0-9]+)?$/
				if (reg.test(event.detail.value)) {
					this.weightCheck = true;
					this.helthInfo.weight = event.detail.value
				} else {
					this.weightCheck = false;
				}
			},
			// 是否有过敏史
			allergy: function(evt) {
				this.helthInfo.allergy = JSON.parse(evt.detail.value)
			},
			// 是否有既往史
			previoushistory: function(evt) {
				this.helthInfo.previoushistory = JSON.parse(evt.detail.value)
			},
			// 是否有就诊史
			medicalhistory: function(evt) {
				this.helthInfo.medicalhistory = JSON.parse(evt.detail.value)
			},
			// 是否有家族病史
			familymedicalhistory: function(evt) {
				this.helthInfo.familymedicalhistory = JSON.parse(evt.detail.value)
			},
			cancelHealth() {
				this.isShowHealth = false
			},
			async healthSubmit() {
				this.isShowHealth = false
				if (!this.helthInfo.high) {
					this.highCheck = false
				}
				if (!this.helthInfo.weight) {
					this.weightCheck = false
				}
				if (this.highCheck && this.weightCheck) {
					const healthRes = await postHealth(this.helthInfo).catch(err => {
						console.log(err);
					})
					if (healthRes.data.code === 200) {
						uni.showToast({
							title: healthRes.data.message
						})
					}

				} else {
					uni.showToast({
						icon: "error",
						title: "请检查输入"
					})
				}
			},
			// 选择血型
			loodtype_xz() {
				let _this = this
				uni.showActionSheet({
					itemList: ['A型', 'B型', 'O型', 'AB型', 'RH阴型', 'RH阳型', '不详'],
					success: function(res) {
						if (res.tapIndex == 0) {
							_this.helthInfo.loodtype = "A型"
						} else if (res.tapIndex == 1) {
							_this.helthInfo.loodtype = "B型"
						} else if (res.tapIndex == 2) {
							_this.helthInfo.loodtype = "O型"
						} else if (res.tapIndex == 3) {
							_this.helthInfo.loodtype = "AB型"
						} else if (res.tapIndex == 4) {
							_this.helthInfo.loodtype = "RH阴型"
						} else if (res.tapIndex == 5) {
							_this.helthInfo.loodtype = "RH阳型"
						} else if (res.tapIndex == 6) {
							_this.helthInfo.loodtype = "不详"
						}
					}
				});
			},


		}
	}
</script>

<style>
	.box {
		margin-bottom: 100rpx;
		position: relative;
	}

	.navigation {
		width: 90%;
		background-color: #F2F2F2;
		height: 80rpx;
		border-radius: 20rpx;
		margin-left: 5%;
		margin-top: 20rpx;
	}

	.navigation_One {
		float: left;
		width: 47.25%;
		height: 68rpx;
		margin-top: 6rpx;
		text-align: center;
		line-height: 68rpx;
		margin-left: 1.5%;
		border-radius: 20rpx;
	}

	.navigation_Two {
		float: left;
		width: 47.25%;
		height: 68rpx;
		margin-top: 6rpx;
		text-align: center;
		line-height: 68rpx;
		margin-left: 1.5%;
		border-radius: 20rpx;
		color: #666666;
	}

	.is_active {
		background-color: #FFFFFF;
		color: #3ba88e;
	}

	.headPortrait {
		width: 100%;
		background-color: #F7FAFD;
		height: 300rpx;
		margin-top: 20rpx;
	}

	.realName {
		height: 150rpx;
		width: 90%;
		margin-left: 5%;
		border-bottom: 2rpx solid #999999;
		line-height: 120rpx;
		background-color: #FFFFFF;
		position: relative;
	}

	.content {
		color: #333;
		height: 40rpx;
		font-size: 28rpx;
		position: absolute;
		top: -40rpx;
		left: 20rpx;
	}

	.baocun {
		width: 90%;
		height: 100rpx;
		border-radius: 20rpx;
		background-color: #52ae8f;
		font-size: 40rpx;
		text-align: center;
		margin-top: 40rpx;
		line-height: 100rpx;
		color: #FFFFFF;
		position: relative;
		left: 5%;

	}

	.baocun-btn {
		left: 0;
	}

	.t1 {
		font-size: 36rpx;
		color: #333333;
		float: left;
	}

	.xx {
		color: #FA746B;
		float: left;
	}

	.inp1 {
		float: left;
		height: 120rpx;
		margin-left: 40rpx;
	}

	.vie1 {
		float: left;
		height: 120rpx;
		margin-left: 40rpx;
		color: #898686;
	}
</style>
