<template>
	<view class="details_box">
		<view class="top">
			<view class="img_box">
				<image class="top_img" src="https://z3.ax1x.com/2021/11/16/Ifaasx.png" mode="scaleToFill"></image>
			</view>
			<view class="top_right">
				<view class="top_title">
					{{teamdetail.name}}
				</view>
				<!-- <view class="arderrs" @click="goMedetail"> -->
				<view class="arderrs">
					<view class="arderrs_text">
						所属地区: {{teamdetail.adname}}
					</view>
				</view>
				<view class="top_people">
					联系电话：<text>{{teamdetail.tel}}</text>
				</view>
				<u-rate count="5"  v-model="value1"  active-color="#ffff00"></u-rate>
			</view>
		</view>
		<view class="content">
			<view class="content_title">
				医院属性
			</view>
			<map class="map" :longitude="108.884948" :latitude="34.149287"></map>
			<view class="maxbox">
				<view class="p-top">
					<u-icon color="#9C9C9C" name="map-fill"></u-icon>
					<span>位置:</span>
					<p>{{teamdetail.address}}</p>
				</view>
				<view class="p-bottom">
					<u-icon color="#9C9C9C" name="grid-fill"></u-icon>
					<span>类型:</span>
					<p>{{teamdetail.type}}</p>
				</view>
			</view>
		</view>

		<view class="content">
			<view class="content_title">
				相关服务
			</view>
			<view class="box">
				<view class="left">
					<image src="http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529649395871788.png"></image>
				</view>
				<view class="right">
					<view class="right-top">
						<text class="title">基础就医</text>
						<text class="part">门诊</text>
					</view>
					<view class="right-bottom">
						<view class="numbers">
							预约人数:<text class="qycolor">45</text>
						</view>
					</view>
				</view>
				<view class="button_box">
					<button class="button" type="default" size="mini" @click="goReserve()">一键预约</button>
				</view>
			</view>
			<view class="box box-second">
				<view class="left">
					<image src="http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529648407658960.png"></image>
				</view>
				<view class="right">
					<view class="right-top">
						<text class="title">路线导航</text>
						<text class="part">高德</text>
					</view>
					<view class="right-bottom">
						<view class="numbers">
							公交地图
						</view>
					</view>
				</view>
				<view class="button_box">
					<button class="button" type="default" size="mini">立即前往</button>
				</view>
			</view>

		</view>
	</view>
</template>

<script>
	export default {
		name: "detail",
		data() {
			return {
				teamdetail: [],
				lastDetail: {},
				package: {},
				value1:5
			}
		},
		onLoad(option) {
			this.teamdetail = JSON.parse(option.id)
			console.log(this.teamdetail)
		},
		methods: {
			goReserve() {
				uni.navigateTo({
					url: '../reserve/reserve'
				})
			}
		}
	}
</script>

<style lang="less" scoped>
	.details_box {
		background-color: #F6FAFD;
	}

	/* top */
	.top {
		background-color: #F7FAFD;
		padding: 20rpx;
		display: flex;
		justify-content: space-around;
	}

	.img_box {
		overflow: hidden;
		width: 240rpx;
		height: 240rpx;
		border-radius: 24rpx;
		border: 1px solid #CEE2FC;
	}

	.top_img {
		width: 240rpx;
		height: 240rpx;
	}

	.top_right {
		width: 380rpx;
		height: 240rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
	}

	.arderrs {
		display: flex;
		justify-content: flex-start;
		height: 45rpx;
		line-height: 45rpx;
	}

	.arderrs_text {
		font-size: 12px;
		margin-right: 20rpx;
		color: #9C9C9C;
	}

	.top_people {
		overflow: hidden;
		font-size: 12px;
		color: #9C9C9C;
	}

	.top_people>text {
		color: #3ba88e;
	}

	/* 标签渲染 */
	.tag_box {
		display: flex;
		margin-top: 25rpx;
		align-items: center;
		flex-wrap: wrap;
		padding-left: 38rpx;
	}

	.tag {
		font-size: 14px;
		border-radius: 8px;
		height: 64rpx;
		line-height: 64rpx;
		text-align: center;
		padding: 0rpx 20rpx;
		margin-right: 20rpx;
		font-weight: 500;
	}

	uni-map {
		display: flex;
		margin: 0 auto;
		height: 400rpx;
	}

	/* 医生团队 */
	.content_title {
		margin: 20rpx 0 30rpx 15rpx;
		font-size: 40rpx;
		font-weight: 500;
	}

	.button {
		background-color: #3ba88e;
		border-radius: 8px;
		color: white;
	}

	.maxbox {
		display: flex;
		flex-direction: column;
		justify-content: space-evenly;
		align-items: center;
		padding: 10rpx;

		.span {
			padding: 12rpx;
		}
	}

	.p-bottom {
		display: flex;
		padding: 6rpx;
		margin: 3rpx;
		align-items: baseline;

		span {
			color: #9C9C9C;
			margin-right: 10rpx;
		}

		p {
			color: #9C9C9C;
		}
	}

	.p-top {
		display: flex;
		padding: 6rpx;
		margin: 3rpx;
		align-items: baseline;

		span {
			color: #9C9C9C;
			margin-right: 10rpx;
		}

		p {
			color: #9C9C9C;
		}
	}


	.box {
		display: flex;
		justify-content: space-evenly;
		align-items: center;
		background-color: white;
		box-sizing: border-box;
		border-radius: 10px;
		width: 94%;
		margin: 0 auto;
		margin-bottom: 20rpx;
		box-shadow: 0 0 10rpx rgba(0, 0, 0, .1);

		.left {
			
			border-radius: 20rpx;
			uni-image {
				width: 150rpx;
				height: 150rpx;
				padding: 20rpx;
			}
		}

		.right {
			display: flex;
			flex-direction: column;

			.title {
				margin-right: 20rpx;
				font-size: 38rpx
			}

			.part {
				color: #6d6d6d;
			}

			.right-bottom {
				margin-top: 30rpx;

				.numbers {
					color: #6d6d6d;

					.qycolor {
						margin-left: 10rpx;
						color: #3ba88e;
					}
				}
			}
		}
	}

	.box-second {
		.button {
			background-color: #007AFF;
			border-radius: 8px;
			color: white;
		}
	}
</style>
