<template>
  <view class="login-container">
    <!-- 顶部波浪背景 -->
    <view class="wave-container">
      <image src="https://img.freepik.com/free-vector/abstract-blue-wave-background_53876-88677.jpg" mode="widthFix" class="wave-bg"></image>
      <view class="app-title-container">
        <image src="https://img.icons8.com/ios-filled/100/ffffff/heart-health.png" class="app-icon"></image>
        <view class="app-title">心 安</view>
        <view class="app-subtitle">您的健康守护者</view>
      </view>
    </view>
    
    <!-- 登录内容区域 -->
    <view class="login-content">
      <!-- 欢迎语 -->
      <view class="welcome-section">
        <view class="welcome-title">欢迎回来</view>
        <view class="welcome-subtitle">请登录您的账号</view>
      </view>
      
      <!-- 登录表单 -->
      <view class="login-form">
        <u-form :rules="rules" :model="form" errorType="message" ref="loginFormRef">
          <!-- 用户名输入 -->
          <u-form-item prop="username" label-width="0px">
            <view class="input-container" :class="{'input-focused': usernameFocused}">
              <u-icon name="account" color="#4a90e2" size="20"></u-icon>
              <u-input
                v-model="form.username"
                placeholder="请输入手机号/用户名"
                placeholderClass="placeholder-style"
                border="none"
                clearable
                @focus="usernameFocused = true"
                @blur="usernameFocused = false"
              ></u-input>
            </view>
          </u-form-item>
          
          <!-- 密码输入 -->
          <u-form-item prop="password" label-width="0px">
            <view class="input-container" :class="{'input-focused': passwordFocused}">
              <u-icon name="lock" color="#4a90e2" size="20"></u-icon>
              <u-input
                v-model="form.password"
                :type="showPassword ? 'text' : 'password'"
                placeholder="请输入密码"
                placeholderClass="placeholder-style"
                border="none"
                clearable
                @focus="passwordFocused = true"
                @blur="passwordFocused = false"
              ></u-input>
              <u-icon 
                :name="showPassword ? 'eye-fill' : 'eye-off'" 
                color="#4a90e2" 
                size="20"
                @click="togglePasswordVisibility"
              ></u-icon>
            </view>
          </u-form-item>
        </u-form>
        
        <!-- 辅助功能 -->
        <view class="auxiliary-actions">
          <view class="remember-pwd">
            <u-checkbox 
              v-model="rememberPwd" 
              shape="circle" 
              activeColor="#4a90e2"
              iconSize="18"
            ></u-checkbox>
            <text>记住密码</text>
          </view>
          <view class="forgot-pwd" @click="findPwd">
            <text>忘记密码?</text>
          </view>
        </view>
        
        <!-- 登录按钮 -->
        <u-button 
          class="login-btn" 
          shape="circle" 
          text="登 录" 
          color="#4a90e2"
          @click="submit"
          :loading="loading"
          :customStyle="{
            boxShadow: '0 10rpx 20rpx rgba(74, 144, 226, 0.3)',
            transform: loginBtnScale,
            transition: 'transform 0.2s ease'
          }"
          @touchstart="loginBtnScale = 'scale(0.98)'"
          @touchend="loginBtnScale = 'scale(1)'"
        ></u-button>
        
        <!-- 社交登录 - 使用u-icon组件 -->
        <view class="social-login">
          <view class="divider">
            <view class="divider-line"></view>
            <view class="divider-text">或使用以下方式登录</view>
            <view class="divider-line"></view>
          </view>
          <view class="social-icons">
            <view class="social-icon-container" @click="wechatLogin">
              <u-icon name="weixin-fill" color="#09BB07" size="28"></u-icon>
              <view class="social-icon-text">微信</view>
            </view>

            <view class="social-icon-container" @click="qqLogin">
              <u-icon name="qq-fill" color="#12B7F5" size="28"></u-icon>
              <view class="social-icon-text">QQ</view>
            </view>

            <view class="social-icon-container" @click="appleLogin">
              <u-icon name="apple-fill" color="#333" size="28"></u-icon>
              <view class="social-icon-text">Apple</view>
            </view>
          </view>
        </view>
        
        <!-- 注册引导 -->
        <view class="register-guide">
          <text>还没有账号?</text>
          <text class="register-link" @click="register">立即注册</text>
        </view>
      </view>
    </view>
    
    <!-- 底部装饰 -->
    <view class="bottom-decoration">
      <image src="https://img.freepik.com/free-vector/medical-healthcare-pattern-background_53876-93121.jpg" mode="widthFix" class="decoration-img"></image>
    </view>
  </view>
</template>
<script>
export default {
  data() {
    return {
      form: {
        username: '',
        password: ''
      },
      rememberPwd: false,
      showPassword: false,
      usernameFocused: false,
      passwordFocused: false,
      loading: false,
      loginBtnScale: 'scale(1)',
      rules: {
        username: [
          { 
            required: true, 
            message: '请输入手机号/用户名', 
            trigger: ['blur', 'change'] 
          },
          {
            pattern: /^1[3-9]\d{9}$|^[a-zA-Z0-9_-]{4,16}$/,
            message: '请输入正确的手机号或用户名',
            trigger: ['blur', 'change']
          }
        ],
        password: [
          { 
            required: true, 
            message: '请输入密码', 
            trigger: ['blur', 'change'] 
          },
          {
            minLength: 6,
            message: '密码长度不能少于6位',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
  },
  methods: {
    submit() {
	  console.log("wwww")
    
          this.loading = true;
          uni.showLoading({
            title: '登录中...',
            mask: true
          });
          
          // 直接调用后端登录接口
          uni.request({
            url: 'http://localhost:8000/base/login/', // 替换为你的实际后端地址
            method: 'POST',
            data: this.form,
            header: {
              'content-type': 'application/json' // 根据后端需求调整
            },
            success: (res) => {
              console.log('登录请求成功:', res); // 添加日志输出
              uni.hideLoading();
              if (res.statusCode === 200 && res.data.code === 200) {
                uni.$u.toast('登录成功');
                
                // 保存登录状态
                this.$store.commit('user/SET_USER', {
                  username: this.form.username,
                  isLogin: true
                });
                
                // 记住密码处理
                if (this.rememberPwd) {
                  uni.setStorageSync('rememberedAccount', {
                    username: this.form.username,
                    password: this.form.password
                  });
                } else {
                  uni.removeStorageSync('rememberedAccount');
                }
                
                uni.reLaunch({ url: '/pages/index/index' });
              } else {
                uni.$u.toast(res.data.msg || '登录失败');
              }
            },
            fail: (err) => {
              console.error('登录请求失败:', err); // 添加日志输出
              uni.hideLoading();
              uni.$u.toast('网络错误，请稍后重试');
            },
            complete: () => {
              this.loading = false;
            }
          });
        
      
    },

    register() {
      uni.navigateTo({ 
        url: '/pages/register/register',
        animationType: 'slide-in-right',
        animationDuration: 300
      });
    },
    findPwd() {
      uni.navigateTo({ 
        url: '/pages/pwd/pwd',
        animationType: 'slide-in-right',
        animationDuration: 300
      });
    },
    togglePasswordVisibility() {
      this.showPassword = !this.showPassword;
    },
    wechatLogin() {
      uni.showToast({
        title: '微信登录',
        icon: 'none'
      });
    },
    qqLogin() {
      uni.showToast({
        title: 'QQ登录',
        icon: 'none'
      });
    },
    appleLogin() {
      uni.showToast({
        title: 'Apple登录',
        icon: 'none'
      });
    }
  },
  onLoad() {
    const rememberedAccount = uni.getStorageSync('rememberedAccount');
    if (rememberedAccount) {
      this.form = rememberedAccount;
      this.rememberPwd = true;
    }
  }
}
</script>
<style lang="scss" scoped>
.login-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: linear-gradient(to bottom, #f7faff, #ffffff);
  position: relative;
  overflow: hidden;
  
  .wave-container {
    position: relative;
    height: 380rpx;
    overflow: hidden;
    
    .wave-bg {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .app-title-container {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
      width: 100%;
      
      .app-icon {
        width: 80rpx;
        height: 80rpx;
        margin-bottom: 15rpx;
        filter: drop-shadow(0 4rpx 8rpx rgba(0, 0, 0, 0.1));
      }
      
      .app-title {
        font-family: 'STKaiti', '楷体', serif;
        font-size: 72rpx;
        font-weight: bold;
        color: #fff;
        text-shadow: 0 4rpx 8rpx rgba(0, 0, 0, 0.2);
        letter-spacing: 10rpx;
        margin-bottom: 10rpx;
      }
      
      .app-subtitle {
        font-size: 28rpx;
        color: rgba(255, 255, 255, 0.9);
        letter-spacing: 2rpx;
      }
    }
  }
  
  .login-content {
    flex: 1;
    padding: 40rpx 50rpx;
    display: flex;
    flex-direction: column;
    margin-top: -20rpx;
    background-color: #fff;
    border-radius: 40rpx 40rpx 0 0;
    box-shadow: 0 -10rpx 30rpx rgba(0, 0, 0, 0.05);
    z-index: 1;
    
    .welcome-section {
      margin-bottom: 60rpx;
      
      .welcome-title {
        font-size: 48rpx;
        font-weight: bold;
        color: #333;
        margin-bottom: 10rpx;
      }
      
      .welcome-subtitle {
        font-size: 28rpx;
        color: #999;
      }
    }
    
    .login-form {
      flex: 1;
      width: 100%;
      
      .input-container {
        display: flex;
        align-items: center;
        background-color: #f8f9fa;
        border-radius: 50rpx;
        padding: 25rpx 35rpx;
        margin-bottom: 30rpx;
        width: 100%;
        box-sizing: border-box;
        border: 2rpx solid #e9ecef;
        transition: all 0.3s ease;
        
        &.input-focused {
          border-color: #4a90e2;
          box-shadow: 0 0 0 4rpx rgba(74, 144, 226, 0.2);
        }
        
        .u-icon {
          margin-right: 20rpx;
        }
        
        ::v-deep .u-input {
          flex: 1;
          font-size: 32rpx;
          min-height: 50rpx;
          background-color: transparent;
        }
        
        ::v-deep .placeholder-style {
          color: #adb5bd;
          font-size: 32rpx;
        }
      }
      
      .auxiliary-actions {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 30rpx 0 60rpx;
        font-size: 28rpx;
        
        .remember-pwd {
          display: flex;
          align-items: center;
          color: #666;
          
          ::v-deep .u-checkbox__icon {
            margin-right: 10rpx;
          }
        }
        
        .forgot-pwd {
          color: #4a90e2;
          font-weight: 500;
        }
      }
      
      .login-btn {
        height: 90rpx;
        font-size: 36rpx;
        letter-spacing: 5rpx;
        margin-bottom: 40rpx;
        width: 100%;
        border: none;
        font-weight: 500;
        
        ::v-deep .u-button__text {
          letter-spacing: 5rpx;
        }
      }
      
      .social-login {
        margin: 60rpx 0 40rpx;
        
        .divider {
          display: flex;
          align-items: center;
          margin-bottom: 40rpx;
          
          .divider-line {
            flex: 1;
            height: 1rpx;
            background-color: #e9ecef;
          }
          
          .divider-text {
            padding: 0 30rpx;
            font-size: 26rpx;
            color: #adb5bd;
          }
        }
        
        .social-icons {
          display: flex;
          justify-content: center;
          gap: 60rpx;
          
          .social-icon-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 10rpx 20rpx;
            
            .u-icon {
              margin-bottom: 10rpx;
            }
            
            .social-icon-text {
              font-size: 24rpx;
              color: #666;
            }
            
            &:active {
              opacity: 0.7;
            }
          }
        }
      }
      
      .register-guide {
        text-align: center;
        color: #999;
        font-size: 28rpx;
        margin-top: 20rpx;
        
        .register-link {
          color: #4a90e2;
          margin-left: 10rpx;
          font-weight: 500;
        }
      }
    }
  }
  
  .bottom-decoration {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 120rpx;
    overflow: hidden;
    z-index: 0;
    
    .decoration-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 0.8;
    }
  }
}
</style>