<template>
  <view class="pwd-container">
    <!-- 顶部波浪背景 - 与登录页保持一致 -->
    <view class="wave-container">
      <image src="https://img.freepik.com/free-vector/abstract-blue-wave-background_53876-88677.jpg" mode="widthFix" class="wave-bg"></image>
      <view class="app-title-container">
        <image src="https://img.icons8.com/ios-filled/100/ffffff/heart-health.png" class="app-icon"></image>
        <view class="app-title">找回密码</view>
        <view class="app-subtitle">重置您的账户密码</view>
      </view>
    </view>
    
    <!-- 找回密码内容区域 -->
    <view class="pwd-content">
      <u-form :rules="rules" :model="form" errorType="message" ref="pwdFormRef">
        <!-- 账号输入 -->
        <u-form-item prop="username" label-width="0px">
          <view class="input-container" :class="{'input-focused': usernameFocused}">
            <u-icon name="account" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.username"
              placeholder="请输入账号"
              placeholderClass="placeholder-style"
              border="none"
              clearable
              @focus="usernameFocused = true"
              @blur="usernameFocused = false"
            ></u-input>
          </view>
        </u-form-item>
        
        <!-- 邮箱输入 -->
        <u-form-item prop="email" label-width="0px">
          <view class="input-container" :class="{'input-focused': emailFocused}">
            <u-icon name="email" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.email"
              placeholder="请输入邮箱"
              placeholderClass="placeholder-style"
              border="none"
              clearable
              @focus="emailFocused = true"
              @blur="emailFocused = false"
            ></u-input>
          </view>
        </u-form-item>
        
        <!-- 新密码输入 -->
        <u-form-item prop="newPassword" label-width="0px">
          <view class="input-container" :class="{'input-focused': newPasswordFocused}">
            <u-icon name="lock" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.newPassword"
              :type="showNewPassword ? 'text' : 'password'"
              placeholder="请输入新密码"
              placeholderClass="placeholder-style"
              border="none"
              clearable
              @focus="newPasswordFocused = true"
              @blur="newPasswordFocused = false"
            ></u-input>
            <u-icon 
              :name="showNewPassword ? 'eye-fill' : 'eye-off'" 
              color="#4a90e2" 
              size="20"
              @click="showNewPassword = !showNewPassword"
            ></u-icon>
          </view>
        </u-form-item>
        
        <!-- 确认密码输入 -->
        <u-form-item prop="passwordAgain" label-width="0px">
          <view class="input-container" :class="{'input-focused': passwordAgainFocused}">
            <u-icon name="lock" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.passwordAgain"
              :type="showPasswordAgain ? 'text' : 'password'"
              placeholder="请再次输入新密码"
              placeholderClass="placeholder-style"
              border="none"
              clearable
              @focus="passwordAgainFocused = true"
              @blur="passwordAgainFocused = false"
            ></u-input>
            <u-icon 
              :name="showPasswordAgain ? 'eye-fill' : 'eye-off'" 
              color="#4a90e2" 
              size="20"
              @click="showPasswordAgain = !showPasswordAgain"
            ></u-icon>
          </view>
        </u-form-item>
        
        <!-- 验证码输入 -->
        <u-form-item prop="code" label-width="0px">
          <view class="input-container code-container" :class="{'input-focused': codeFocused}">
            <u-icon name="shield" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.code"
              placeholder="请输入验证码"
              placeholderClass="placeholder-style"
              border="none"
              @focus="codeFocused = true"
              @blur="codeFocused = false"
            ></u-input>
            <u-button
              class="code-btn"
              @tap="getCode"
              :text="tips"
              size="mini"
              :disabled="disabled"
              :customStyle="{
                backgroundColor: '#4a90e2',
                color: '#fff',
                border: 'none',
                boxShadow: '0 4rpx 12rpx rgba(74, 144, 226, 0.3)'
              }"
            ></u-button>
            <u-code
              ref="uCode"
              @change="codeChange"
              keep-running
              change-text="倒计时XS"
              @start="disabled = true"
              @end="disabled = false"
              seconds="30"
              start-text="获取验证码"
              end-text="重新获取"
            ></u-code>
          </view>
        </u-form-item>
      </u-form>
      
      <!-- 提交按钮 -->
      <u-button 
        class="submit-btn" 
        shape="circle" 
        text="提 交" 
        color="#4a90e2"
        @click="submit"
        :loading="loading"
        :customStyle="{
          boxShadow: '0 10rpx 20rpx rgba(74, 144, 226, 0.3)',
          transform: submitBtnScale,
          transition: 'transform 0.2s ease',
          marginTop: '60rpx'
        }"
        @touchstart="submitBtnScale = 'scale(0.98)'"
        @touchend="submitBtnScale = 'scale(1)'"
      ></u-button>
      
      <!-- 返回登录 -->
      <view class="back-login">
        <text>想起密码了?</text>
        <text class="login-link" @click="backToLogin">返回登录</text>
      </view>
    </view>
    
    <!-- 底部装饰 - 与登录页保持一致 -->
    <view class="bottom-decoration">
      <image src="https://img.freepik.com/free-vector/medical-healthcare-pattern-background_53876-93121.jpg" mode="widthFix" class="decoration-img"></image>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      form: {
        username: '',
        email: '',
        newPassword: '',
        passwordAgain: '',
        code: ''
      },
      tips: '',
      disabled: false,
      loading: false,
      submitBtnScale: 'scale(1)',
      usernameFocused: false,
      emailFocused: false,
      newPasswordFocused: false,
      passwordAgainFocused: false,
      codeFocused: false,
      showNewPassword: false,
      showPasswordAgain: false,
      rules: {
        username: {
          type: 'string',
          required: true,
          message: '账号不能为空',
          trigger: ['change', 'blur']
        },
        email: [
          {
            type: 'string',
            required: true,
            message: '邮箱不能为空',
            trigger: ['change', 'blur']
          },
          {
            type: 'email',
            required: true,
            message: '请输入正确的邮箱格式',
            trigger: ['change', 'blur']
          }
        ],
        newPassword: [
          {
            type: 'string',
            required: true,
            message: '新密码不能为空',
            trigger: ['change', 'blur']
          },
          {
            minLength: 6,
            message: '密码长度不能少于6位',
            trigger: ['change', 'blur']
          }
        ],
        passwordAgain: [
          {
            type: 'string',
            required: true,
            message: '请再次输入新密码',
            trigger: ['change', 'blur']
          },
          {
            validator: (rule, value, callback) => {
              if (value === this.form.newPassword) {
                callback();
              } else {
                callback(new Error('两次输入的密码不一致'));
              }
            },
            trigger: ['change', 'blur']
          }
        ],
        code: [
          {
            type: 'string',
            required: true,
            message: '验证码不能为空',
            trigger: ['change', 'blur']
          },
          {
            type: 'string',
            len: 6,
            message: '验证码为6位数字',
            trigger: ['change', 'blur']
          }
        ]
      }
    }
  },
  methods: {
    submit() {
      this.$refs.pwdFormRef.validate(valid => {
        if (valid) {
          this.loading = true;
          uni.showLoading({
            title: '提交中...',
            mask: true
          });
          
          // 这里调用找回密码的API
          setTimeout(() => {
            uni.hideLoading();
            uni.$u.toast('密码重置成功');
            this.backToLogin();
          }, 1500);
        }
      });
    },
    codeChange(text) {
      this.tips = text;
    },
    getCode() {
      // 验证邮箱格式
      if (!this.form.email) {
        uni.$u.toast('请输入邮箱地址');
        return;
      }
      
      if (!/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(this.form.email)) {
        uni.$u.toast('邮箱格式不正确');
        return;
      }
      
      // 开始倒计时
      this.$refs.uCode.start();
      
      // 这里调用获取验证码的API
      uni.$u.toast('验证码已发送至您的邮箱');
    },
    backToLogin() {
      uni.navigateBack();
    }
  }
}
</script>

<style lang="scss" scoped>
.pwd-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: linear-gradient(to bottom, #f7faff, #ffffff);
  position: relative;
  overflow: hidden;
  
  .wave-container {
    position: relative;
    height: 380rpx;
    overflow: hidden;
    
    .wave-bg {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .app-title-container {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
      width: 100%;
      
      .app-icon {
        width: 80rpx;
        height: 80rpx;
        margin-bottom: 15rpx;
        filter: drop-shadow(0 4rpx 8rpx rgba(0, 0, 0, 0.1));
      }
      
      .app-title {
        font-family: 'STKaiti', '楷体', serif;
        font-size: 52rpx;
        font-weight: bold;
        color: #fff;
        text-shadow: 0 4rpx 8rpx rgba(0, 0, 0, 0.2);
        letter-spacing: 10rpx;
        margin-bottom: 10rpx;
      }
      
      .app-subtitle {
        font-size: 28rpx;
        color: rgba(255, 255, 255, 0.9);
        letter-spacing: 2rpx;
      }
    }
  }
  
  .pwd-content {
    flex: 1;
    padding: 40rpx 50rpx;
    display: flex;
    flex-direction: column;
    margin-top: -20rpx;
    background-color: #fff;
    border-radius: 40rpx 40rpx 0 0;
    box-shadow: 0 -10rpx 30rpx rgba(0, 0, 0, 0.05);
    z-index: 1;
    
    .input-container {
      display: flex;
      align-items: center;
      background-color: #f8f9fa;
      border-radius: 50rpx;
      padding: 25rpx 35rpx;
      margin-bottom: 10rpx;
      width: 100%;
      box-sizing: border-box;
      border: 2rpx solid #e9ecef;
      transition: all 0.3s ease;
      
      &.input-focused {
        border-color: #4a90e2;
        box-shadow: 0 0 0 4rpx rgba(74, 144, 226, 0.2);
      }
      
      .u-icon {
        margin-right: 20rpx;
      }
      
      ::v-deep .u-input {
        flex: 1;
        font-size: 32rpx;
        min-height: 50rpx;
        background-color: transparent;
      }
      
      ::v-deep .placeholder-style {
        color: #adb5bd;
        font-size: 32rpx;
      }
      
      &.code-container {
        padding-right: 20rpx;
        
        .code-btn {
          width: 200rpx;
          height: 60rpx;
          margin-left: 20rpx;
          border-radius: 30rpx;
          
          ::v-deep .u-button__text {
            font-size: 26rpx;
          }
        }
      }
    }
    
    .submit-btn {
      height: 90rpx;
      font-size: 36rpx;
      letter-spacing: 5rpx;
      width: 100%;
      border: none;
      font-weight: 500;
      
      ::v-deep .u-button__text {
        letter-spacing: 5rpx;
      }
    }
    
    .back-login {
      text-align: center;
      color: #999;
      font-size: 28rpx;
      margin-top: 40rpx;
      
      .login-link {
        color: #4a90e2;
        margin-left: 10rpx;
        font-weight: 500;
      }
    }
  }
  
  .bottom-decoration {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 120rpx;
    overflow: hidden;
    z-index: 0;
    
    .decoration-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 0.8;
    }
  }
}
</style>