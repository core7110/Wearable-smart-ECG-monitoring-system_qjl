<template>
	<view>
		<view class="mechanism_top">
			<image class="locate" src="../../static/icon/treamentLocate.png" @click="getCurrent()"></image>
			<view class="city">西安</view>
			<view class="top_input_box">
				<image src="../../static/icon/search.png"  class="input_icon" mode=""></image>
				<text class="top_input">搜索机构/医生</text>
			</view>
		</view>
		<view class="content">
			<view class="content_box" v-for="(item,index) in hosptals" :key="item.id" @click="goDetails(item)">
				<image class="imgs" src="https://s3.bmp.ovh/imgs/2021/11/e3712d4f641e9ce8.png" mode="scaleToFill"></image>
				<text class="content_text">{{item.name}}</text>
				<text class="content_distance">距您{{item.distance}}m</text>
				<image src="../../static/icon/right.png" class="content_box_icon" mode=""></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "treat",
		data() {
			return {
				map: '',
				hosptals:[],
				input_value: "",
				cityname:''
			}
		},
		onLoad() {
			this.getDistance()
			this.getCurrent()
			this.getCity()
		},
		methods: {
			getCity(){
				uni.request({
					url:'https://restapi.amap.com/v3/ip?key=04180bd5c0a4a741dfc090480a6df36fkey',
					success: (res) => {
						
						console.log(res)
						console.log('1111')
					    }
				})
			},
			goDetails(item){
				const pid = item
				uni.navigateTo({
				url: '../hosptal/hosptal?id='+encodeURIComponent(JSON.stringify(pid)) ,
					 success: res => {
						res.eventChannel.emit('acceptDataFromOpenerPage', {
							data: [this.pid]
							})
							}
						})
					console.log(pid)
			},
			getCurrent(){
				uni.getLocation({
					type: 'wgs84',
					success: function (res) {
						console.log('当前位置的经度：' + res.longitude);
						console.log('当前位置的纬度：' + res.latitude);
						 uni.$u.vuex('vuex_longi', res.longitude)
						uni.$u.vuex('vuex_lati', res.latitude)
					}
				});
				this.getDistance()
			},
			getDistance(){
				
				console.log(this.vuex_longi)
				uni.request({
					url:`https://restapi.amap.com/v3/place/around?location=${this.vuex_longi},${this.vuex_lati}&keywords=&types=090100&radius=2500&offset=20&page=1&extensions=base&key=04180bd5c0a4a741dfc090480a6df36f`,
					success: (res) => {
						
						this.hosptals = res.data.pois
						console.log(this.hosptals)
					    }
				})
			},
		}
	}
</script>

<style lang="less" scoped>
	.bottom{
		width: 200rpx;
		height: 200rpx;
		background-color: pink;
		color: white;
		line-height: 200rpx;
		text-align: center;
	}
	.city{
		float: right;
		margin-right: 16rpx;
		color: #3ba88e;
		font-size: 30rpx;
	}

	/* 头部搜索框 */
	* {
		padding: 0;
		margin: 0;
	}

	.mechanism_top {
		width: 100%;
		height: 95rpx;
		line-height: 95rpx;
		text-align: center;
		position: sticky;
		background-color: #FFFFFF;
		top: 0rpx;
		z-index: 9;
		.locate{
			width: 60rpx;
			height: 60rpx;
			position: absolute;
			left: 20rpx;
			top: 20rpx;
		}
	}

	.top_input_box {
		border: 1px solid #EAF3FE;
		border-radius: 10rpx;
		position: absolute;
		top: 10rpx;
		left: calc(50% - 275rpx);
		width: 550rpx;
		height: 70rpx;
		line-height: 70rpx;
	}

	.top_icon {
		position: absolute;
		left: 10px;
	}

	.top_input {
		display: block;
		font-size: 14px;
		text-align: left;
		color: #CCD0DB;
		height: 70rpx;
		padding-left: 70rpx;
	}

	.input_icon {
		position: absolute;
		left: 10rpx;
		top: 14rpx;
		width: 20px;
		height: 20px;
	}

	/* 机构渲染类容 */
	.content {
		background-color: #F4F8FD;
		width: 100%;
		display: flex;
		padding: 10rpx 0;
		justify-content: space-around;
		flex-direction: column;
		align-items: center;
		flex-wrap: wrap;
	}

	.content_box {
		width: 92%;
		height: 228rpx;
		margin: 10rpx 0;
		position: relative;
		padding: 20rpx 30rpx;
		background-color: #FFFFFF;
		border-radius: 24rpx;
		box-sizing: border-box;
		box-shadow: 0px 0px 15px rgb(41 132 248 / 10%);
	}

	.imgs {
		width: 160rpx;
		height: 160rpx;
		margin-top: 20rpx;
	}

	.content_box_icon {
		position: absolute;
		right: 20rpx;
		width: 20px;
		height: 20px;
		bottom: 30rpx;
	}

	.content_text {
		width: 380rpx;
		color: #333333;
		font-size: 16px;
		line-height: 45rpx;
		position: absolute;
		top: 50rpx;
		left: 220rpx;
	}

	.content_distance {
		position: absolute;
		bottom: 40rpx;
		left: 220rpx;
		color: #999999;
		font-size: 12px
	}
</style>
