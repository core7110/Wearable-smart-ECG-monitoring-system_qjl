<template>
	<view class="content">
		<ul class="articleMain">
			<li class="article" v-for="item in this.newsData" @click="handleDetail(item.paperId)">
				<div class="iamge">
					<u--image :src="item.image" radius="20" width="200rpx" height="200rpx"></u--image>
				</div>
				<div class="text">
					<p>{{item.title}}</p>
					<p>{{item.author}}<span class="tag">{{item.target}}类</span></p>
					<p>{{item.publishDate}}</p>
				</div>
				<image src="../../static/icon/right.png" mode="" class="right">
				</image>
			</li>
		</ul>
	</view>

</template>

<script>
	import {
		getCollectionArticle,
	} from '@/config/api.js'
	export default {
		data() {
			return {
				isShow: false,
				newsData: [],
				title: '你好，uniapp',
				// 导航栏文字
				nav_title: '我是导航栏',
				// 是否包含状态栏
				status_bar: true,
				list: [
					'https://liyun-oss1.oss-cn-beijing.aliyuncs.com/medicine/pic/3.png',
					'https://liyun-oss1.oss-cn-beijing.aliyuncs.com/medicine/pic/1.jpg',
					'https://liyun-oss1.oss-cn-beijing.aliyuncs.com/medicine/pic/2.png',
					'https://liyun-oss1.oss-cn-beijing.aliyuncs.com/medicine/pic/4.jpg'
				],
				articleIamge: [
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529658134801406.png',
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529658864265309.png',
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529659461767940.png',
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529660074933715.png',
					'http://exam-1.oss-cn-beijing.aliyuncs.com/png/2022/05/19/16529661797101070.png'
				]
			}
		},
		onLoad() {
			// 获取首页文章数据
			this.getCollectionArticleList()
		},
		methods: {
			// 获取文章列表
			async getCollectionArticleList() {
				const id = this.vuex_uid
				const {
					data
				} = await getCollectionArticle(id)
				const results = data.data
				this.newsData.push(...results)
				let i = 0;
				for (let j of this.newsData) {
					j.image = this.articleIamge[i%5];
					i = i + 1;
				}
			},// 跳转文章详情页
			handleDetail(id) {
				const pid = id
				uni.navigateTo({
					url: '../ariticle/ariticle?id=' + encodeURIComponent(JSON.stringify(pid))
				})
			}
		},
	}
</script>

<style lang="less" scoped>
	.content {
		background-color: #fff;
	}
	.nearHospital {
		margin: 0 auto;
		width: 95%;
		height: 200rpx;
		background-image: url(@/static/images/nearHospital.png);
		background-size: 100% 100%;
		border-radius: 10rpx;

		p:nth-of-type(1) {
			display: inline-block;
			width: 100%;
			margin: 40rpx 0 0 50rpx;
			font-size: 44rpx;
			font-weight: 600;
			color: rgba(0, 0, 0, .9);
		}

		p:nth-of-type(2),
		p:nth-of-type(3) {
			display: inline-block;
			width: 180rpx;
			height: 55rpx;
			border-radius: 30rpx;
			font-size: 34rpx;
			background-color: rgb(255, 184, 96);
			color: rgba(255, 255, 255, .9);
			text-align: center;
			line-height: 55rpx;
			margin-top: 20rpx;
		}

		p:nth-of-type(2) {
			margin-left: 40rpx;
			margin-right: 20rpx;
		}
	}

	.articleMain {
		width: 95%;
		margin: 20rpx auto 40rpx;
		// border: 1px solid black;
		padding: 0;

		li {
			list-style-type: none;
			height: 260rpx;
			// padding: 20rpx;
			box-shadow: 0 0 10rpx rgba(0, 0, 0, .2);
			background-color: #fff;
			border-radius: 10rpx;
			position: relative;
			margin-bottom: 40rpx;

			.iamge {
				width: 200rpx;
				height: 200rpx;
				margin: 30rpx 40rpx 30rpx 30rpx;
				display: inline-block;
			}

			.text {
				display: inline-block;
				width: 400rpx;
				position: relative;
				top: -26rpx;
				color: #404040;

				p:nth-of-type(1) {
					width: 400rpx;
					word-wrap: break-word;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 1;
					/* 限制在一个块元素显示的文本的行数 */
					-webkit-box-orient: vertical;
					/* 垂直排列 */
					overflow: hidden;
					// height: 44.8rpx;
					font-size: 34rpx;
					margin-bottom: 20rpx;
				}

				p:nth-of-type(2) {
					margin-bottom: 15rpx;

					.tag {
						display: inline-block;
						margin-left: 20rpx;
						color: #aaa0a0;
					}
				}

				// p:nth-of-type(3){
				// 	width: 100rpx;
				// 	height: 56rpx;
				// 	position: absolute;
				// 	bottom: 50rpx;
				// 	right: 60rpx;
				// }
				p:nth-of-type(3) {
					color: #aaa0a0;
					// font-size: rpx;
				}
			}

			.right {
				width: 50rpx;
				height: 50rpx;
				position: absolute;
				right: 20rpx;
				bottom: 45rpx;

			}
		}
	}

	page {
		background-color: #fff;
	}

	.u-search {
		margin-top: 20rpx !important;
		background-color: white;
	}

	.u-line {
		margin: 0 auto !important;
	}

	.uni-page-wrapper {
		background-color: #f6f6f6;
	}

	.mySwiper {
		margin-top: 30rpx;
	}

	.u-grid {
		margin-top: 60rpx;
	}


	.u-grid-item {
		border-radius: 10%;
		width: 26% !important;
		margin: 28rpx;
		box-shadow: 0rpx 5rpx 10rpx #888888;
	}

	.u-grid-item:hover {
		cursor: pointer;
	}

	.u-grid-item:nth-child(1) {
		background-color: #f56c6c !important;
	}

	.u-grid-item:nth-child(2) {
		background-color: #f9ae3d !important;
	}

	.u-grid-item:nth-child(3) {
		background-color: #5ac725 !important;
	}

	.infobox {
		width: 100%;
		height: 270rpx;
		margin-bottom: 10rpx;
		display: flex;
		justify-content: space-around;
	}

	.infobox view {
		margin-bottom: 10rpx;
	}

	.toutiao,
	.huli {
		height: 180rpx;
		width: 40%;
		position: relative;
		background-color: #EAF3FE;
		border-radius: 10%;
		padding: 20rpx;
		margin-top: 10rpx;
	}

	.toutiao image {
		width: 140rpx;
		height: 120rpx;
		position: absolute;
		right: 20rpx;
		bottom: 20rpx;
	}

	.title2 {
		font-size: 32rpx;
		color: grey;
		margin-top: 40rpx;
	}

	.title3 {
		font-size: 36rpx;
		font-weight: 500;
	}

	.title5 {
		margin-left: 50rpx;
		display: flex;
	}

	.title5:hover {
		color: black;
	}

	.huli image {
		width: 132rpx;
		height: 76rpx;
		position: absolute;
		right: 20rpx;
		bottom: 20rpx;
	}

	.till {
		display: flex;
		margin-left: 40rpx;
		font-size: 46rpx;
		margin-top: 40rpx;
		margin-bottom: 30rpx;

		p {
			position: relative;
			margin-left: 20rpx;

			span {
				display: inline-block;
				height: 85%;
				width: 15rpx;
				background-color: rgb(16, 173, 225);
				position: absolute;
				left: -30rpx;
				top: 12.5%;
			}
		}
	}


	// 没有
	.fwtx {
		width: 95%;
		margin: auto;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
		margin-bottom: 10rpx;
	}

	.fwtempo {
		width: 96%;
		height: 240rpx;
		border-radius: 10rpx;
		background-color: white;
		margin: auto;
		margin-top: 20rpx;
		position: relative;

		box-sizing: border-box;
		box-shadow: 0 0 10rpx rgba(0, 0, 0, .1);
		margin-bottom: 8rpx;
	}

	.iconinfo {
		position: absolute;
		top: 50rpx;
		left: 50rpx;
		width: 140rpx;
		height: 140rpx;
		background-color: #FFF8E4;
		text-align: center;
	}

	.iconinfo image {
		margin: auto;
		margin-top: 18rpx;
		width: 100%;
		height: 100%;
	}

	.textfw {
		width: 70%;
		height: 100rpx;
		/* background-color: #007AFF; */
		position: absolute;
		top: 50rpx;
		margin: 10rpx;
		left: 200rpx;

	}

	.fwpre {
		width: 32rpx;
		height: 32rpx;
		position: absolute;
		right: 20rpx;
		top: 50%;
		margin-top: -16rpx;
	}

	.fwpre image {
		width: 32rpx;
		height: 32rpx;
	}
</style>
