<template>
	<view class="details_box">
		<view class="top">
			<view class="img_box">
				<image class="top_img" :src="detail.imgUr2" mode="scaleToFill"></image>
			</view>
			<view class="top_right">
				<view class="top_title">
					{{detail.text}}
				</view>
				<view class="arderrs">
					<u-icon type="location-filled" color="#2984F8" size="15"></u-icon>
					<view class="arderrs_text">
						{{detail.adress}}
					</view>
					<u-icon type="arrowright" color="#9C9C9C" size="15"></u-icon>
				</view>
				<view class="tel_box" @click="tel">
					<image class="tel_img" src="https://s3.bmp.ovh/imgs/2021/11/0d89be7ae36346b2.png"
						mode="scaleToFill"></image>
				</view>
			</view>
		</view>
		<view class="content">
			<view class="content_title">
				机构简介
			</view>
			<view class="content_text">
				{{detail.introduction}}
			</view>
		</view>
		<view class="doctor content">
			<view class="content_title">
				医生团队
			</view>
			<view class="maxbox">
				<view class="content_box1" v-for="(item,index) in teamValue" :key="item.id" @tap="goTeamDetails(item)">
					<image class="imgs" :src="item.imgUrl" mode="scaleToFill"></image>
					<text class="content_text1">{{item.name}}</text>
					<view class="content_distance1">
						<text class="dis1">{{item.mechanism}}</text>
						<text>距您{{item.distance}}km</text>
					</view>
					<view class="score">
						<view class="score_icon">
							<!-- <uni-rate :is-fill="false" :disabled="true" disabledColor="#FDDB78" :margin="5" :size="16"
								:value="item.score" /> -->
						</view>
						<view class="score_text">
							{{item.score}}
						</view>
					</view>
					<u-icon class="content_box_icon" type="arrowright" color="#CCCCCC" size="25"></u-icon>
				</view>
			</view>
		</view>
		<view class="doctor content">
			<view class="content_title">
				服务包
			</view>
			<view class="maxbox">
				<view class="package_box" v-for="(item,index) in package" :key="item.id" @tap="goPackageDetails(item)">
					<image class="imgs2" :src="item.imgurl" mode="scaleToFill"></image>
					<view class="package_right">
						<text class="package_text">{{item.name}}</text>
						<view :class="item.class" class="package_tag">
							{{item.tag[0]}}
						</view>
					</view>
					<view class="package_price">
						<text>￥</text>{{item.price}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "detail",
		data() {
			return {
				detail: {},
				teamValue: [{
					id: 1,
					name: "李云龙团队",
					imgUrl: "https://s3.bmp.ovh/imgs/2021/11/375d7c7d5f6c4280.png",
					mechanism: "翡翠郡社区服务站",
					distance: "4.9",
					score: "4.5",
					people: "500",
					tag: [{
							id: 1,
							name: "慢病管理"
						},
						{
							id: 2,
							name: "中医服务"
						}, {
							id: 3,
							name: "老年人管理"
						}
					],
					teamDoctor: [{
							id: 1,
							name: "李明明",
							sex:"0",
							age:"28",
							number:"371456198908090543",
							tel:"15678909900",
							ardess:" 怀柔区洛西县建设路青莲小区6-601",
							role: "0",
							img:"https://s3.bmp.ovh/imgs/2021/11/a0f322e6e96a240d.png"
						},
						{
							id: 2,
							name: "王小倩",
							sex:"1",
							age:"28",
							number:"371456198908090543",
							tel:"15678909900",
							ardess:" 怀柔区洛西县建设路青莲小区6-601",
							role: "1",
							img:"https://s3.bmp.ovh/imgs/2021/11/a0f322e6e96a240d.png"
						},
						{
							id: 3,
							name: "高蓝",
							sex:"0",
							age:"48",
							number:"371456198908090543",
							tel:"15678909900",
							ardess:" 怀柔区洛西县建设路青莲小区6-601",
							role: "2",
							img:"https://s3.bmp.ovh/imgs/2021/11/a0f322e6e96a240d.png"
						}
					]
				}, {
					id: 2,
					name: "王天弋团队",
					imgUrl: "https://s3.bmp.ovh/imgs/2021/11/375d7c7d5f6c4280.png",
					mechanism: "翡翠郡社区服务站",
					distance: "4.9",
					score: "4.0",
					people: "500",
					tag: [{
							id: 1,
							name: "慢病管理"
						},
						{
							id: 2,
							name: "中医服务"
						}, {
							id: 3,
							name: "老年人管理"
						}
					],
					teamDoctor: [{
							id: 1,
							name: "李明明",
							sex:"0",
							age:"28",
							number:"371456198908090543",
							tel:"15678909900",
							ardess:" 怀柔区洛西县建设路青莲小区6-601",
							role: "0",
							img:"https://s3.bmp.ovh/imgs/2021/11/a0f322e6e96a240d.png"
						},
						{
							id: 2,
							name: "王小倩",
							sex:"1",
							age:"28",
							number:"371456198908090543",
							tel:"15678909900",
							ardess:" 怀柔区洛西县建设路青莲小区6-601",
							role: "1",
							img:"https://s3.bmp.ovh/imgs/2021/11/a0f322e6e96a240d.png"
						},
						{
							id: 3,
							name: "高林",
							sex:"0",
							age:"58",
							number:"371456198908090543",
							tel:"15678909900",
							ardess:" 怀柔区洛西县建设路黄莲小区6-601",
							role: "2",
							img:"https://s3.bmp.ovh/imgs/2021/11/a0f322e6e96a240d.png"
						}
					]
				}, {
					id: 3,
					name: "高晓松团队",
					imgUrl: "https://s3.bmp.ovh/imgs/2021/11/375d7c7d5f6c4280.png",
					mechanism: "翡翠郡社区服务站",
					distance: "4.9",
					score: "3.5",
					people: "500",
					tag: [{
							id: 1,
							name: "慢病管理"
						},
						{
							id: 2,
							name: "中医服务"
						}, {
							id: 3,
							name: "老年人管理"
						}
					],
					teamDoctor: [{
							id: 1,
							name: "李明",
							sex:"0",
							age:"28",
							number:"371456198908090543",
							tel:"15678909900",
							ardess:" 怀柔区洛西县建设路青莲小区6-601",
							role: "0",
							img:"https://s3.bmp.ovh/imgs/2021/11/a0f322e6e96a240d.png"
						},
						{
							id: 2,
							name: "王小倩",
							sex:"1",
							age:"25",
							number:"371456198908090543",
							tel:"15678909900",
							ardess:" 怀柔区洛西县建设路青莲小区6-601",
							role: "1",
							img:"https://s3.bmp.ovh/imgs/2021/11/a0f322e6e96a240d.png"
						},
						{
							id: 3,
							name: "刘小二",
							sex:"0",
							age:"29",
							number:"371456198908090543",
							tel:"15678909910",
							ardess:" 怀柔区洛西县建设路白莲小区6-601",
							role: "2",
							img:"https://s3.bmp.ovh/imgs/2021/11/a0f322e6e96a240d.png"
						}
					]
				}],
				package: [{
						id: 1,
						imgurl: "https://s3.bmp.ovh/imgs/2021/11/366908b9d2f43d62.png",
						imgurl2: "https://s3.bmp.ovh/imgs/2021/11/0e8bd981a807f80e.png",
						name: "基础包",
						class: "blue",
						price: "0",
						object: "适用于所有人",
						project: [{
								name: "高血压随访服务 ",
								number: "2次"
							},
							{
								name: "日常随访",
								number: "不限次数"
							},
							{
								name: "血糖测量",
								number: "不限次数"
							},
							{
								name: "血压测量",
								number: "2次"
							}
						],
						cycle: "一年",
						detail: "主要以基本医疗服务和公共卫生服务为主，如部分常见病或 多发病的治疗和用药指导、重症的就医指导和转诊预约、居民健康档案的管理和 慢病管理指导等。",
						tag: ["基础医疗"]
					},
					{
						id: 2,
						imgurl: "https://s3.bmp.ovh/imgs/2021/11/0290f63147f60607.png",
						imgurl2: "https://s3.bmp.ovh/imgs/2021/11/0e8bd981a807f80e.png",
						name: "0-6岁儿童服务包",
						class: "yellow",
						price: "120",
						object: "0-6岁儿童",
						project: [{
								name: "高血压随访服务 ",
								number: "2次"
							},
							{
								name: "日常随访",
								number: "不限次数"
							},
							{
								name: "血糖测量",
								number: "不限次数"
							},
							{
								name: "血压测量",
								number: "2次"
							}
						],
						cycle: "一年",
						detail: "主要以基本医疗服务和公共卫生服务为主，如部分常见病或 多发病的治疗和用药指导、重症的就医指导和转诊预约、居民健康档案的管理和 慢病管理指导等。",
						tag: ["儿童护理"]
					}, {
						id: 3,
						imgurl: "https://s3.bmp.ovh/imgs/2021/11/72471c33298ea6ce.png",
						imgurl2: "https://s3.bmp.ovh/imgs/2021/11/0e8bd981a807f80e.png",
						name: "老年人服务包",
						class: "green",
						price: "120",
						object: "55岁以上的老人",
						project: [{
								name: "高血压随访服务 ",
								number: "2次"
							},
							{
								name: "日常随访",
								number: "不限次数"
							},
							{
								name: "血糖测量",
								number: "不限次数"
							},
							{
								name: "血压测量",
								number: "2次"
							}
						],
						cycle: "一年",
						detail: "主要以基本医疗服务和公共卫生服务为主，如部分常见病或 多发病的治疗和用药指导、重症的就医指导和转诊预约、居民健康档案的管理和 慢病管理指导等。",
						tag: ["慢病管理", "中医服务", "老年人管理"]
					}
				]
			}
		},
		onLoad(options) {
			// #ifdef APP-NVUE
			const eventChannel = this.$scope.eventChannel; // 兼容APP-NVUE
			// #endif
			// #ifndef APP-NVUE
			const eventChannel = this.getOpenerEventChannel();
			// #endif
			// 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
			eventChannel.on('acceptDataFromOpenerPage', (data) => {
				this.detail = data.data[0];
				// console.log(this.detail);
			})
		},
		methods: {
			tel() {
				uni.makePhoneCall({
					// 手机号
					phoneNumber: '16090900080',
					// 成功回调
					success: (res) => {
						console.log('调用成功!')
					},
					// 失败回调
					fail: (res) => {
						console.log('调用失败!')
					}
				});
			},
			goTeamDetails(item) {
				uni.navigateTo({
					url: '../team/detail',
					success: res => {
						res.eventChannel.emit('acceptDataFromOpenerPage', {
							data: [this.detail, item, this.package]
						})
					},
					fail: () => {},
					complete: () => {}
				});
			},
			goPackageDetails(item) {
				// let value = JSON.stringify(item)
				uni.navigateTo({
					url: './packageDetail',
					success: res => {
						res.eventChannel.emit('acceptDataFromOpenerPage', {
							data: [this.detail, item]
						})
					},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
</script>

<style scoped>
	.details_box {
		background-color: #F6FAFD;
	}

	/* top */
	.top {
		background-color: #F7FAFD;
		padding: 20rpx;
		display: flex;
		justify-content: space-around;
	}

	.img_box {
		overflow: hidden;
		width: 240rpx;
		height: 240rpx;
		border-radius: 24rpx;
		border: 1px solid #CEE2FC;
	}

	.top_img {
		width: 240rpx;
		height: 240rpx;
	}

	.top_right {
		width: 380rpx;
		height: 240rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
	}

	.arderrs {
		display: flex;
		justify-content: space-around;
		height: 45rpx;
		line-height: 45rpx;
	}

	.arderrs_text {
		font-size: 12px;
		color: #9C9C9C;
	}

	.tel_box {
		overflow: hidden;
		border-radius: 15rpx;
		width: 48rpx;
		height: 48rpx;
	}

	.tel_img {
		width: 48rpx;
		height: 48rpx;
	}

	/* 机构简介 */
	.content {
		padding: 25rpx;
	}

	.content_title {
		font-size: 18px;
		margin-bottom: 30rpx;
	}

	.content_text {
		font-size: 14px;
		color: #999999;
		line-height: 180%;
	}

	/* 医生团队 */
	.doctor {
		margin-top: -20rpx;
	}

	.maxbox {
		width: 100%;
		display: flex;
		padding: 10rpx 0;
		justify-content: space-around;
		flex-direction: column;
		align-items: center;
		flex-wrap: wrap;
	}

	.content_box1 {
		width: 100%;
		height: 228rpx;
		margin: 10rpx 0;
		position: relative;
		padding: 20rpx 30rpx;
		background-color: #FFFFFF;
		border-radius: 24rpx;
		box-sizing: border-box;
		box-shadow: 0px 0px 15px rgb(41 132 248 / 10%);
	}

	.imgs {
		width: 160rpx;
		height: 160rpx;
		margin-top: 20rpx;
	}

	.content_box_icon {
		position: absolute;
		right: 20rpx;
		top: calc(50% - 25rpx);
	}

	.dis1 {
		margin-right: 10rpx;
	}

	.content_text1 {
		width: 380rpx;
		color: #333333;
		font-size: 16px;
		line-height: 45rpx;
		position: absolute;
		top: 50rpx;
		left: 220rpx;
	}

	.content_distance1 {
		position: absolute;
		top: 120rpx;
		left: 220rpx;
		color: #999999;
		font-size: 12px
	}

	.score {
		height: 45rpx;
		position: absolute;
		bottom: 20rpx;
		left: 220rpx;
		color: #FDDB78;
		display: flex;
	}

	.score_icon {
		margin-right: 10rpx;
	}

	.score_text {
		font-size: 12px;
		line-height: 35rpx;
	}

	/* 服务包 */
	.imgs2 {
		width: 160rpx;
		height: 120rpx;
		margin-top: 50rpx;
	}

	.package_box {
		width: 100%;
		height: 228rpx;
		margin: 10rpx 0;
		position: relative;
		padding: 20rpx 30rpx;
		background-color: #FFFFFF;
		border-radius: 24rpx;
		box-sizing: border-box;
		display: flex;
		align-items: center;
		box-shadow: 0px 0px 15px rgb(41 132 248 / 10%);
	}

	.package_right {
		margin-left: 50rpx;
		height: 80%;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
	}

	
	.package_tag {
		font-size: 12px;
		width: 60px;
		height: 24px;
		text-align: center;
		line-height: 24px;
		border-radius: 16rpx;
	}

	.green {
		background-color: rgba(61, 212, 167, 0.2);
		color: #3DD4A7;
	}

	.yellow {
		background-color: rgba(253, 219, 120, 0.2);
		color: #FDDB78;
	}

	.blue {
		color: #2984F8;
		background-color: rgba(41, 132, 248, 0.2);
	}

	.package_price {
		position: absolute;
		top: 40rpx;
		right: 20rpx;
		height: 28px;
		line-height: 28px;
		font-size: 18px;
		color: red;
		font-family: 'PingFangSC-Medium', 'PingFang SC Medium', 'PingFang SC';
		font-weight: 500;
	}

	.package_price>text {
		font-size: 12px;
		font-family: 'PingFangSC-Regular', 'PingFang SC';
	}
</style>
