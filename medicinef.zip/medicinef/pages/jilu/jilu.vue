<template>
  <view class="container">
    <!-- 日期选择器 -->
    <view class="date-selector">
      <button 
        @click="changeDate(-1)" 
        class="date-btn"
      >前一天</button>
      
      <text class="current-date">{{ formattedDate }}</text>
      
      <button 
        @click="changeDate(1)" 
        class="date-btn"
      >后一天</button>
    </view>

    <!-- 健康数据卡片 -->
    <view class="health-cards">
      <!-- 心率卡片 -->
      <view class="health-card heart-rate">
        <view class="card-header">
          <image src="../../static/icon/heart.png" class="card-icon"></image>
          <text class="card-title">心率</text>
        </view>
        <view class="card-content">
          <text class="card-value">{{ healthData.heartRate || '--' }}</text>
          <text class="card-unit">次/分钟</text>
        </view>
        <view class="card-footer">
          <text class="card-trend" :class="getTrendClass('heartRate')">
            {{ getTrendText('heartRate') }}
          </text>
          <text class="card-time">{{ healthData.heartRateTime || '未记录' }}</text>
        </view>
      </view>

      <!-- 血压卡片 -->
      <view class="health-card blood-pressure">
        <view class="card-header">
          <image src="../../static/icon/tiwen.png" class="card-icon"></image>
          <text class="card-title">血压</text>
        </view>
        <view class="card-content">
          <text class="card-value">
            {{ healthData.bloodPressureHigh || '--' }}/{{ healthData.bloodPressureLow || '--' }}
          </text>
          <text class="card-unit">mmHg</text>
        </view>
        <view class="card-footer">
          <text class="card-trend" :class="getTrendClass('bloodPressure')">
            {{ getTrendText('bloodPressure') }}
          </text>
          <text class="card-time">{{ healthData.bloodPressureTime || '未记录' }}</text>
        </view>
      </view>

      <!-- 血氧卡片 -->
      <view class="health-card blood-oxygen">
        <view class="card-header">
          <image src="../../static/icon/O2.png" class="card-icon"></image>
          <text class="card-title">血氧</text>
        </view>
        <view class="card-content">
          <text class="card-value">{{ healthData.bloodOxygen || '--' }}</text>
          <text class="card-unit">%</text>
        </view>
        <view class="card-footer">
          <text class="card-trend" :class="getTrendClass('bloodOxygen')">
            {{ getTrendText('bloodOxygen') }}
          </text>
          <text class="card-time">{{ healthData.bloodOxygenTime || '未记录' }}</text>
        </view>
      </view>

      <!-- 步数卡片 -->
      <view class="health-card steps">
        <view class="card-header">
          <image src="../../static/icon/home-active.png" class="card-icon"></image>
          <text class="card-title">步数</text>
        </view>
        <view class="card-content">
          <text class="card-value">{{ healthData.steps || '--' }}</text>
          <text class="card-unit">步</text>
        </view>
        <view class="card-footer">
          <text class="card-trend" :class="getTrendClass('steps')">
            {{ getTrendText('steps') }}
          </text>
          <text class="card-time">{{ healthData.stepsTime || '未记录' }}</text>
        </view>
      </view>
    </view>

    <!-- 图表展示 - 使用原生Canvas绘制 -->
    <view class="chart-container">
      <view class="chart-title">最近7天健康趋势</view>
      <view class="chart-wrapper">
        <canvas canvas-id="healthChart" class="chart-canvas" 
                :style="{width: chartWidth+'px', height: chartHeight+'px'}"></canvas>
      </view>
    </view>

    <!-- 添加记录按钮 -->
    <view class="add-record-btn" @click="showAddRecordModal">
      <text>+</text>
      <text>添加记录</text>
    </view>

    <!-- 添加记录模态框 -->
    <view class="modal-mask" v-if="showModal" @click="closeModal">
      <view class="modal-content" @click.stop>
        <view class="modal-header">
          <text class="modal-title">添加健康记录</text>
          <text class="modal-close" @click="closeModal">×</text>
        </view>
        <view class="modal-body">
          <view class="form-item">
            <text class="form-label">记录类型</text>
            <picker @change="selectType" :range="recordTypes" class="form-input">
              <view>{{ form.type }}</view>
            </picker>
          </view>
          
          <view class="form-item">
            <text class="form-label">{{ form.type === '血压' ? '高压' : '数值' }}</text>
            <input v-model="form.value1" type="number" class="form-input" />
          </view>
          
          <view class="form-item" v-if="form.type === '血压'">
            <text class="form-label">低压</text>
            <input v-model="form.value2" type="number" class="form-input" />
          </view>
          
          <view class="form-item">
            <text class="form-label">记录时间</text>
            <picker mode="time" @change="selectTime" class="form-input">
              <view>{{ form.time }}</view>
            </picker>
          </view>
        </view>
        <view class="modal-footer">
          <button class="modal-btn cancel" @click="closeModal">取消</button>
          <button class="modal-btn confirm" @click="submitRecord">确定</button>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      currentDate: new Date(),
      healthData: {},
      chartWidth: 300,
      chartHeight: 200,
      showModal: false,
      recordTypes: ['心率', '血压', '血氧', '步数'],
      form: {
        type: '心率',
        value1: '',
        value2: '',
        time: this.formatTime(new Date())
      },
      chartData: {
        labels: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
        datasets: [
          {
            label: '心率',
            data: [72, 75, 70, 68, 73, 77, 74],
            borderColor: '#FF5A5F',
            fill: false
          },
          {
            label: '血压(高压)',
            data: [120, 118, 122, 125, 119, 123, 121],
            borderColor: '#4A90E2',
            fill: false
          },
          {
            label: '血氧',
            data: [98, 97, 98, 96, 97, 98, 97],
            borderColor: '#50E3C2',
            fill: false
          },
          {
            label: '步数(千)',
            data: [5, 8, 6, 7, 9, 10, 8],
            borderColor: '#F8E71C',
            fill: false
          }
        ]
      }
    };
  },
  computed: {
    formattedDate() {
      const year = this.currentDate.getFullYear();
      const month = String(this.currentDate.getMonth() + 1).padStart(2, '0');
      const day = String(this.currentDate.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    }
  },
  onReady() {
    this.initChart();
  },
  onLoad() {
    uni.setNavigationBarTitle({
      title: '记录'
    });
    
    this.loadHealthData();
  },
  methods: {
    formatTime(date) {
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      return `${hours}:${minutes}`;
    },
    
    async loadHealthData() {
      try {
        this.healthData = {
          heartRate: Math.floor(Math.random() * 20) + 60,
          heartRateTime: this.formatTime(new Date()),
          heartRateTrend: Math.floor(Math.random() * 5) - 2,
          
          bloodPressureHigh: Math.floor(Math.random() * 20) + 110,
          bloodPressureLow: Math.floor(Math.random() * 10) + 70,
          bloodPressureTime: this.formatTime(new Date()),
          bloodPressureTrend: Math.floor(Math.random() * 5) - 2,
          
          bloodOxygen: Math.floor(Math.random() * 5) + 95,
          bloodOxygenTime: this.formatTime(new Date()),
          bloodOxygenTrend: Math.floor(Math.random() * 5) - 2,
          
          steps: Math.floor(Math.random() * 8000) + 2000,
          stepsTime: this.formatTime(new Date()),
          stepsTrend: Math.floor(Math.random() * 1000) - 500
        };
      } catch (error) {
        console.error('加载健康数据失败:', error);
        uni.showToast({
          title: '加载数据失败',
          icon: 'none'
        });
      }
    },
    
    initChart() {
      uni.getSystemInfo({
        success: (res) => {
          this.chartWidth = res.windowWidth * 0.9;
          this.chartHeight = this.chartWidth * 0.6;
          this.$nextTick(() => {
            this.drawChart();
          });
        }
      });
    },
    
    drawChart() {
      const ctx = uni.createCanvasContext('healthChart', this);
      const { labels, datasets } = this.chartData;
      const width = this.chartWidth;
      const height = this.chartHeight;
      const padding = 20;
      const chartWidth = width - 2 * padding;
      const chartHeight = height - 2 * padding;
      
      // 1. 绘制背景
      ctx.setFillStyle('#FFFFFF');
      ctx.fillRect(0, 0, width, height);
      
      // 2. 计算最大值和最小值
      let maxValue = -Infinity;
      let minValue = Infinity;
      
      datasets.forEach(dataset => {
        dataset.data.forEach(value => {
          if (value > maxValue) maxValue = value;
          if (value < minValue) minValue = value;
        });
      });
      
      // 添加一些空间
      maxValue = maxValue * 1.1;
      minValue = minValue * 0.9;
      const valueRange = maxValue - minValue;
      
      // 3. 绘制坐标轴
      ctx.setStrokeStyle('#CCCCCC');
      ctx.setLineWidth(1);
      
      // X轴
      ctx.beginPath();
      ctx.moveTo(padding, height - padding);
      ctx.lineTo(width - padding, height - padding);
      ctx.stroke();
      
      // Y轴
      ctx.beginPath();
      ctx.moveTo(padding, padding);
      ctx.lineTo(padding, height - padding);
      ctx.stroke();
      
      // 4. 绘制刻度
      ctx.setFontSize(10);
      ctx.setFillStyle('#666666');
      
      // X轴刻度
      const xStep = chartWidth / (labels.length - 1);
      labels.forEach((label, index) => {
        const x = padding + index * xStep;
        ctx.fillText(label, x - 10, height - padding + 15);
        
        // 刻度线
        ctx.beginPath();
        ctx.moveTo(x, height - padding);
        ctx.lineTo(x, height - padding + 5);
        ctx.stroke();
      });
      
      // Y轴刻度
      const yStep = chartHeight / 5;
      for (let i = 0; i <= 5; i++) {
        const y = height - padding - i * yStep;
        const value = minValue + (valueRange * i / 5);
        
        ctx.beginPath();
        ctx.moveTo(padding, y);
        ctx.lineTo(padding - 5, y);
        ctx.stroke();
        
        ctx.fillText(value.toFixed(0), padding - 25, y + 5);
      }
      
      // 5. 绘制数据线
      datasets.forEach(dataset => {
        ctx.setStrokeStyle(dataset.borderColor);
        ctx.setLineWidth(2);
        ctx.beginPath();
        
        dataset.data.forEach((value, index) => {
          const x = padding + index * xStep;
          const y = height - padding - ((value - minValue) / valueRange) * chartHeight;
          
          if (index === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
          
          // 绘制数据点
          ctx.setFillStyle(dataset.borderColor);
          ctx.beginPath();
          ctx.arc(x, y, 3, 0, Math.PI * 2);
          ctx.fill();
        });
        
        ctx.stroke();
      });
      
      // 6. 绘制图例
      const legendX = padding + 10;
      const legendY = padding - 10;
      datasets.forEach((dataset, index) => {
        ctx.setFillStyle(dataset.borderColor);
        ctx.fillRect(legendX + index * 70, legendY, 10, 10);
        ctx.fillText(dataset.label, legendX + index * 70 + 15, legendY + 8);
      });
      
      ctx.draw();
    },
    
    changeDate(days) {
      const newDate = new Date(this.currentDate);
      newDate.setDate(newDate.getDate() + days);
      this.currentDate = newDate;
      this.loadHealthData();
    },
    
    getTrendClass(field) {
      if (!this.healthData[`${field}Trend`]) return '';
      return this.healthData[`${field}Trend`] > 0 ? 'trend-up' : 
             this.healthData[`${field}Trend`] < 0 ? 'trend-down' : '';
    },
    
    getTrendText(field) {
      if (!this.healthData[`${field}Trend`]) return '暂无趋势';
      const trend = this.healthData[`${field}Trend`];
      return trend > 0 ? `↑ ${Math.abs(trend)}` : 
             trend < 0 ? `↓ ${Math.abs(trend)}` : '→ 持平';
    },
    
    showAddRecordModal() {
      this.showModal = true;
    },
    
    closeModal() {
      this.showModal = false;
    },
    
    selectType(e) {
      this.form.type = this.recordTypes[e.detail.value];
    },
    
    selectTime(e) {
      this.form.time = e.detail.value;
    },
    
    async submitRecord() {
      try {
        const recordData = {
          type: this.form.type,
          value1: this.form.value1,
          value2: this.form.value2,
          time: this.form.time,
          date: this.formattedDate
        };
        
        console.log('添加记录:', recordData);
        uni.showToast({
          title: '记录添加成功',
          icon: 'success'
        });
        
        this.showModal = false;
        this.resetForm();
        this.loadHealthData();
      } catch (error) {
        console.error('添加记录失败:', error);
        uni.showToast({
          title: '添加记录失败',
          icon: 'none'
        });
      }
    },
    
    resetForm() {
      this.form = {
        type: '心率',
        value1: '',
        value2: '',
        time: this.formatTime(new Date())
      };
    }
  }
};
</script>

<style lang="less" scoped>
.container {
  padding: 20rpx;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.date-selector {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 20rpx 0;
  padding: 0 5rpx;
  
  .current-date {
    font-size: 35rpx;
    font-weight: bold;
    color: #333;
  }
  
  .date-btn {
    padding: 0 10rpx;
    width: 200rpx;
    height: 80rpx;
    font-size: 30rpx;
    background: transparent;
    border: 1rpx solid #ddd;
    border-radius: 8rpx;
  }
}

.health-cards {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20rpx;
  margin-bottom: 30rpx;
}

.health-card {
  background-color: #fff;
  border-radius: 16rpx;
  padding: 20rpx;
  box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
  
  &.heart-rate {
    border-top: 8rpx solid #FF5A5F;
  }
  
  &.blood-pressure {
    border-top: 8rpx solid #4A90E2;
  }
  
  &.blood-oxygen {
    border-top: 8rpx solid #50E3C2;
  }
  
  &.steps {
    border-top: 8rpx solid #F8E71C;
  }
}

.card-header {
  display: flex;
  align-items: center;
  margin-bottom: 15rpx;
  
  .card-icon {
    width: 40rpx;
    height: 40rpx;
    margin-right: 10rpx;
  }
  
  .card-title {
    font-size: 28rpx;
    font-weight: bold;
    color: #333;
  }
}

.card-content {
  display: flex;
  align-items: flex-end;
  margin-bottom: 15rpx;
  
  .card-value {
    font-size: 48rpx;
    font-weight: bold;
    color: #333;
    margin-right: 10rpx;
  }
  
  .card-unit {
    font-size: 24rpx;
    color: #999;
    margin-bottom: 6rpx;
  }
}

.card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  
  .card-trend {
    font-size: 24rpx;
    
    &.trend-up {
      color: #FF5A5F;
    }
    
    &.trend-down {
      color: #50E3C2;
    }
  }
  
  .card-time {
    font-size: 22rpx;
    color: #999;
  }
}

.chart-container {
  background-color: #fff;
  border-radius: 16rpx;
  padding: 20rpx;
  margin-bottom: 30rpx;
  box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
  
  .chart-title {
    font-size: 32rpx;
    font-weight: bold;
    color: #333;
    margin-bottom: 20rpx;
    text-align: center;
  }
  
  .chart-wrapper {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: auto;
    
    .chart-canvas {
      background-color: #fff;
    }
  }
}

.add-record-btn {
  position: fixed;
  right: 40rpx;
  bottom: 80rpx;
  background-color: #3A8EE6;
  color: #fff;
  border-radius: 50%;
  width: 130rpx;
  height: 125rpx;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  box-shadow: 0 4rpx 12rpx rgba(58, 142, 230, 0.3);
  
  text {
    font-size: 24rpx;
    margin-top: 1rpx;
  }
  
  text:first-child {
    font-size: 60rpx;
    line-height: 36rpx;
  }
}

.modal-mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}

.modal-content {
  width: 80%;
  background-color: #fff;
  border-radius: 16rpx;
  overflow: hidden;
}

.modal-header {
  padding: 30rpx;
  border-bottom: 1rpx solid #eee;
  display: flex;
  justify-content: space-between;
  align-items: center;
  
  .modal-title {
    font-size: 32rpx;
    font-weight: bold;
  }
  
  .modal-close {
    font-size: 40rpx;
    color: #999;
  }
}

.modal-body {
  padding: 30rpx;
}

.form-item {
  margin-bottom: 30rpx;
  
  .form-label {
    display: block;
    margin-bottom: 10rpx;
    font-size: 28rpx;
    color: #666;
  }
  
  .form-input {
    border: 1rpx solid #ddd;
    border-radius: 8rpx;
    padding: 20rpx;
    font-size: 28rpx;
  }
}

.modal-footer {
  display: flex;
  border-top: 1rpx solid #eee;
  
  .modal-btn {
    flex: 1;
    padding: 30rpx;
    font-size: 30rpx;
    background: none;
    border: none;
    
    &.cancel {
      color: #666;
      border-right: 1rpx solid #eee;
    }
    
    &.confirm {
      color: #3A8EE6;
      font-weight: bold;
    }
  }
}

.trend-up {
  color: #FF5A5F;
}

.trend-down {
  color: #50E3C2;
}
</style>