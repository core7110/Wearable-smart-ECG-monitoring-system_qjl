<template>
  <view class="register-container">
    <!-- 顶部波浪背景 - 与登录页保持一致 -->
    <view class="wave-container">
      <image src="https://img.freepik.com/free-vector/abstract-blue-wave-background_53876-88677.jpg" mode="widthFix" class="wave-bg"></image>
      <view class="app-title-container">
        <image src="https://img.icons8.com/ios-filled/100/ffffff/heart-health.png" class="app-icon"></image>
        <view class="app-title">注 册</view>
        <view class="app-subtitle">创建您的健康账户</view>
      </view>
    </view>
    
    <!-- 注册内容区域 -->
    <view class="register-content">
      <u-form :rules="rules" :model="form" errorType="message" ref="uFormRef">
        <!-- 用户名输入 -->
        <u-form-item prop="username" label-width="0px">
          <view class="input-container" :class="{'input-focused': usernameFocused}">
            <u-icon name="account" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.username"
              placeholder="请输入账号"
              placeholderClass="placeholder-style"
              border="none"
              clearable
              @focus="usernameFocused = true"
              @blur="usernameFocused = false"
            ></u-input>
          </view>
        </u-form-item>
        
        <!-- 密码输入 -->
        <u-form-item prop="password" label-width="0px">
          <view class="input-container" :class="{'input-focused': passwordFocused}">
            <u-icon name="lock" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.password"
              :type="showPassword ? 'text' : 'password'"
              placeholder="请输入密码"
              placeholderClass="placeholder-style"
              border="none"
              clearable
              @focus="passwordFocused = true"
              @blur="passwordFocused = false"
            ></u-input>
            <u-icon 
              :name="showPassword ? 'eye-fill' : 'eye-off'" 
              color="#4a90e2" 
              size="20"
              @click="togglePasswordVisibility"
            ></u-icon>
          </view>
        </u-form-item>
        
        <!-- 确认密码输入 -->
        <u-form-item prop="confirmPassword" label-width="0px">
          <view class="input-container" :class="{'input-focused': confirmPasswordFocused}">
            <u-icon name="lock" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.confirmPassword"
              :type="showConfirmPassword ? 'text' : 'password'"
              placeholder="请再次输入密码"
              placeholderClass="placeholder-style"
              border="none"
              clearable
              @focus="confirmPasswordFocused = true"
              @blur="confirmPasswordFocused = false"
            ></u-input>
            <u-icon 
              :name="showConfirmPassword ? 'eye-fill' : 'eye-off'" 
              color="#4a90e2" 
              size="20"
              @click="showConfirmPassword = !showConfirmPassword"
            ></u-icon>
          </view>
        </u-form-item>
        
        <!-- 邮箱输入 -->
        <u-form-item prop="email" label-width="0px">
          <view class="input-container" :class="{'input-focused': emailFocused}">
            <u-icon name="email" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.email"
              placeholder="请输入邮箱"
              placeholderClass="placeholder-style"
              border="none"
              clearable
              @focus="emailFocused = true"
              @blur="emailFocused = false"
            ></u-input>
          </view>
        </u-form-item>
        
        <!-- 手机号输入 -->
        <u-form-item prop="phone" label-width="0px">
          <view class="input-container" :class="{'input-focused': phoneFocused}">
            <u-icon name="phone" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.phone"
              placeholder="请输入手机号"
              placeholderClass="placeholder-style"
              border="none"
              clearable
              @focus="phoneFocused = true"
              @blur="phoneFocused = false"
            ></u-input>
          </view>
        </u-form-item>
        
        <!-- 验证码输入 -->
        <u-form-item prop="code" label-width="0px">
          <view class="input-container code-container" :class="{'input-focused': codeFocused}">
            <u-icon name="shield" color="#4a90e2" size="20"></u-icon>
            <u-input
              v-model="form.code"
              placeholder="请输入验证码"
              placeholderClass="placeholder-style"
              border="none"
              @focus="codeFocused = true"
              @blur="codeFocused = false"
            ></u-input>
            <u-button
              class="code-btn"
              @tap="getCode"
              :text="tips"
              size="mini"
              :disabled="disabled"
              :customStyle="{
                backgroundColor: '#4a90e2',
                color: '#fff',
                border: 'none',
                boxShadow: '0 4rpx 12rpx rgba(74, 144, 226, 0.3)'
              }"
            ></u-button>
            <u-code
              ref="uCode"
              @change="codeChange"
              keep-running
              change-text="倒计时XS"
              @start="disabled = true"
              @end="disabled = false"
              seconds="30"
              start-text="获取验证码"
              end-text="重新获取"
            ></u-code>
          </view>
        </u-form-item>
      </u-form>
      
      <!-- 注册按钮 -->
      <u-button 
        class="register-btn" 
        shape="circle" 
        text="注 册" 
        color="#4a90e2"
        @click="register"
        :loading="loading"
        :customStyle="{
          boxShadow: '0 10rpx 20rpx rgba(74, 144, 226, 0.3)',
          transform: registerBtnScale,
          transition: 'transform 0.2s ease',
          marginTop: '60rpx'
        }"
        @touchstart="registerBtnScale = 'scale(0.98)'"
        @touchend="registerBtnScale = 'scale(1)'"
      ></u-button>
      
      <!-- 已有账号引导 -->
      <view class="login-guide">
        <text>已有账号?</text>
        <text class="login-link" @click="backToLogin">立即登录</text>
      </view>
    </view>
    
    <!-- 底部装饰 - 与登录页保持一致 -->
    <view class="bottom-decoration">
      <image src="https://img.freepik.com/free-vector/medical-healthcare-pattern-background_53876-93121.jpg" mode="widthFix" class="decoration-img"></image>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      form: {
        username: '',
        password: '',
        confirmPassword: '',
        email: '',
        phone: '',
        code: ''
      },
      tips: '获取验证码',
      disabled: false,
      loading: false,
      registerBtnScale: 'scale(1)',
      usernameFocused: false,
      passwordFocused: false,
      confirmPasswordFocused: false,
      emailFocused: false,
      phoneFocused: false,
      codeFocused: false,
      showPassword: false,
      showConfirmPassword: false,
      rules: {
        username: [
          { 
            required: true, 
            message: '请输入账号', 
            trigger: ['blur', 'change'] 
          },
          {
            pattern: /^\d{10}$/,
            message: '账号必须为10位数字',
            trigger: ['blur', 'change']
          }
        ],
        password: [
          { 
            required: true, 
            message: '请输入密码', 
            trigger: ['blur', 'change'] 
          },
          {
            minLength: 6,
            message: '密码长度不能少于6位',
            trigger: ['blur', 'change']
          }
        ],
        confirmPassword: [
          { 
            required: true, 
            message: '请再次输入密码', 
            trigger: ['blur', 'change'] 
          },
          {
            validator: (rule, value, callback) => {
              if (value === this.form.password) {
                callback();
              } else {
                callback(new Error('两次输入的密码不一致'));
              }
            },
            trigger: ['blur', 'change']
          }
        ],
        email: [
          { 
            required: true, 
            message: '请输入邮箱', 
            trigger: ['blur', 'change'] 
          },
          {
            type: 'email',
            message: '请输入正确的邮箱格式',
            trigger: ['blur', 'change']
          }
        ],
        phone: [
          { 
            required: true, 
            message: '请输入手机号', 
            trigger: ['blur', 'change'] 
          },
          {
            pattern: /^1[3-9]\d{9}$/,
            message: '请输入正确的手机号',
            trigger: ['blur', 'change']
          }
        ],
        code: [
          { 
            required: true, 
            message: '请输入验证码', 
            trigger: ['blur', 'change'] 
          },
          {
            len: 6,
            message: '验证码为6位数字',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
  },
   methods: {
    register() {
    
          this.loading = true;
          uni.showLoading({
            title: '注册中...',
            mask: true
          });
          
          // 调用注册API
          uni.request({
            url: 'http://localhost:8000/base/register/', // 确保这是你的Django后端注册API的URL
            method: 'POST',
            data: {
              email: this.form.email,
              emailCode: this.form.code, // 注意这里使用emailCode字段名，与后端一致
              username: this.form.username,
              password: this.form.password,
              confirmPassword: this.form.confirmPassword, // 注意这里添加了confirmPassword字段
              phone: this.form.phone
            },
            success: (res) => {
              uni.hideLoading();
              if (res.data.code === 200) {
                uni.$u.toast('注册成功');
                this.backToLogin();
              } else {
				console.log(res.data)
                uni.$u.toast(res.data.msg);
              }
            },
            fail: (err) => {
              console.error('注册请求失败:', err);
              uni.$u.toast('网络错误，请稍后重试');
            },
            complete: () => {
              this.loading = false;
            }
          });
        
      
    },
    codeChange(text) {
      this.tips = text;
    },
     // 发送邮箱验证码的方法
        getCode() {
          if (!this.form.email) {
            uni.$u.toast('请输入邮箱地址');
            return;
          }
          
          if (!/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(this.form.email)) {
            uni.$u.toast('邮箱格式不正确');
            return;
          }
          
          // 开始倒计时
          this.$refs.uCode.start();
          
          // 调用后端发送验证码的API
          uni.request({
            url: 'http://localhost:8000/base/sendEmail/', // 确保这是你的Django后端发送验证码API的URL
            method: 'POST',
            data: {
              email: this.form.email
            },
            success: (res) => {
              if (res.data.code === 200) {
                uni.$u.toast('验证码已发送至您的邮箱');
              } else {
                uni.$u.toast(res.data.msg);
                this.$refs.uCode.reset(); // 发送失败，重置倒计时
              }
            },
            fail: (err) => {
              console.error('获取验证码请求失败:', err);
              uni.$u.toast('网络错误，请稍后重试');
              this.$refs.uCode.reset(); // 网络错误，重置倒计时
            }
          });
        },
    togglePasswordVisibility() {
      this.showPassword = !this.showPassword;
    },
    backToLogin() {
      uni.navigateBack();
    }
  }
}
</script>

<style lang="scss" scoped>
.register-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: linear-gradient(to bottom, #f7faff, #ffffff);
  position: relative;
  overflow: hidden;
  
  .wave-container {
    position: relative;
    height: 380rpx;
    overflow: hidden;
    
    .wave-bg {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .app-title-container {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
      width: 100%;
      
      .app-icon {
        width: 80rpx;
        height: 80rpx;
        margin-bottom: 15rpx;
        filter: drop-shadow(0 4rpx 8rpx rgba(0, 0, 0, 0.1));
      }
      
      .app-title {
        font-family: 'STKaiti', '楷体', serif;
        font-size: 52rpx;
        font-weight: bold;
        color: #fff;
        text-shadow: 0 4rpx 8rpx rgba(0, 0, 0, 0.2);
        letter-spacing: 10rpx;
        margin-bottom: 10rpx;
      }
      
      .app-subtitle {
        font-size: 28rpx;
        color: rgba(255, 255, 255, 0.9);
        letter-spacing: 2rpx;
      }
    }
  }
  
  .register-content {
    flex: 1;
    padding: 40rpx 50rpx;
    display: flex;
    flex-direction: column;
    margin-top: -20rpx;
    background-color: #fff;
    border-radius: 40rpx 40rpx 0 0;
    box-shadow: 0 -10rpx 30rpx rgba(0, 0, 0, 0.05);
    z-index: 1;
    
    .input-container {
      display: flex;
      align-items: center;
      background-color: #f8f9fa;
      border-radius: 50rpx;
      padding: 25rpx 35rpx;
      margin-bottom:0rpx;
      width: 100%;
      box-sizing: border-box;
      border: 2rpx solid #e9ecef;
      transition: all 0.3s ease;
      
      &.input-focused {
        border-color: #4a90e2;
        box-shadow: 0 0 0 4rpx rgba(74, 144, 226, 0.2);
      }
      
      .u-icon {
        margin-right: 20rpx;
      }
      
      ::v-deep .u-input {
        flex: 1;
        font-size: 32rpx;
        min-height: 50rpx;
        background-color: transparent;
      }
      
      ::v-deep .placeholder-style {
        color: #adb5bd;
        font-size: 32rpx;
      }
      
      &.code-container {
        padding-right: 20rpx;
        
        .code-btn {
          width: 200rpx;
          height: 60rpx;
          margin-left: 20rpx;
          border-radius: 30rpx;
          
          ::v-deep .u-button__text {
            font-size: 26rpx;
          }
        }
      }
    }
    
    .register-btn {
      height: 90rpx;
      font-size: 36rpx;
      letter-spacing: 5rpx;
      width: 100%;
      border: none;
      font-weight: 500;
      
      ::v-deep .u-button__text {
        letter-spacing: 5rpx;
      }
    }
    
    .login-guide {
      text-align: center;
      color: #999;
      font-size: 28rpx;
      margin-top: 40rpx;
      
      .login-link {
        color: #4a90e2;
        margin-left: 10rpx;
        font-weight: 500;
      }
    }
  }
  
  .bottom-decoration {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 120rpx;
    overflow: hidden;
    z-index: 0;
    
    .decoration-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 0.8;
    }
  }
}
</style>